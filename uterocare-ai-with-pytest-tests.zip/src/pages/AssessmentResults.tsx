import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Printer, 
  Share2, 
  AlertTriangle, 
  CheckCircle2, 
  HelpCircle, 
  Stethoscope, 
  FileText, 
  Sparkles,
  Info,
  Calendar,
  ShieldAlert,
  Download
} from 'lucide-react';
import { api } from '../services/api';
import { AssessmentResult, Assessment, SymptomData } from '../types';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';

export const AssessmentResults: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [symptoms, setSymptoms] = useState<SymptomData>({});
  const [result, setResult] = useState<AssessmentResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      loadData(id);
    }
  }, [id]);

  const loadData = async (assessmentId: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getAssessment(assessmentId);
      setAssessment(res.assessment);
      setSymptoms(res.symptoms || {});
      setResult(res.result);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve assessment results.');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-10 h-10 border-3 border-[#451E33] border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-gray-500 font-sans">Compiling clinical assessment report...</p>
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <Card variant="white" className="p-8 max-w-lg mx-auto">
          <AlertTriangle className="w-10 h-10 text-amber-600 mx-auto mb-3" />
          <h2 className="text-xl font-bold text-[#2C141F] font-editorial">
            Analysis Not Found
          </h2>
          <p className="text-xs text-gray-600 mt-2 mb-6">
            {error || 'This assessment has not been analyzed yet. Please complete the review step in the workspace.'}
          </p>
          <div className="flex justify-center gap-3">
            <Link to={id ? `/assessment/${id}/workspace` : '/assessments'}>
              <Button variant="primary" size="md">
                Open Workspace & Analyze
              </Button>
            </Link>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 print:p-0 print:m-0 print:max-w-none">
      
      {/* Top Action Bar (Hidden on print) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E9E3DC] print:hidden">
        <div className="flex items-center gap-3">
          <Link
            to="/assessments"
            className="p-1.5 rounded-xl text-gray-500 hover:text-[#451E33] hover:bg-[#F5E5EC] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-[#FAF2F5] text-[#451E33] border border-[#EAC9D9]">
                {result.assessment_id}
              </span>
              <span className="text-xs text-gray-400">• Comprehensive Report</span>
            </div>
            <h1 className="text-2xl font-bold text-[#2C141F] font-editorial mt-0.5">
              Clinical Assessment Summary
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handlePrint}
            icon={<Printer className="w-4 h-4" />}
          >
            Print / Save as PDF
          </Button>

          <Link to={`/assessment/${id}/doctor-prep`}>
            <Button
              variant="sage"
              size="sm"
              icon={<Stethoscope className="w-4 h-4" />}
            >
              Doctor Prep Guide
            </Button>
          </Link>
        </div>
      </div>

      {/* EMERGENCY OR URGENCY CALLOUT */}
      {result.urgency_level === 'immediate_emergency' && (
        <div className="bg-rose-50 border-2 border-rose-300 rounded-3xl p-6 space-y-3">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-6 h-6 text-rose-700 shrink-0" />
            <h3 className="text-base font-bold text-rose-900 font-editorial uppercase tracking-wide">
              Immediate Emergency Care Advised
            </h3>
          </div>
          <p className="text-xs sm:text-sm text-rose-800 leading-relaxed">
            Reported symptoms (such as extreme hemorrhaging, sudden severe pelvic pain, or pregnancy complications) indicate acute risk. Please contact emergency services or proceed to the nearest emergency department.
          </p>
        </div>
      )}

      {/* PRINT-FRIENDLY CLINICAL REPORT CARD */}
      <Card variant="white" className="p-8 sm:p-12 space-y-8 border-[#E9E3DC] shadow-sm">
        
        {/* Header of Report */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-gray-200 gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold font-editorial text-[#2C141F]">UteroCare AI</span>
              <span className="text-[10px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full bg-[#FAF2F5] text-[#9B4274] border border-[#EAC9D9]">
                Clinical Evaluation
              </span>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Assessment ID: <span className="font-mono text-gray-800 font-medium">{result.assessment_id}</span>
            </p>
          </div>

          <div className="text-left sm:text-right text-xs text-gray-500 space-y-0.5">
            <p>Generated: {new Date(result.created_at).toLocaleDateString()} at {new Date(result.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
            <div className="pt-1">
              <Badge variant={result.urgency_level === 'immediate_emergency' ? 'emergency' : result.urgency_level === 'urgent' ? 'urgent' : 'routine'}>
                Triage Priority: {result.urgency_level.replace('_', ' ')}
              </Badge>
            </div>
          </div>
        </div>

        {/* Executive Summary */}
        <div className="space-y-2">
          <h2 className="text-sm font-bold uppercase tracking-wider text-[#451E33]">
            1. Clinical Executive Summary
          </h2>
          <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] text-xs text-gray-800 leading-relaxed font-sans">
            {result.summary}
          </div>
        </div>

        {/* Identified Clinical Patterns (PALM-COEIN) */}
        <div className="space-y-4">
          <h2 className="text-sm font-bold uppercase tracking-wider text-[#451E33]">
            2. Correlated Clinical Patterns (FIGO PALM-COEIN)
          </h2>
          <p className="text-xs text-gray-600">
            Based on reported bleeding volume, dysmenorrhea severity, and anatomical pressure characteristics. These are educational patterns to review with a qualified gynecologist and do not constitute an unconfirmed medical diagnosis.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {result.identified_patterns.map((item, idx) => (
              <div key={idx} className="p-5 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-[#2C141F] font-editorial">
                    {item.conditionName}
                  </h3>
                  <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded-full bg-[#FAF2F5] text-[#9B4274] border border-[#EAC9D9]">
                    {item.category}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs">
                  <strong className="text-[11px] text-gray-500 block uppercase tracking-wide">Key Matching Features:</strong>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    {item.matchingFeatures.map((f, fIdx) => (
                      <li key={fIdx} className="leading-snug">{f}</li>
                    ))}
                  </ul>
                </div>

                <div className="pt-2 border-t border-gray-200/60 text-xs text-gray-600 leading-relaxed italic">
                  {item.educationalNotes}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Ultrasound Interpretation Capability Status (Part 10 directive) */}
        <div className="space-y-2">
          <h2 className="text-sm font-bold uppercase tracking-wider text-[#451E33]">
            3. Ultrasound & Medical Imaging Status
          </h2>
          <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] flex items-start gap-3">
            <Info className="w-5 h-5 text-[#7B325B] shrink-0 mt-0.5" />
            <div className="text-xs text-gray-700 leading-relaxed">
              <strong className="text-[#451E33]">Model Availability Notice:</strong> Automated ultrasound interpretation is unavailable because a compatible trained model has not been configured in this environment. No synthetic or unvalidated probabilities have been fabricated. Dedicated pelvic transvaginal ultrasound (TVS) or saline sonohysterography (SIS) must be interpreted by a certified sonologist or radiologist.
            </div>
          </div>
        </div>

        {/* Evidence Sources & Missing Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#451E33]">
              4. Evidence Sources
            </h2>
            <ul className="space-y-1.5 text-xs text-gray-700 bg-[#FAF8F5] border border-[#E9E3DC] p-4 rounded-2xl">
              {result.evidence_sources.map((src, i) => (
                <li key={i} className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#5A7B57] shrink-0" />
                  <span>{src}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#451E33]">
              5. Missing Clinical Information
            </h2>
            <ul className="space-y-1.5 text-xs text-gray-700 bg-[#FAF8F5] border border-[#E9E3DC] p-4 rounded-2xl">
              {result.missing_information.length > 0 ? (
                result.missing_information.map((info, i) => (
                  <li key={i} className="flex items-center gap-2">
                    <HelpCircle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                    <span>{info}</span>
                  </li>
                ))
              ) : (
                <li className="text-gray-500 italic">No critical symptom fields missing.</li>
              )}
            </ul>
          </div>
        </div>

        {/* Tailored Questions for Doctor Consultation */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold uppercase tracking-wider text-[#451E33]">
              6. Tailored Questions for Your Doctor
            </h2>
            <Link to={`/assessment/${id}/doctor-prep`} className="text-xs font-semibold text-[#7B325B] hover:underline print:hidden">
              Open Interactive Prep Guide &rarr;
            </Link>
          </div>
          <div className="p-4 rounded-2xl bg-[#EEF3ED] border border-[#D0E0CE] space-y-2.5">
            {result.questions_for_doctor.map((q, i) => (
              <div key={i} className="flex items-start gap-2.5 text-xs text-[#2C2426]">
                <span className="font-bold text-[#5A7B57] shrink-0">{i + 1}.</span>
                <span className="leading-snug">{q}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Full Clinical Disclaimer */}
        <div className="pt-4 border-t border-gray-200 space-y-2">
          <h2 className="text-xs font-bold uppercase tracking-wider text-gray-400">
            Medical Disclaimer & Limitations
          </h2>
          <p className="text-[11px] text-gray-500 leading-relaxed italic">
            {result.disclaimer}
          </p>
        </div>

      </Card>

    </div>
  );
};
