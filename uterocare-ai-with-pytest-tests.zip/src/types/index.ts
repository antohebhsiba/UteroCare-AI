export interface User {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export interface Assessment {
  id: string;
  user_id: string;
  title: string;
  status: 'draft' | 'collecting_information' | 'ready_for_review' | 'processing' | 'completed' | 'analysis_unavailable' | 'failed' | 'cancelled';
  current_step: number;
  emergency_flag: number;
  created_at: string;
  updated_at: string;
  document_count?: number;
  result_id?: string;
  urgency_level?: string;
  main_concern?: string;
}

export interface SymptomData {
  age_range?: string;
  main_concern?: string;
  cycle_regularity?: string;
  cycle_length?: string;
  bleeding_duration?: string;
  bleeding_heaviness?: string;
  pelvic_pain_presence?: string;
  pain_severity?: number;
  pain_location?: string;
  pain_timing?: string;
  intermenstrual_bleeding?: string;
  postcoital_bleeding?: string;
  pelvic_pressure?: string;
  urinary_bowel_symptoms?: string;
  symptom_duration?: string;
  pregnancy_possibility?: string;
  prior_diagnoses?: string;
  current_medications?: string;
  additional_notes?: string;
  updated_at?: string;
}

export interface MedicalDocument {
  id: string;
  assessment_id: string;
  filename: string;
  original_name: string;
  mime_type: string;
  size_bytes: number;
  document_type: 'ultrasound_image' | 'pdf_report' | 'clinical_note' | 'other';
  extracted_text?: string | null;
  status: string;
  created_at: string;
}

export interface ClinicalPatternMatch {
  conditionId: string;
  conditionName: string;
  category: 'uterine' | 'related' | 'systemic' | 'acute';
  matchingFeatures: string[];
  differentiatingFactors: string[];
  educationalNotes: string;
}

export interface AssessmentResult {
  id: string;
  assessment_id: string;
  user_id: string;
  summary: string;
  urgency_level: 'routine' | 'soon' | 'urgent' | 'immediate_emergency';
  urgency_reasons: string[];
  identified_patterns: ClinicalPatternMatch[];
  report_findings?: any;
  ultrasound_status: 'unavailable_no_trained_model' | 'completed' | 'not_provided';
  evidence_sources: string[];
  missing_information: string[];
  questions_for_doctor: string[];
  lifestyle_guidance?: string[];
  disclaimer: string;
  created_at: string;
}

export interface MenstrualEntry {
  id: string;
  user_id: string;
  start_date: string;
  end_date?: string | null;
  flow_intensity?: 'spotting' | 'light' | 'medium' | 'heavy' | 'very_heavy' | null;
  pain_level?: number | null;
  symptoms: string[];
  notes?: string | null;
  created_at: string;
  updated_at: string;
}

export interface CycleAnalytics {
  totalRecordedCycles: number;
  averageCycleDays: number | null;
  averagePeriodDays: number | null;
  estimatedNextPeriod: string | null;
  estimationDisclaimer: string | null;
}

export interface ConditionInfo {
  id: string;
  name: string;
  category: 'uterine' | 'related' | 'systemic' | 'acute';
  description: string;
  typicalSymptoms: string[];
  diagnosticGoldStandards: string[];
  palmCoeinCategory?: string;
  recommendedInvestigations: string[];
  treatmentOverview: string[];
}
