import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Heart } from 'lucide-react';

export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#FAF8F5] flex flex-col items-center justify-center p-4">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#451E33] to-[#7B325B] flex items-center justify-center text-white shadow-lg animate-pulse mb-4">
          <Heart className="w-7 h-7 fill-rose-200" />
        </div>
        <p className="text-sm font-semibold text-[#451E33] font-editorial tracking-wide">
          Verifying Clinical Session...
        </p>
        <p className="text-xs text-gray-500 mt-1">
          Restoring secure encrypted user context
        </p>
      </div>
    );
  }

  if (!user) {
    return <Navigate to={`/login?redirect=${encodeURIComponent(location.pathname + location.search)}`} replace />;
  }

  return <>{children}</>;
};
