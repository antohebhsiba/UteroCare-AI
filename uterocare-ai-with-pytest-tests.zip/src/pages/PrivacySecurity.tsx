import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ShieldCheck, 
  Lock, 
  FileKey, 
  Server, 
  Trash2, 
  CheckCircle2, 
  AlertCircle,
  EyeOff,
  UserCheck
} from 'lucide-react';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';

export const PrivacySecurity: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <Badge variant="sage">Confidentiality & Compliance</Badge>
        <h1 className="text-3xl sm:text-4xl font-bold text-[#2C141F] font-editorial">
          Privacy & Security Architecture
        </h1>
        <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
          How UteroCare AI protects your sensitive gynecological questionnaires, ultrasound images, and menstrual cycle logs.
        </p>
      </div>

      {/* Security Architecture Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        <Card variant="white" className="p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#FAF2F5] text-[#451E33] flex items-center justify-center">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-[#2C141F] font-editorial">
            Authentication & Password Security
          </h3>
          <p className="text-xs text-gray-600 leading-relaxed">
            All user passwords are encrypted using multi-round salt hashing (Bcrypt/Argon2id). Passwords are never stored in plaintext and never logged in application diagnostics.
          </p>
        </Card>

        <Card variant="white" className="p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#EEF3ED] text-[#5A7B57] flex items-center justify-center">
            <Server className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-[#2C141F] font-editorial">
            HTTP-Only Cookie Sessions
          </h3>
          <p className="text-xs text-gray-600 leading-relaxed">
            Authentication sessions use secure, HTTP-only cookies protected against client-side JavaScript access (mitigating XSS theft). Sessions automatically expire after 7 days of inactivity.
          </p>
        </Card>

        <Card variant="white" className="p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#FAF2F5] text-[#9B4274] flex items-center justify-center">
            <EyeOff className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-[#2C141F] font-editorial">
            Private Medical Document Isolation
          </h3>
          <p className="text-xs text-gray-600 leading-relaxed">
            Uploaded ultrasound scans and PDF records are saved in private server directories strictly outside public web-root directories. Files are streamed only after checking active user ownership.
          </p>
        </Card>

        <Card variant="white" className="p-6 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-[#FAF8F5] text-[#451E33] flex items-center justify-center border border-[#E9E3DC]">
            <Trash2 className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-[#2C141F] font-editorial">
            Complete Data Erasure (Right to be Forgotten)
          </h3>
          <p className="text-xs text-gray-600 leading-relaxed">
            When you delete an assessment or your entire user account, all associated database records, symptoms, cycles, and physical file attachments are permanently unlinked and deleted from storage.
          </p>
        </Card>

      </div>

      {/* Security Principles Checklist */}
      <Card variant="white" className="p-6 sm:p-8 space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#451E33] border-b border-gray-100 pb-3">
          Technical Guarantees Implemented
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-gray-700">
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0 mt-0.5" />
            <span>Strict server-side Zod validation on every endpoint</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0 mt-0.5" />
            <span>Parameterized SQLite queries preventing SQL injection</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0 mt-0.5" />
            <span>Multi-user isolation preventing cross-account access</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0 mt-0.5" />
            <span>Brute-force login rate limiting on authentication routes</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0 mt-0.5" />
            <span>File size limits (15MB) and strict MIME type verification</span>
          </div>
          <div className="flex items-start gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0 mt-0.5" />
            <span>Zero third-party tracking scripts or advertising trackers</span>
          </div>
        </div>
      </Card>

      {/* Honest Limitation Statement (Part 15 directive) */}
      <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] text-xs text-gray-600 leading-relaxed space-y-1">
        <strong className="text-gray-900 block">Encryption Transparency:</strong>
        <p>
          Data transmission is encrypted in transit via TLS/HTTPS. Local persistent storage is securely managed via SQLite WAL journaling and filesystem permission controls. No automated claim of unverified disk-level hardware encryption is asserted.
        </p>
      </div>

    </div>
  );
};
