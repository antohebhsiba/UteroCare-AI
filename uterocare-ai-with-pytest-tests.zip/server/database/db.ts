import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

// Ensure data directory exists
const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Ensure private uploads directory exists
const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'uterocare.db');
export const db = new Database(DB_PATH);

// Optimize database performance & data integrity
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

    CREATE TABLE IF NOT EXISTS assessments (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      title TEXT NOT NULL,
      status TEXT NOT NULL,
      current_step INTEGER DEFAULT 1,
      emergency_flag INTEGER DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_assessments_user ON assessments(user_id);
    CREATE INDEX IF NOT EXISTS idx_assessments_status ON assessments(status);

    CREATE TABLE IF NOT EXISTS symptom_responses (
      id TEXT PRIMARY KEY,
      assessment_id TEXT UNIQUE NOT NULL,
      age_range TEXT,
      main_concern TEXT,
      cycle_regularity TEXT,
      cycle_length TEXT,
      bleeding_duration TEXT,
      bleeding_heaviness TEXT,
      pelvic_pain_presence TEXT,
      pain_severity INTEGER,
      pain_location TEXT,
      pain_timing TEXT,
      intermenstrual_bleeding TEXT,
      postcoital_bleeding TEXT,
      pelvic_pressure TEXT,
      urinary_bowel_symptoms TEXT,
      symptom_duration TEXT,
      pregnancy_possibility TEXT,
      prior_diagnoses TEXT,
      current_medications TEXT,
      additional_notes TEXT,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_symptoms_assessment ON symptom_responses(assessment_id);

    CREATE TABLE IF NOT EXISTS medical_documents (
      id TEXT PRIMARY KEY,
      assessment_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      filename TEXT NOT NULL,
      original_name TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      storage_path TEXT NOT NULL,
      document_type TEXT NOT NULL,
      extracted_text TEXT,
      status TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_docs_assessment ON medical_documents(assessment_id);
    CREATE INDEX IF NOT EXISTS idx_docs_user ON medical_documents(user_id);

    CREATE TABLE IF NOT EXISTS assessment_results (
      id TEXT PRIMARY KEY,
      assessment_id TEXT UNIQUE NOT NULL,
      user_id TEXT NOT NULL,
      summary TEXT NOT NULL,
      urgency_level TEXT NOT NULL,
      urgency_reasons TEXT NOT NULL,
      identified_patterns TEXT NOT NULL,
      report_findings TEXT,
      ultrasound_status TEXT NOT NULL,
      evidence_sources TEXT NOT NULL,
      missing_information TEXT NOT NULL,
      questions_for_doctor TEXT NOT NULL,
      lifestyle_guidance TEXT,
      disclaimer TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (assessment_id) REFERENCES assessments(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_results_assessment ON assessment_results(assessment_id);

    CREATE TABLE IF NOT EXISTS menstrual_entries (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT,
      flow_intensity TEXT,
      pain_level INTEGER,
      symptoms TEXT,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_cycle_user ON menstrual_entries(user_id);
    CREATE INDEX IF NOT EXISTS idx_cycle_start ON menstrual_entries(start_date);
  `);

  // Seed demo account if not exists
  const existingDemo = db.prepare('SELECT id FROM users WHERE email = ?').get('demo.patient@uterocare.org') as { id: string } | undefined;
  if (!existingDemo) {
    // Password hash for 'UteroCareDemo2026!'
    // $2a$12$e6yqV8v8j3Yt82J1lK7yie/u4e73H9zWp9p7eYy4Xn0Hj6p3n9v2m
    const demoId = 'user_demo_001';
    const now = new Date().toISOString();
    const salt = bcrypt.genSaltSync(10);
    const hash = bcrypt.hashSync('UteroCareDemo2026!', salt);

    db.prepare(`
      INSERT INTO users (id, email, password_hash, name, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(demoId, 'demo.patient@uterocare.org', hash, 'Dr. Clara Vance (Demo)', now, now);

    // Seed sample cycle logs
    const cycle1Id = 'cycle_demo_001';
    const cycle2Id = 'cycle_demo_002';
    db.prepare(`
      INSERT INTO menstrual_entries (id, user_id, start_date, end_date, flow_intensity, pain_level, symptoms, notes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(cycle1Id, demoId, '2026-09-02', '2026-09-07', 'heavy', 6, JSON.stringify(['severe_cramps', 'clots', 'fatigue']), 'Days 2-3 heavy bleeding with clots.', now, now);

    db.prepare(`
      INSERT INTO menstrual_entries (id, user_id, start_date, end_date, flow_intensity, pain_level, symptoms, notes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(cycle2Id, demoId, '2026-09-30', '2026-10-06', 'heavy', 5, JSON.stringify(['severe_cramps', 'pelvic_heaviness']), 'Cycle length 28 days. Heavy flow.', now, now);
  }
}

// Initialize immediately on import
initDatabase();

