import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShieldCheck, AlertCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#FAF8F5] border-t border-[#E9E3DC] mt-20 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Urgent Clinical Notice Box */}
        <div className="bg-[#F5E5EC]/60 border border-[#DFC0CC] rounded-2xl p-5 mb-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-[#451E33] shrink-0 mt-0.5" />
            <div className="text-xs text-gray-700 leading-relaxed">
              <strong className="text-[#451E33]">Emergency Clinical Disclaimer:</strong> UteroCare AI is an educational clinical guidance and doctor preparation platform. It does not provide definitive medical diagnoses, prescriptions, or direct emergency triage. In case of acute severe pelvic pain, hemorrhage, or pregnancy complications, dial <strong>911</strong> or attend your nearest emergency department immediately.
            </div>
          </div>
          <Link
            to="/privacy"
            className="text-xs font-semibold text-[#451E33] hover:underline shrink-0"
          >
            Clinical Protocols & Privacy &rarr;
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-10 border-b border-[#E9E3DC]">
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#451E33] flex items-center justify-center text-white">
                <Heart className="w-4 h-4 fill-rose-200" />
              </div>
              <span className="text-lg font-bold text-[#2C141F] font-editorial">
                UteroCare AI
              </span>
            </div>
            <p className="text-xs text-gray-600 max-w-md leading-relaxed">
              Empowering women and people with uteruses through structured FIGO PALM-COEIN symptom tracking, secure clinical document parsing, and evidence-grounded consultation preparation.
            </p>
            <div className="flex items-center gap-2 text-xs text-[#5A7B57]">
              <ShieldCheck className="w-4 h-4" />
              <span>Zero third-party data sharing • Private database storage</span>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#451E33] mb-3">
              Clinical Platform
            </h4>
            <ul className="space-y-2 text-xs text-gray-600">
              <li><Link to="/assessments" className="hover:text-[#451E33]">Active Assessments</Link></li>
              <li><Link to="/cycle" className="hover:text-[#451E33]">Cycle & Symptom Tracker</Link></li>
              <li><Link to="/library" className="hover:text-[#451E33]">Conditions & FIGO Classification</Link></li>
              <li><Link to="/doctor-prep" className="hover:text-[#451E33]">Doctor Consultation Prep</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#451E33] mb-3">
              Safety & Standards
            </h4>
            <ul className="space-y-2 text-xs text-gray-600">
              <li><Link to="/privacy" className="hover:text-[#451E33]">Privacy & Security Controls</Link></li>
              <li><Link to="/settings" className="hover:text-[#451E33]">Data Export & Account Deletion</Link></li>
              <li><span className="text-gray-400">FIGO PALM-COEIN Guideline Aligned</span></li>
              <li><span className="text-gray-400">ACOG / RCOG Diagnostic Pathways</span></li>
            </ul>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-gray-500 gap-2">
          <p>© {new Date().getFullYear()} UteroCare AI. Built for evidence-based gynecological health guidance.</p>
          <div className="flex items-center gap-4">
            <Link to="/privacy" className="hover:underline">Privacy Policy</Link>
            <span>•</span>
            <Link to="/privacy" className="hover:underline">Terms of Health Guidance</Link>
          </div>
        </div>

      </div>
    </footer>
  );
};
