import React, { createContext, useContext, useState, useCallback } from 'react';
import { Assessment, SymptomData, MedicalDocument, AssessmentResult } from '../types';
import { api } from '../services/api';

interface AssessmentContextType {
  activeAssessmentId: string | null;
  activeAssessment: Assessment | null;
  symptoms: SymptomData;
  documents: MedicalDocument[];
  result: AssessmentResult | null;
  isLoading: boolean;
  saveStatus: 'idle' | 'saving' | 'saved' | 'error';
  errorMessage: string | null;
  startNewAssessment: (title?: string) => Promise<string>;
  loadAssessment: (id: string) => Promise<boolean>;
  updateSymptomField: (field: keyof SymptomData, value: any) => void;
  saveCurrentSymptoms: (symptomOverrides?: Partial<SymptomData>) => Promise<boolean>;
  uploadScanOrRecord: (file: File) => Promise<MedicalDocument>;
  removeDocument: (docId: string) => Promise<boolean>;
  triggerAnalysis: () => Promise<AssessmentResult>;
  clearActiveAssessment: () => void;
}

const AssessmentContext = createContext<AssessmentContextType | undefined>(undefined);

export const AssessmentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeAssessmentId, setActiveAssessmentId] = useState<string | null>(null);
  const [activeAssessment, setActiveAssessment] = useState<Assessment | null>(null);
  const [symptoms, setSymptoms] = useState<SymptomData>({});
  const [documents, setDocuments] = useState<MedicalDocument[]>([]);
  const [result, setResult] = useState<AssessmentResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const startNewAssessment = useCallback(async (title?: string): Promise<string> => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await api.createAssessment({ title: title || 'Uterine Health Assessment' });
      const newAssessment = res.assessment;
      setActiveAssessmentId(newAssessment.id);
      setActiveAssessment(newAssessment);
      setSymptoms({});
      setDocuments([]);
      setResult(null);
      return newAssessment.id;
    } catch (err: any) {
      const msg = err.message || 'Failed to initialize assessment';
      setErrorMessage(msg);
      throw new Error(msg);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const loadAssessment = useCallback(async (id: string): Promise<boolean> => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await api.getAssessment(id);
      setActiveAssessmentId(res.assessment.id);
      setActiveAssessment(res.assessment);
      setSymptoms(res.symptoms || {});
      setDocuments(res.documents || []);
      setResult(res.result);
      return true;
    } catch (err: any) {
      setErrorMessage(err.message || 'Unable to retrieve assessment records.');
      setActiveAssessment(null);
      setActiveAssessmentId(null);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const updateSymptomField = (field: keyof SymptomData, value: any) => {
    setSymptoms(prev => ({
      ...prev,
      [field]: value
    }));
    setSaveStatus('idle');
  };

  const saveCurrentSymptoms = async (symptomOverrides?: Partial<SymptomData>): Promise<boolean> => {
    if (!activeAssessmentId) {
      setErrorMessage('No active assessment selected.');
      return false;
    }

    setSaveStatus('saving');
    try {
      const dataToSave = {
        ...symptoms,
        ...(symptomOverrides || {})
      };
      const res = await api.saveSymptoms(activeAssessmentId, dataToSave);
      setSymptoms(res.symptoms);
      setSaveStatus('saved');
      
      // Update assessment local state if emergency flagged
      if (res.emergencyFlag && activeAssessment) {
        setActiveAssessment(prev => prev ? { ...prev, emergency_flag: 1 } : null);
      }
      return true;
    } catch (err: any) {
      setSaveStatus('error');
      setErrorMessage(err.message || 'Failed to save responses');
      return false;
    }
  };

  const uploadScanOrRecord = async (file: File): Promise<MedicalDocument> => {
    if (!activeAssessmentId) {
      throw new Error('Active assessment ID required for document upload.');
    }
    const res = await api.uploadDocument(activeAssessmentId, file);
    setDocuments(prev => [...prev, res.document]);
    return res.document;
  };

  const removeDocument = async (docId: string): Promise<boolean> => {
    if (!activeAssessmentId) return false;
    try {
      await api.deleteDocument(activeAssessmentId, docId);
      setDocuments(prev => prev.filter(d => d.id !== docId));
      return true;
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to delete document');
      return false;
    }
  };

  const triggerAnalysis = async (): Promise<AssessmentResult> => {
    if (!activeAssessmentId) {
      throw new Error('Active assessment ID required for clinical analysis.');
    }
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const res = await api.runAnalysis(activeAssessmentId);
      setResult(res.result);
      if (activeAssessment) {
        setActiveAssessment(prev => prev ? { ...prev, status: 'completed' } : null);
      }
      return res.result;
    } catch (err: any) {
      const msg = err.message || 'Analysis processing failed';
      setErrorMessage(msg);
      throw new Error(msg);
    } finally {
      setIsLoading(false);
    }
  };

  const clearActiveAssessment = () => {
    setActiveAssessmentId(null);
    setActiveAssessment(null);
    setSymptoms({});
    setDocuments([]);
    setResult(null);
    setErrorMessage(null);
    setSaveStatus('idle');
  };

  return (
    <AssessmentContext.Provider value={{
      activeAssessmentId,
      activeAssessment,
      symptoms,
      documents,
      result,
      isLoading,
      saveStatus,
      errorMessage,
      startNewAssessment,
      loadAssessment,
      updateSymptomField,
      saveCurrentSymptoms,
      uploadScanOrRecord,
      removeDocument,
      triggerAnalysis,
      clearActiveAssessment
    }}>
      {children}
    </AssessmentContext.Provider>
  );
};

export function useAssessment() {
  const context = useContext(AssessmentContext);
  if (!context) {
    throw new Error('useAssessment must be used within an AssessmentProvider');
  }
  return context;
}
