import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { z } from 'zod';
import { db } from '../database/db.ts';
import { requireAuth } from '../middleware/auth.ts';
import { generateAssessmentId } from '../security/auth.ts';
import { deleteUploadFile } from '../services/documentService.ts';

export const assessmentsRouter = Router();

// Permitted statuses
export const VALID_STATUSES = [
  'draft',
  'collecting_information',
  'ready_for_review',
  'processing',
  'completed',
  'analysis_unavailable',
  'failed',
  'cancelled'
] as const;

// GET /api/assessments - list all user assessments
assessmentsRouter.get('/', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessments = db.prepare(`
      SELECT 
        a.id, 
        a.title, 
        a.status, 
        a.current_step, 
        a.emergency_flag,
        a.created_at, 
        a.updated_at,
        (SELECT COUNT(*) FROM medical_documents d WHERE d.assessment_id = a.id) as document_count,
        (SELECT id FROM assessment_results r WHERE r.assessment_id = a.id) as result_id,
        (SELECT urgency_level FROM assessment_results r WHERE r.assessment_id = a.id) as urgency_level,
        (SELECT main_concern FROM symptom_responses s WHERE s.assessment_id = a.id) as main_concern
      FROM assessments a
      WHERE a.user_id = ?
      ORDER BY a.updated_at DESC
    `).all(userId);

    res.json({ assessments });
  } catch (err) {
    console.error('Error fetching assessments:', err);
    res.status(500).json({ error: 'Failed to retrieve assessments list.' });
  }
});

// POST /api/assessments - create a real assessment in DB
assessmentsRouter.post('/', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const title = (req.body.title || 'Uterine Health Assessment').trim();

    const assessmentId = generateAssessmentId();
    const now = new Date().toISOString();

    const createTransaction = db.transaction(() => {
      // Create assessment record
      db.prepare(`
        INSERT INTO assessments (id, user_id, title, status, current_step, emergency_flag, created_at, updated_at)
        VALUES (?, ?, ?, 'collecting_information', 1, 0, ?, ?)
      `).run(assessmentId, userId, title, now, now);

      // Create initial empty symptom record attached to this assessment
      const symptomId = crypto.randomUUID();
      db.prepare(`
        INSERT INTO symptom_responses (id, assessment_id, updated_at)
        VALUES (?, ?, ?)
      `).run(symptomId, assessmentId, now);
    });

    createTransaction();

    const created = db.prepare('SELECT * FROM assessments WHERE id = ?').get(assessmentId);

    res.status(201).json({
      assessment: created,
      message: 'Assessment initiated successfully.'
    });
  } catch (err) {
    console.error('Error creating assessment:', err);
    res.status(500).json({ error: 'Failed to initialize new assessment in database.' });
  }
});

// GET /api/assessments/:id - retrieve specific assessment with verified ownership
assessmentsRouter.get('/:id', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    const assessment = db.prepare(`
      SELECT * FROM assessments WHERE id = ? AND user_id = ?
    `).get(assessmentId, userId) as any;

    if (!assessment) {
      res.status(404).json({ error: 'Assessment not found or you do not have permission to access it.' });
      return;
    }

    const symptoms = db.prepare(`
      SELECT * FROM symptom_responses WHERE assessment_id = ?
    `).get(assessmentId);

    const documents = db.prepare(`
      SELECT id, assessment_id, filename, original_name, mime_type, size_bytes, document_type, extracted_text, status, created_at
      FROM medical_documents
      WHERE assessment_id = ?
      ORDER BY created_at ASC
    `).all(assessmentId);

    const result = db.prepare(`
      SELECT * FROM assessment_results WHERE assessment_id = ?
    `).get(assessmentId) as any;

    let parsedResult = null;
    if (result) {
      parsedResult = {
        ...result,
        urgency_reasons: JSON.parse(result.urgency_reasons || '[]'),
        identified_patterns: JSON.parse(result.identified_patterns || '[]'),
        evidence_sources: JSON.parse(result.evidence_sources || '[]'),
        missing_information: JSON.parse(result.missing_information || '[]'),
        questions_for_doctor: JSON.parse(result.questions_for_doctor || '[]'),
        lifestyle_guidance: JSON.parse(result.lifestyle_guidance || '[]'),
      };
    }

    res.json({
      assessment,
      symptoms: symptoms || {},
      documents: documents || [],
      result: parsedResult
    });
  } catch (err) {
    console.error('Error fetching assessment:', err);
    res.status(500).json({ error: 'Failed to retrieve assessment details.' });
  }
});

// PATCH /api/assessments/:id - update assessment metadata or status
assessmentsRouter.patch('/:id', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    // Verify ownership
    const existing = db.prepare('SELECT * FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId) as any;
    if (!existing) {
      res.status(404).json({ error: 'Assessment not found.' });
      return;
    }

    const { title, status, current_step, emergency_flag } = req.body;

    if (status && !VALID_STATUSES.includes(status)) {
      res.status(400).json({ error: `Invalid status '${status}'. Must be one of: ${VALID_STATUSES.join(', ')}` });
      return;
    }

    const newTitle = title !== undefined ? String(title).trim() : existing.title;
    const newStatus = status !== undefined ? status : existing.status;
    const newStep = current_step !== undefined ? Number(current_step) : existing.current_step;
    const newEmergency = emergency_flag !== undefined ? (emergency_flag ? 1 : 0) : existing.emergency_flag;
    const now = new Date().toISOString();

    db.prepare(`
      UPDATE assessments
      SET title = ?, status = ?, current_step = ?, emergency_flag = ?, updated_at = ?
      WHERE id = ? AND user_id = ?
    `).run(newTitle, newStatus, newStep, newEmergency, now, assessmentId, userId);

    const updated = db.prepare('SELECT * FROM assessments WHERE id = ?').get(assessmentId);
    res.json({ assessment: updated, message: 'Assessment updated successfully.' });
  } catch (err) {
    console.error('Error updating assessment:', err);
    res.status(500).json({ error: 'Failed to update assessment record.' });
  }
});

// DELETE /api/assessments/:id - delete assessment and its stored files
assessmentsRouter.delete('/:id', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    const existing = db.prepare('SELECT * FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId) as any;
    if (!existing) {
      res.status(404).json({ error: 'Assessment not found.' });
      return;
    }

    // Clean up physical files
    const docs = db.prepare('SELECT filename FROM medical_documents WHERE assessment_id = ?').all(assessmentId) as { filename: string }[];
    for (const doc of docs) {
      deleteUploadFile(doc.filename);
    }

    // Delete assessment (foreign keys cascade will remove symptoms, documents, and results)
    db.prepare('DELETE FROM assessments WHERE id = ? AND user_id = ?').run(assessmentId, userId);

    res.json({ success: true, message: 'Assessment and all associated records deleted permanently.' });
  } catch (err) {
    console.error('Error deleting assessment:', err);
    res.status(500).json({ error: 'Failed to delete assessment.' });
  }
});
