import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  PlusCircle, 
  ShieldCheck, 
  Calendar, 
  FileSearch, 
  Stethoscope, 
  ArrowRight, 
  CheckCircle2, 
  AlertTriangle,
  FileCheck2,
  Sparkles
} from 'lucide-react';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';
import { UterusIllustration } from '../components/UterusIllustration';
import { useAuth } from '../context/AuthContext';
import { useAssessment } from '../context/AssessmentContext';

export const Home: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const { startNewAssessment } = useAssessment();
  const [starting, setStarting] = useState(false);
  const [startError, setStartError] = useState<string | null>(null);
  const navigate = useNavigate();

  const handleStart = async () => {
    if (starting) return;
    if (authLoading) return;
    if (!user) {
      navigate('/login?redirect=start-assessment');
      return;
    }
    setStarting(true);
    setStartError(null);
    try {
      const id = await startNewAssessment();
      navigate(`/assessment/${id}`);
    } catch (err: any) {
      console.error('Failed to start assessment:', err);
      setStartError(err.message || 'Unable to initialize assessment. Please try again.');
    } finally {
      setStarting(false);
    }
  };

  return (
    <div className="space-y-20 pb-16">
      
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-8 md:pt-14 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Editorial Headline & Actions */}
            <div className="lg:col-span-7 space-y-6">
              
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#F5E5EC] border border-[#DFC0CC]/60 text-xs font-semibold text-[#451E33]">
                <Sparkles className="w-3.5 h-3.5 text-[#9B4274]" />
                <span>FIGO PALM-COEIN Aligned Clinical Guidance</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#2C141F] font-editorial leading-[1.12]">
                Clarity and clinical structure for your <span className="italic text-[#7B325B] font-medium">uterine health</span>.
              </h1>

              <p className="text-base sm:text-lg text-gray-700 max-w-2xl font-sans leading-relaxed">
                UteroCare AI bridges the gap between chronic pelvic symptoms and medical diagnosis. Complete guided symptom questionnaires, organize ultrasound scans, track menstrual patterns, and generate physician-ready clinical consultation reports.
              </p>

              {startError && (
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center justify-between">
                  <span>{startError}</span>
                  <button onClick={() => setStartError(null)} className="text-rose-600 hover:text-rose-900 font-bold ml-2 cursor-pointer">
                    ✕
                  </button>
                </div>
              )}

              {/* Primary Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <Button
                  variant="primary"
                  size="lg"
                  onClick={handleStart}
                  isLoading={starting}
                  icon={<PlusCircle className="w-5 h-5" />}
                  className="shadow-md"
                >
                  Start Clinical Assessment
                </Button>

                <Link to="/library">
                  <Button variant="outline" size="lg" className="w-full sm:w-auto" icon={<FileSearch className="w-5 h-5" />}>
                    Explore Health Library
                  </Button>
                </Link>
              </div>

              {/* Trust Indicators */}
              <div className="pt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 border-t border-[#E9E3DC]/80 text-xs text-gray-600">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0" />
                  <span>No data sold or shared</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0" />
                  <span>Transparent clinical rules</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0" />
                  <span>Doctor prep checklist</span>
                </div>
              </div>

            </div>

            {/* Right Column: 3D-Inspired Uterus Illustration */}
            <div className="lg:col-span-5 flex justify-center">
              <Card variant="white" className="p-6 md:p-8 w-full border-[#E9E3DC] shadow-md">
                <div className="text-center mb-2">
                  <span className="text-[11px] font-bold uppercase tracking-widest text-[#9B4274] bg-[#FAF2F5] px-3 py-1 rounded-full border border-[#EAC9D9]/60">
                    Interactive Anatomical Guide
                  </span>
                </div>
                <UterusIllustration />
              </Card>
            </div>

          </div>

        </div>
      </section>

      {/* EMERGENCY TRIAGE BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#FAF2F5] border border-[#EAC9D9] rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xs">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-800 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-800">
                  Patient Safety First
                </span>
                <span className="text-xs text-gray-500">• Urgent Symptoms Protocol</span>
              </div>
              <h3 className="text-lg font-bold text-[#2C141F] font-editorial">
                Experiencing severe pain, faintness, or soaking 2+ pads per hour?
              </h3>
              <p className="text-xs sm:text-sm text-gray-700 mt-1 max-w-3xl leading-relaxed">
                Certain uterine and pelvic symptoms (including sudden severe unilateral pain, acute blood loss with dizziness, or high fever with pelvic tenderness) require immediate emergency department care. Do not wait for an online assessment.
              </p>
            </div>
          </div>
          <a
            href="tel:911"
            className="shrink-0 inline-flex items-center justify-center font-medium transition-all text-xs sm:text-sm px-5 py-2.5 rounded-xl bg-rose-700 hover:bg-rose-800 text-white shadow-xs"
          >
            Emergency Guidance
          </a>
        </div>
      </section>

      {/* CORE 3-PILLAR CLINICAL WORKFLOW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="plum">Integrated Workflow</Badge>
          <h2 className="text-3xl sm:text-4xl font-bold text-[#2C141F] font-editorial mt-3">
            Designed to bring order to complex symptoms
          </h2>
          <p className="text-sm text-gray-600 mt-2">
            Every step is persisted in your private database, providing complete continuity between home symptom logging and clinical appointments.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Card 1: Guided Assessment */}
          <Card variant="white" className="flex flex-col justify-between hover:border-[#C77A9E] transition-colors">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#F5E5EC] text-[#451E33] flex items-center justify-center">
                <FileCheck2 className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#9B4274]">Pillar 1</span>
              <h3 className="text-xl font-bold text-[#2C141F] font-editorial">
                Guided Symptom Questionnaire
              </h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                Step-by-step clinical questions covering bleeding volume, dysmenorrhea severity, pelvic pressure, cycle intervals, and medication history without skipping or guessing.
              </p>
            </div>
            <div className="pt-6 border-t border-gray-100 mt-6">
              <button
                onClick={handleStart}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#451E33] hover:text-[#7B325B]"
              >
                <span>Start assessment questionnaire</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </Card>

          {/* Card 2: Upload Scans & Records */}
          <Card variant="white" className="flex flex-col justify-between hover:border-[#C77A9E] transition-colors">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#EEF3ED] text-[#5A7B57] flex items-center justify-center">
                <FileSearch className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#5A7B57]">Pillar 2</span>
              <h3 className="text-xl font-bold text-[#2C141F] font-editorial">
                Medical Records & Scans
              </h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                Securely store ultrasound images and PDF pathology reports. Extract clinical text directly and review ultrasound documentation with transparent diagnostic standards.
              </p>
            </div>
            <div className="pt-6 border-t border-gray-100 mt-6">
              <Link
                to="/assessments"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#5A7B57] hover:text-[#435E40]"
              >
                <span>Manage uploaded documents</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </Card>

          {/* Card 3: Cycle Tracking & Doctor Prep */}
          <Card variant="white" className="flex flex-col justify-between hover:border-[#C77A9E] transition-colors">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-[#FAF2F5] text-[#9B4274] flex items-center justify-center">
                <Calendar className="w-6 h-6" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#9B4274]">Pillar 3</span>
              <h3 className="text-xl font-bold text-[#2C141F] font-editorial">
                Cycle Diary & Doctor Prep
              </h3>
              <p className="text-xs text-gray-600 leading-relaxed">
                Log flow intensity and pain levels over time. Automatically synthesize your questions, missing diagnostic tests, and symptom timeline for your next gynecologist visit.
              </p>
            </div>
            <div className="pt-6 border-t border-gray-100 mt-6">
              <Link
                to="/doctor-prep"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#451E33] hover:text-[#7B325B]"
              >
                <span>View doctor preparation guide</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </Card>

        </div>
      </section>

      {/* PALM-COEIN CONDITIONS SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-3xl border border-[#E9E3DC] p-8 md:p-12 shadow-sm">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-5 space-y-4">
              <Badge variant="sage">Clinical Reference Standard</Badge>
              <h2 className="text-3xl font-bold text-[#2C141F] font-editorial">
                The FIGO PALM-COEIN System
              </h2>
              <p className="text-xs sm:text-sm text-gray-700 leading-relaxed">
                Gynecologists worldwide classify abnormal uterine bleeding through FIGO criteria. PALM encompasses structural causes visible on imaging, while COEIN classifies non-structural hormonal and coagulative disorders.
              </p>
              <div className="pt-2">
                <Link to="/library">
                  <Button variant="secondary" size="sm" icon={<FileSearch className="w-4 h-4" />}>
                    Browse Complete Condition Library
                  </Button>
                </Link>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-[#451E33] text-white flex items-center justify-center font-bold text-xs">P</span>
                  <strong className="text-xs text-[#2C141F]">Polyps (Endometrial)</strong>
                </div>
                <p className="text-[11px] text-gray-600">Localized growths of endometrial stroma causing intermenstrual or postcoital spotting.</p>
              </div>

              <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-[#451E33] text-white flex items-center justify-center font-bold text-xs">A</span>
                  <strong className="text-xs text-[#2C141F]">Adenomyosis</strong>
                </div>
                <p className="text-[11px] text-gray-600">Ectopic endometrial glands inside the myometrium causing tender enlargement and heavy cramps.</p>
              </div>

              <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-[#451E33] text-white flex items-center justify-center font-bold text-xs">L</span>
                  <strong className="text-xs text-[#2C141F]">Leiomyomas (Fibroids)</strong>
                </div>
                <p className="text-[11px] text-gray-600">Benign myometrial smooth muscle tumors causing prolonged menorrhagia and pelvic pressure.</p>
              </div>

              <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] space-y-2">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-[#451E33] text-white flex items-center justify-center font-bold text-xs">M</span>
                  <strong className="text-xs text-[#2C141F]">Malignancy & Hyperplasia</strong>
                </div>
                <p className="text-[11px] text-gray-600">Glandular proliferation driven by unopposed estrogen; critical to evaluate in postmenopausal bleeding.</p>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* CALL TO ACTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="bg-gradient-to-br from-[#451E33] to-[#2E1522] text-white rounded-3xl p-8 sm:p-14 shadow-lg space-y-6">
          <h2 className="text-3xl sm:text-4xl font-bold font-editorial">
            Take control of your gynecological health journey today
          </h2>
          <p className="text-xs sm:text-sm text-rose-100/90 max-w-xl mx-auto leading-relaxed">
            Start a confidential assessment without needing to upload records. Everything is securely stored in your private database.
          </p>
          <div className="pt-2 flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              variant="secondary"
              size="lg"
              onClick={handleStart}
              isLoading={starting}
              icon={<PlusCircle className="w-5 h-5" />}
            >
              Begin Confidential Assessment
            </Button>
            <Link to="/cycle">
              <Button variant="outline" size="lg" className="border-white/40 text-white hover:bg-white/10">
                Open Cycle Tracker
              </Button>
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
};
