import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { db } from '../database/db.ts';
import { requireAuth } from '../middleware/auth.ts';
import { runAssessmentEngine } from '../services/assessmentEngine.ts';

export const analysisRouter = Router({ mergeParams: true });

// POST /api/assessments/:id/analyze - run clinical guidance & report synthesis
analysisRouter.post('/analyze', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    // Verify ownership
    const assessment = db.prepare('SELECT * FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId) as any;
    if (!assessment) {
      res.status(404).json({ error: 'Assessment not found or unauthorized.' });
      return;
    }

    // Retrieve symptoms
    const symptoms = (db.prepare('SELECT * FROM symptom_responses WHERE assessment_id = ?').get(assessmentId) || {}) as any;

    // Retrieve documents
    const documents = db.prepare('SELECT * FROM medical_documents WHERE assessment_id = ?').all(assessmentId) as any[];

    // Check for readable extracted text from documents
    const combinedExtractedText = documents
      .map(d => d.extracted_text)
      .filter(t => Boolean(t))
      .join('\n\n');

    // Run deterministic clinical assessment engine
    const engineOutput = runAssessmentEngine(symptoms, combinedExtractedText);

    // Verify whether any ultrasound images were attached
    const hasUltrasoundImage = documents.some(d => d.document_type === 'ultrasound_image');
    let ultrasoundStatus: 'unavailable_no_trained_model' | 'completed' | 'not_provided' = 'not_provided';

    if (hasUltrasoundImage) {
      ultrasoundStatus = 'unavailable_no_trained_model';
    }

    const now = new Date().toISOString();
    const resultId = crypto.randomUUID();

    // Upsert assessment_results
    const existingResult = db.prepare('SELECT id FROM assessment_results WHERE assessment_id = ?').get(assessmentId) as any;

    if (existingResult) {
      db.prepare(`
        UPDATE assessment_results SET
          summary = ?,
          urgency_level = ?,
          urgency_reasons = ?,
          identified_patterns = ?,
          report_findings = ?,
          ultrasound_status = ?,
          evidence_sources = ?,
          missing_information = ?,
          questions_for_doctor = ?,
          lifestyle_guidance = ?,
          disclaimer = ?,
          created_at = ?
        WHERE assessment_id = ?
      `).run(
        engineOutput.summary,
        engineOutput.urgencyLevel,
        JSON.stringify(engineOutput.urgencyReasons),
        JSON.stringify(engineOutput.identifiedPatterns),
        combinedExtractedText ? JSON.stringify({ extractedLength: combinedExtractedText.length }) : null,
        ultrasoundStatus,
        JSON.stringify(engineOutput.evidenceSources),
        JSON.stringify(engineOutput.missingInformation),
        JSON.stringify(engineOutput.questionsForDoctor),
        JSON.stringify(engineOutput.lifestyleGuidance),
        engineOutput.disclaimer,
        now,
        assessmentId
      );
    } else {
      db.prepare(`
        INSERT INTO assessment_results (
          id, assessment_id, user_id, summary, urgency_level, urgency_reasons, identified_patterns, report_findings,
          ultrasound_status, evidence_sources, missing_information, questions_for_doctor, lifestyle_guidance, disclaimer, created_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        resultId,
        assessmentId,
        userId,
        engineOutput.summary,
        engineOutput.urgencyLevel,
        JSON.stringify(engineOutput.urgencyReasons),
        JSON.stringify(engineOutput.identifiedPatterns),
        combinedExtractedText ? JSON.stringify({ extractedLength: combinedExtractedText.length }) : null,
        ultrasoundStatus,
        JSON.stringify(engineOutput.evidenceSources),
        JSON.stringify(engineOutput.missingInformation),
        JSON.stringify(engineOutput.questionsForDoctor),
        JSON.stringify(engineOutput.lifestyleGuidance),
        engineOutput.disclaimer,
        now
      );
    }

    // Update assessment status to completed
    db.prepare(`
      UPDATE assessments
      SET status = 'completed', emergency_flag = ?, updated_at = ?
      WHERE id = ?
    `).run(engineOutput.urgencyLevel === 'immediate_emergency' ? 1 : 0, now, assessmentId);

    const savedResult = db.prepare('SELECT * FROM assessment_results WHERE assessment_id = ?').get(assessmentId) as any;

    res.json({
      result: {
        ...savedResult,
        urgency_reasons: JSON.parse(savedResult.urgency_reasons || '[]'),
        identified_patterns: JSON.parse(savedResult.identified_patterns || '[]'),
        evidence_sources: JSON.parse(savedResult.evidence_sources || '[]'),
        missing_information: JSON.parse(savedResult.missing_information || '[]'),
        questions_for_doctor: JSON.parse(savedResult.questions_for_doctor || '[]'),
        lifestyle_guidance: JSON.parse(savedResult.lifestyle_guidance || '[]'),
      },
      message: 'Assessment analysis completed successfully.'
    });
  } catch (err: any) {
    console.error('Error in assessment analysis:', err);
    res.status(500).json({ error: 'Failed to process assessment analysis.' });
  }
});

// GET /api/assessments/:id/results
analysisRouter.get('/results', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    const assessment = db.prepare('SELECT id FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId);
    if (!assessment) {
      res.status(404).json({ error: 'Assessment not found or unauthorized.' });
      return;
    }

    const result = db.prepare('SELECT * FROM assessment_results WHERE assessment_id = ?').get(assessmentId) as any;
    if (!result) {
      res.status(404).json({ error: 'No analysis results found for this assessment yet. Please complete the assessment.' });
      return;
    }

    res.json({
      result: {
        ...result,
        urgency_reasons: JSON.parse(result.urgency_reasons || '[]'),
        identified_patterns: JSON.parse(result.identified_patterns || '[]'),
        evidence_sources: JSON.parse(result.evidence_sources || '[]'),
        missing_information: JSON.parse(result.missing_information || '[]'),
        questions_for_doctor: JSON.parse(result.questions_for_doctor || '[]'),
        lifestyle_guidance: JSON.parse(result.lifestyle_guidance || '[]'),
      }
    });
  } catch (err) {
    console.error('Error fetching results:', err);
    res.status(500).json({ error: 'Failed to retrieve assessment results.' });
  }
});

// GET /api/assessments/:id/report - complete report
analysisRouter.get('/report', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    const assessment = db.prepare('SELECT * FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId) as any;
    if (!assessment) {
      res.status(404).json({ error: 'Assessment not found or unauthorized.' });
      return;
    }

    const symptoms = db.prepare('SELECT * FROM symptom_responses WHERE assessment_id = ?').get(assessmentId);
    const documents = db.prepare(`
      SELECT id, original_name, mime_type, size_bytes, document_type, status, extracted_text, created_at
      FROM medical_documents WHERE assessment_id = ?
    `).all(assessmentId);

    const result = db.prepare('SELECT * FROM assessment_results WHERE assessment_id = ?').get(assessmentId) as any;

    if (!result) {
      res.status(400).json({ error: 'Assessment has not been analyzed yet. Run analysis first to generate report.' });
      return;
    }

    res.json({
      report: {
        assessmentId: assessment.id,
        assessmentTitle: assessment.title,
        status: assessment.status,
        createdAt: assessment.created_at,
        patientName: req.user!.name,
        patientEmail: req.user!.email,
        symptoms: symptoms || {},
        documents: documents || [],
        summary: result.summary,
        urgencyLevel: result.urgency_level,
        urgencyReasons: JSON.parse(result.urgency_reasons || '[]'),
        identifiedPatterns: JSON.parse(result.identified_patterns || '[]'),
        ultrasoundStatus: result.ultrasound_status,
        evidenceSources: JSON.parse(result.evidence_sources || '[]'),
        missingInformation: JSON.parse(result.missing_information || '[]'),
        questionsForDoctor: JSON.parse(result.questions_for_doctor || '[]'),
        lifestyleGuidance: JSON.parse(result.lifestyle_guidance || '[]'),
        disclaimer: result.disclaimer,
      }
    });
  } catch (err) {
    console.error('Error generating report:', err);
    res.status(500).json({ error: 'Failed to generate comprehensive report.' });
  }
});
