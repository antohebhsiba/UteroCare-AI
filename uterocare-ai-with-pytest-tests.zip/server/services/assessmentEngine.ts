export interface SymptomData {
  age_range?: string;
  main_concern?: string;
  cycle_regularity?: string;
  cycle_length?: string;
  bleeding_duration?: string;
  bleeding_heaviness?: string;
  pelvic_pain_presence?: string;
  pain_severity?: number; // 0-10
  pain_location?: string;
  pain_timing?: string;
  intermenstrual_bleeding?: string;
  postcoital_bleeding?: string;
  pelvic_pressure?: string;
  urinary_bowel_symptoms?: string;
  symptom_duration?: string;
  pregnancy_possibility?: string;
  prior_diagnoses?: string;
  current_medications?: string;
  additional_notes?: string;
}

export interface ConditionInfo {
  id: string;
  name: string;
  category: 'uterine' | 'related' | 'systemic' | 'acute';
  description: string;
  typicalSymptoms: string[];
  diagnosticGoldStandards: string[];
  palmCoeinCategory?: string;
  recommendedInvestigations: string[];
  treatmentOverview: string[];
}

export interface ClinicalPatternMatch {
  conditionId: string;
  conditionName: string;
  category: 'uterine' | 'related' | 'systemic' | 'acute';
  matchingFeatures: string[];
  differentiatingFactors: string[];
  educationalNotes: string;
}

export interface EngineResult {
  summary: string;
  urgencyLevel: 'routine' | 'soon' | 'urgent' | 'immediate_emergency';
  urgencyReasons: string[];
  identifiedPatterns: ClinicalPatternMatch[];
  ultrasoundStatus: 'unavailable_no_trained_model' | 'completed' | 'not_provided';
  evidenceSources: string[];
  missingInformation: string[];
  questionsForDoctor: string[];
  lifestyleGuidance: string[];
  disclaimer: string;
}

export const CLINICAL_CONDITIONS: ConditionInfo[] = [
  {
    id: 'uterine-fibroids',
    name: 'Uterine Fibroids (Leiomyomas)',
    category: 'uterine',
    palmCoeinCategory: 'Leiomyoma (L)',
    description: 'Noncancerous growths of the myometrium (uterine muscle) classified by location: submucosal (under endometrium, causing bleeding), intramural (within muscular wall), or subserosal (projecting outward, causing pressure/bulk symptoms).',
    typicalSymptoms: [
      'Heavy menstrual bleeding (menorrhagia) often with clots',
      'Prolonged periods lasting more than 7 days',
      'Pelvic pressure, fullness, or distension',
      'Frequent urination or difficulty emptying bladder',
      'Constipation or lower back ache',
      'Iron deficiency anemia from chronic blood loss'
    ],
    diagnosticGoldStandards: ['Transvaginal pelvic ultrasound (TVS)', 'Saline infusion sonohysterography (SIS) for cavity mapping', 'Pelvic MRI for precise surgical mapping'],
    recommendedInvestigations: ['Transvaginal & transabdominal pelvic ultrasound', 'Full Blood Count (FBC/CBC) and serum ferritin', 'Iron profile'],
    treatmentOverview: [
      'Watchful waiting if asymptomatic',
      'Medical management: Tranexamic acid, hormonal contraceptives (LNG-IUD), GnRH receptor antagonists/agonists',
      'Procedural: Uterine artery embolization (UAE), MR-guided focused ultrasound',
      'Surgical: Hysteroscopic or laparoscopic myomectomy (fertility-sparing), or hysterectomy'
    ]
  },
  {
    id: 'adenomyosis',
    name: 'Adenomyosis',
    category: 'uterine',
    palmCoeinCategory: 'Adenomyosis (A)',
    description: 'A condition where the endometrial lining grows deep into the muscular wall of the uterus (myometrium), leading to an enlarged, globular, tender uterus and painful, heavy menses.',
    typicalSymptoms: [
      'Severe menstrual cramps (dysmenorrhea) worsening over time',
      'Heavy, prolonged bleeding often starting in 30s or 40s',
      'Deep dyspareunia (pelvic pain during intercourse)',
      'Chronic pelvic ache or feeling of pelvic heaviness',
      'Enlarged, tender uterus on pelvic examination'
    ],
    diagnosticGoldStandards: ['High-resolution 2D/3D transvaginal pelvic ultrasound (MUSA criteria)', 'Pelvic MRI (junctional zone thickness >= 12mm)'],
    recommendedInvestigations: ['Expert transvaginal ultrasound assessing myometrial heterogeneity and asymmetrical thickening', 'Hemoglobin and iron indices'],
    treatmentOverview: [
      'Symptomatic: NSAIDs for cramping',
      'Hormonal: Levonorgestrel intrauterine system (LNG-IUD / Mirena) — first line medical',
      'Oral progestins, combined hormonal contraceptives, or GnRH modulators',
      'Uterine-preserving interventions or hysterectomy for definitive management'
    ]
  },
  {
    id: 'endometrial-polyps',
    name: 'Endometrial Polyps',
    category: 'uterine',
    palmCoeinCategory: 'Polyp (P)',
    description: 'Localized hyperplastic overgrowths of endometrial glands and stroma forming sessile or pedunculated projections into the uterine cavity.',
    typicalSymptoms: [
      'Intermenstrual bleeding (spotting between expected menstrual periods)',
      'Postcoital bleeding or irregular light bleeding',
      'Heavy menstrual periods or prolonged spotting prior to menses',
      'Postmenopausal vaginal bleeding'
    ],
    diagnosticGoldStandards: ['Saline Infusion Sonohysterography (SIS)', 'Diagnostic and operative hysteroscopy with histopathology'],
    recommendedInvestigations: ['TVS ultrasound preferably timed in early follicular phase (days 4-7)', 'Saline sonography / SIS', 'Hysteroscopy with polypectomy'],
    treatmentOverview: [
      'Hysteroscopic polypectomy for symptomatic polyps or postmenopausal polyps',
      'Histological assessment to rule out hyperplasia or malignancy'
    ]
  },
  {
    id: 'endometrial-hyperplasia',
    name: 'Endometrial Hyperplasia',
    category: 'uterine',
    palmCoeinCategory: 'Hyperplasia / Malignancy (M)',
    description: 'Proliferation of endometrial glands leading to an increased gland-to-stroma ratio, categorized as non-atypical or atypical (endometrial intraepithelial neoplasia - EIN), driven by unopposed estrogen.',
    typicalSymptoms: [
      'Unscheduled or erratic uterine bleeding',
      'Heavy or prolonged bleeding in perimenopausal women',
      'Any postmenopausal bleeding',
      'Bleeding in women with chronic anovulation (e.g., PCOS or obesity)'
    ],
    diagnosticGoldStandards: ['Endometrial tissue biopsy (Pipelle sampling or hysteroscopic guided biopsy)'],
    recommendedInvestigations: ['Transvaginal ultrasound measuring endometrial thickness', 'Endometrial biopsy for histological evaluation'],
    treatmentOverview: [
      'Non-atypical: High-dose progestins (LNG-IUD or oral medroxyprogesterone/micronized progesterone) with surveillance biopsy at 6 months',
      'Atypical (EIN): Total hysterectomy with bilateral salpingo-oophorectomy recommended due to 30-40% concurrent malignancy risk; fertility-sparing progestin therapy under specialist gynecologic oncology surveillance only if strictly desired.'
    ]
  },
  {
    id: 'abnormal-uterine-bleeding',
    name: 'Abnormal Uterine Bleeding (AUB)',
    category: 'uterine',
    palmCoeinCategory: 'FIGO PALM-COEIN Classification',
    description: 'Bleeding from the uterine corpus that is abnormal in regularity, volume, frequency, or duration. Classified systematically into structural (PALM: Polyp, Adenomyosis, Leiomyoma, Malignancy/hyperplasia) and non-structural (COEIN: Coagulopathy, Ovulatory dysfunction, Endometrial, Iatrogenic, Not otherwise classified).',
    typicalSymptoms: [
      'Bleeding heavier than 80 mL or requiring double protection',
      'Menses lasting longer than 8 days',
      'Cycle frequency under 24 days or over 38 days',
      'Bleeding between cycles or after intercourse'
    ],
    diagnosticGoldStandards: ['FIGO PALM-COEIN workup: TVS, hormonal profile, bleeding diathesis workup, endometrial evaluation'],
    recommendedInvestigations: ['Transvaginal ultrasound', 'FBC, TSH, Prolactin, Coagulation profile', 'Pregnancy test (beta-hCG)'],
    treatmentOverview: [
      'Targeted to specific PALM or COEIN etiology',
      'Medical stabilization with antifibrinolytics (Tranexamic acid) or hormonal therapies',
      'Correction of underlying anemia and thyroid or coagulopathy issues'
    ]
  },
  {
    id: 'endometrial-cancer',
    name: 'Endometrial Cancer & Uterine Sarcoma',
    category: 'uterine',
    palmCoeinCategory: 'Malignancy (M)',
    description: 'Malignant transformation of endometrial tissue or myometrium. Most frequent in postmenopausal women or younger women with prolonged unopposed estrogen, Lynch syndrome, or high BMI.',
    typicalSymptoms: [
      'Postmenopausal vaginal bleeding (any amount, even light brown discharge)',
      'Watery or blood-tinged vaginal discharge',
      'Persistent abnormal bleeding refractory to therapy',
      'Pelvic pain or palpable pelvic mass in advanced stages'
    ],
    diagnosticGoldStandards: ['Histological examination via endometrial biopsy or hysteroscopy with fractional curettage'],
    recommendedInvestigations: ['Urgent transvaginal ultrasound (endometrial stripe > 4mm in postmenopausal women warrants urgent biopsy)', 'Endometrial histology', 'Pelvic MRI and CT staging'],
    treatmentOverview: [
      'Urgent gynecologic oncology referral',
      'Surgical staging: total hysterectomy, bilateral salpingo-oophorectomy, and sentinel lymph node assessment',
      'Adjuvant radiotherapy, chemotherapy, or immunotherapy as determined by molecular subtype'
    ]
  },
  {
    id: 'uterine-prolapse',
    name: 'Pelvic Organ & Uterine Prolapse',
    category: 'uterine',
    description: 'Descent of the uterus into the vaginal canal resulting from laxity or damage to pelvic floor muscles and supporting ligaments (uterosacral and cardinal ligaments).',
    typicalSymptoms: [
      'Sensation of a bulge or lump at the vaginal opening',
      'Pelvic heaviness, dragging sensation that worsens towards end of day or after prolonged standing',
      'Difficulty emptying bladder or bowel without manual support',
      'Lower back ache relieved by lying flat'
    ],
    diagnosticGoldStandards: ['POP-Q (Pelvic Organ Prolapse Quantification) clinical examination'],
    recommendedInvestigations: ['Bimanual and speculum pelvic examination in supine and standing/straining positions', 'Urinalysis and post-void residual'],
    treatmentOverview: [
      'Pelvic floor physical therapy (Kegel exercises with biofeedback)',
      'Vaginal pessary fitting for mechanical support',
      'Surgical repair (sacrocolpopexy, hysteropexy, or vaginal hysterectomy with apical suspension)'
    ]
  },
  {
    id: 'intrauterine-adhesions',
    name: 'Intrauterine Adhesions (Asherman Syndrome)',
    category: 'uterine',
    description: 'Fibrous scar tissue bands binding opposing endometrial walls, frequently developing after curettage, postpartum hemorrhage, pelvic infection, or hysteroscopic surgery.',
    typicalSymptoms: [
      'Noticeably light periods (hypomenorrhea) or absence of menses (amenorrhea) following an intrauterine procedure',
      'Cyclic cramping pelvic pain without visible menstrual flow (hematometra)',
      'Recurrent pregnancy loss or difficulty conceiving'
    ],
    diagnosticGoldStandards: ['Direct diagnostic hysteroscopy (gold standard) or Hysterosalpingography (HSG)'],
    recommendedInvestigations: ['Saline Infusion Sonohysterography (SIS)', 'Diagnostic hysteroscopy'],
    treatmentOverview: [
      'Hysteroscopic adhesiolysis (division of scar bands under direct vision)',
      'Temporary intrauterine stent or Foley balloon catheter with post-op estrogen-progestin therapy to regenerate endometrium'
    ]
  },
  {
    id: 'endometriosis',
    name: 'Endometriosis',
    category: 'related',
    description: 'A chronic inflammatory disease characterized by endometrium-like stroma and glands situated outside the uterine cavity (ovaries, uterosacral ligaments, pouch of Douglas, bowel, bladder).',
    typicalSymptoms: [
      'Severe, debilitating dysmenorrhea often starting days before menses',
      'Deep dyspareunia (pain during or after sex)',
      'Dyschezia (painful bowel movements during menses) or dysuria',
      'Chronic non-menstrual pelvic pain lasting > 6 months',
      'Subfertility or fatigue'
    ],
    diagnosticGoldStandards: ['Diagnostic laparoscopy with histological confirmation; specialized deep endometriosis TVS/MRI protocols'],
    recommendedInvestigations: ['Specialized "sliding sign" transvaginal ultrasound for deep infiltrating endometriosis', 'Pelvic MRI with rectal/vaginal gel protocols', 'Diagnostic laparoscopy'],
    treatmentOverview: [
      'First-line: Combined hormonal contraceptives or progestins (dienogest, LNG-IUD)',
      'GnRH antagonists (relugolix, elagolix) with add-back therapy',
      'Laparoscopic excision of endometriotic lesions and endometriomas'
    ]
  },
  {
    id: 'pcos',
    name: 'Polycystic Ovary Syndrome (PCOS)',
    category: 'related',
    description: 'An endocrine disorder characterized by chronic anovulation, hyperandrogenism, and metabolic disturbances, leading to irregular menses and endometrial thickening risk.',
    typicalSymptoms: [
      'Oligomenorrhea (fewer than 9 periods per year) or amenorrhea',
      'Hirsutism (excessive facial/body hair), persistent cystic acne, or scalp alopecia',
      'Weight changes and insulin resistance',
      'Prolonged erratic episodes of heavy breakthrough bleeding'
    ],
    diagnosticGoldStandards: ['Rotterdam Consensus Criteria: 2 of 3 (oligo/anovulation, clinical/biochemical hyperandrogenism, polycystic ovarian morphology on ultrasound)'],
    recommendedInvestigations: ['Serum total testosterone, DHEAS, SHBG, LH/FSH ratio, 17-OHP', 'Fasting glucose, HbA1c, lipid panel', 'Pelvic ultrasound'],
    treatmentOverview: [
      'Endometrial protection with cyclic progestin or combined oral contraceptive',
      'Metformin or lifestyle modifications for insulin resistance',
      'Ovulation induction (letrozole) if pregnancy desired'
    ]
  },
  {
    id: 'pelvic-infection',
    name: 'Pelvic Inflammatory Disease (PID) & Endometritis',
    category: 'acute',
    description: 'Ascending polymicrobial infection of the upper genital tract (endometrium, fallopian tubes, ovaries, and pelvic peritoneum).',
    typicalSymptoms: [
      'Bilateral lower abdominal or pelvic pain (acute or dull)',
      'Abnormal, purulent, or foul-smelling vaginal discharge',
      'Fever, chills, or systemic malaise',
      'Cervical motion tenderness or uterine tenderness on exam',
      'Postcoital or intermenstrual bleeding'
    ],
    diagnosticGoldStandards: ['Clinical triad of lower abdominal pain, cervical motion tenderness, and adnexal tenderness; confirmed by NAAT microbiology and TVS'],
    recommendedInvestigations: ['Endocervical/vaginal NAAT for Chlamydia trachomatis, Neisseria gonorrhoeae, Mycoplasma genitalium', 'High vaginal swab microscopy', 'C-reactive protein and ESR', 'Pelvic ultrasound to exclude tubo-ovarian abscess (TOA)'],
    treatmentOverview: [
      'Prompt empirical broad-spectrum antibiotic regimen (e.g., Ceftriaxone + Doxycycline + Metronidazole)',
      'Partner notification, testing, and treatment',
      'Immediate hospital admission for severe illness, pregnancy, or suspected abscess'
    ]
  }
];

export function runAssessmentEngine(symptoms: SymptomData, extractedDocText?: string): EngineResult {
  const urgencyReasons: string[] = [];
  let urgencyLevel: 'routine' | 'soon' | 'urgent' | 'immediate_emergency' = 'routine';
  const patterns: ClinicalPatternMatch[] = [];
  const missingInfo: string[] = [];
  const questions: string[] = [];
  const evidence: string[] = ['Patient-reported symptom questionnaire'];
  const lifestyle: string[] = [];

  const bleedingHeaviness = symptoms.bleeding_heaviness?.toLowerCase() || '';
  const painSeverity = Number(symptoms.pain_severity || 0);
  const ageRange = symptoms.age_range || '';
  const painPresence = symptoms.pelvic_pain_presence?.toLowerCase() || '';
  const intermenstrual = symptoms.intermenstrual_bleeding?.toLowerCase() || '';
  const postcoital = symptoms.postcoital_bleeding?.toLowerCase() || '';
  const pressure = symptoms.pelvic_pressure?.toLowerCase() || '';
  const pregnancyPossibility = symptoms.pregnancy_possibility?.toLowerCase() || '';
  const regularity = symptoms.cycle_regularity?.toLowerCase() || '';
  const duration = symptoms.symptom_duration?.toLowerCase() || '';
  const notes = (symptoms.additional_notes || '').toLowerCase();
  const mainConcern = (symptoms.main_concern || '').toLowerCase();

  // Combine text for keyword inspection
  const combinedContext = `${notes} ${mainConcern} ${symptoms.prior_diagnoses || ''}`.toLowerCase();

  // 1. SAFETY & TRIAGE CHECKS (Immediate Emergency & Urgent Red Flags)
  const isPostmenopausal = ageRange.includes('50') || ageRange.includes('55') || ageRange.includes('60') || ageRange.includes('postmenopausal');

  // RED FLAG 1: Hemorrhagic Shock / Extremely Heavy Bleeding
  if (
    bleedingHeaviness.includes('soaking') ||
    bleedingHeaviness.includes('flooding') ||
    bleedingHeaviness.includes('very_heavy') ||
    combinedContext.includes('faint') ||
    combinedContext.includes('dizzy') ||
    combinedContext.includes('lightheaded') ||
    combinedContext.includes('pale')
  ) {
    if (bleedingHeaviness.includes('very_heavy') || combinedContext.includes('faint') || combinedContext.includes('soak')) {
      urgencyLevel = 'immediate_emergency';
      urgencyReasons.push(
        'Extremely heavy bleeding reported (e.g. soaking 2+ pads/tampons per hour, flooding, or accompanying dizziness/faintness) requires immediate clinical or emergency room assessment to prevent or manage severe anemia and hypovolemia.'
      );
    }
  }

  // RED FLAG 2: Acute pelvic pain with possible pregnancy (Ectopic risk)
  if (
    (pregnancyPossibility === 'yes' || pregnancyPossibility === 'possible' || combinedContext.includes('positive test')) &&
    (painSeverity >= 6 || painPresence === 'yes' || intermenstrual === 'yes' || bleedingHeaviness.length > 0)
  ) {
    urgencyLevel = 'immediate_emergency';
    urgencyReasons.push(
      'Possible pregnancy accompanied by pelvic pain and/or vaginal bleeding is an immediate emergency until ectopic pregnancy is definitively ruled out by a medical professional.'
    );
  }

  // RED FLAG 3: Severe acute pain (9-10/10) with fever or peritoneal signs
  if (painSeverity >= 9 || (combinedContext.includes('fever') && painPresence === 'yes')) {
    if (urgencyLevel !== 'immediate_emergency') {
      urgencyLevel = 'urgent';
    }
    urgencyReasons.push(
      `Severe pelvic pain (Severity ${painSeverity}/10) or fever requires prompt medical examination to rule out ovarian torsion, pelvic abscess (TOA), or acute pelvic infection.`
    );
  }

  // RED FLAG 4: Postmenopausal bleeding
  if (isPostmenopausal && (bleedingHeaviness.length > 0 || intermenstrual === 'yes' || postcoital === 'yes')) {
    if (urgencyLevel === 'routine') {
      urgencyLevel = 'urgent';
    }
    urgencyReasons.push(
      'Any vaginal bleeding in a postmenopausal woman warrants an urgent clinical referral (typically within 2 weeks) with transvaginal ultrasound and endometrial biopsy to rule out endometrial hyperplasia or malignancy.'
    );
  }

  // Moderate urgency: persistent postcoital bleeding or chronic severe pain
  if (postcoital === 'yes' && urgencyLevel === 'routine') {
    urgencyLevel = 'soon';
    urgencyReasons.push('Postcoital bleeding requires timely cervical visualization (speculum examination) and high-risk HPV/cervical screening.');
  }

  // 2. PATTERN RECOGNITION (Educational Guidance Based on Clinical Criteria)

  // Pattern A: Uterine Fibroids
  if (
    (bleedingHeaviness.includes('heavy') || bleedingHeaviness.includes('very_heavy')) &&
    (pressure === 'yes' || combinedContext.includes('bulk') || combinedContext.includes('urinary') || painSeverity >= 4)
  ) {
    patterns.push({
      conditionId: 'uterine-fibroids',
      conditionName: 'Uterine Fibroids (Leiomyomas)',
      category: 'uterine',
      matchingFeatures: [
        bleedingHeaviness ? `Heavy bleeding profile: ${symptoms.bleeding_heaviness}` : 'Menorrhagia',
        pressure === 'yes' ? 'Pelvic pressure, heaviness, or bladder fullness' : 'Bulk symptoms'
      ],
      differentiatingFactors: [
        'Confirmed definitively by pelvic transvaginal ultrasound demonstrating circumscribed myometrial masses',
        'Submucosal fibroids specifically cause significant bleeding, whereas subserosal fibroids mainly cause pressure'
      ],
      educationalNotes: 'Fibroids are benign monoclonal smooth muscle tumors found in up to 70% of reproductive-age individuals. Location and size dictate whether medical or surgical options are suitable.'
    });
  }

  // Pattern B: Adenomyosis
  if (
    (painPresence === 'yes' && painSeverity >= 5) &&
    (bleedingHeaviness.includes('heavy') || bleedingHeaviness.includes('moderate'))
  ) {
    patterns.push({
      conditionId: 'adenomyosis',
      conditionName: 'Adenomyosis',
      category: 'uterine',
      matchingFeatures: [
        `Marked dysmenorrhea (Pain severity: ${painSeverity}/10)`,
        'Heavy menstrual flow co-occurring with deep cramping'
      ],
      differentiatingFactors: [
        'Often presents as a globally enlarged, tender ("boggy") uterus during examination',
        'High-resolution ultrasound (MUSA criteria) or pelvic MRI showing junctional zone thickening provides diagnostic imaging'
      ],
      educationalNotes: 'Endometrial glands penetrate into the muscular uterine wall, leading to inflammation and heavy cramping. The levonorgestrel IUD or progestin therapy is frequently very effective.'
    });
  }

  // Pattern C: Endometrial Polyps
  if (intermenstrual === 'yes' || postcoital === 'yes' || (regularity === 'regular' && intermenstrual === 'yes')) {
    patterns.push({
      conditionId: 'endometrial-polyps',
      conditionName: 'Endometrial Polyps',
      category: 'uterine',
      matchingFeatures: [
        intermenstrual === 'yes' ? 'Intermenstrual spotting between regular cycles' : 'Unscheduled bleeding',
        postcoital === 'yes' ? 'Bleeding triggered after intercourse' : 'Light irregular flow'
      ],
      differentiatingFactors: [
        'Best visualized by saline infusion sonohysterography (SIS) or office hysteroscopy rather than standard 2D ultrasound',
        'Most polyps are benign, but histological removal is standard practice when symptomatic'
      ],
      educationalNotes: 'Polyps are fleshy growths of endometrial stroma. Removing them through a minimally invasive hysteroscopy typically resolves unscheduled spotting.'
    });
  }

  // Pattern D: Endometriosis
  if (
    (painPresence === 'yes' && painSeverity >= 6) ||
    symptoms.urinary_bowel_symptoms === 'yes' ||
    combinedContext.includes('dyschezia') ||
    combinedContext.includes('dyspareunia')
  ) {
    patterns.push({
      conditionId: 'endometriosis',
      conditionName: 'Endometriosis',
      category: 'related',
      matchingFeatures: [
        `Intense cyclic or acyclic pelvic pain (Severity: ${painSeverity}/10)`,
        symptoms.urinary_bowel_symptoms === 'yes' ? 'Associated bladder or bowel symptoms during menses' : 'Multisystem pelvic pain'
      ],
      differentiatingFactors: [
        'Endometrial-like tissue located outside the uterus (e.g. ovaries, pouch of Douglas)',
        'Routine ultrasound may miss superficial peritoneal disease; specialized deep endometriosis scans or laparoscopy are required'
      ],
      educationalNotes: 'Endometriosis is an estrogen-dependent chronic inflammatory state. Pain management involves hormonal suppression (progestins, combined contraceptives) and multidisciplinary pain care.'
    });
  }

  // Pattern E: PCOS / Anovulatory Bleeding
  if (regularity.includes('irregular') || regularity.includes('infrequent') || regularity.includes('absent')) {
    patterns.push({
      conditionId: 'pcos',
      conditionName: 'Polycystic Ovary Syndrome (PCOS) / Ovulatory Dysfunction',
      category: 'related',
      matchingFeatures: [
        `Irregular or infrequent menstrual cycles (${symptoms.cycle_regularity || 'oligomenorrhea'})`,
        symptoms.cycle_length ? `Reported cycle length: ${symptoms.cycle_length}` : 'Unpredictable cycle intervals'
      ],
      differentiatingFactors: [
        'Defined clinically by Rotterdam criteria (infrequent ovulation + clinical/biochemical androgen excess)',
        'Requires exclusion of thyroid disease, hyperprolactinemia, and congenital adrenal hyperplasia'
      ],
      educationalNotes: 'Irregular ovulation allows the uterine lining to build without regular progestin shedding, increasing the risk of sudden heavy flooding and endometrial hyperplasia if untreated.'
    });
  }

  // Pattern F: Pelvic Organ Prolapse
  if (pressure === 'yes' && (symptoms.urinary_bowel_symptoms === 'yes' || combinedContext.includes('bulge') || combinedContext.includes('heaviness'))) {
    patterns.push({
      conditionId: 'uterine-prolapse',
      conditionName: 'Pelvic Organ & Uterine Prolapse',
      category: 'uterine',
      matchingFeatures: [
        'Sensation of pelvic fullness, downward pressure, or dragging',
        'Associated urinary or defecatory strain'
      ],
      differentiatingFactors: [
        'Evaluated objectively via physical examination (POP-Q staging) rather than imaging',
        'Non-surgical management with pelvic floor physiotherapy and pessary support provides substantial relief'
      ],
      educationalNotes: 'Weakened pelvic fascial support allows the uterus or vaginal walls to descend, especially after vaginal childbirth, chronic coughing, or heavy lifting.'
    });
  }

  // Fallback if no specific pattern matched
  if (patterns.length === 0) {
    patterns.push({
      conditionId: 'abnormal-uterine-bleeding',
      conditionName: 'Abnormal Uterine Bleeding Evaluation (FIGO PALM-COEIN)',
      category: 'uterine',
      matchingFeatures: [
        symptoms.main_concern || 'Reported gynecological concern',
        `Reported symptom duration: ${duration || 'Ongoing'}`
      ],
      differentiatingFactors: [
        'Requires structural imaging (ultrasound) alongside systemic blood investigations (FBC, ferritin, coagulation profile)'
      ],
      educationalNotes: 'The FIGO PALM-COEIN classification separates structural causes (polyp, adenomyosis, leiomyoma, malignancy) from non-structural causes (coagulopathy, ovulatory, endometrial, iatrogenic).'
    });
  }

  // 3. DOCUMENT REVIEW AND EXTRACTED FINDINGS
  if (extractedDocText && extractedDocText.trim().length > 0) {
    evidence.push('Uploaded clinical record / medical report text extraction');
    // If text contains mention of thickness, fibroid, or polyp
    const textLower = extractedDocText.toLowerCase();
    if (textLower.includes('endometrial thickness') || textLower.includes('stripe')) {
      evidence.push('Document notes endometrial stripe thickness measurement');
    }
    if (textLower.includes('leiomyoma') || textLower.includes('fibroid')) {
      evidence.push('Document notes uterine leiomyoma/fibroid presence');
    }
  }

  // 4. MISSING INFORMATION & UNCERTAINTIES
  if (!symptoms.cycle_length || symptoms.cycle_length === "I don't know") {
    missingInfo.push('Precise menstrual cycle length (days from start of one bleed to start of next)');
  }
  if (!symptoms.prior_diagnoses) {
    missingInfo.push('Complete history of prior pelvic ultrasounds or gynecological procedures');
  }
  if (!extractedDocText) {
    missingInfo.push('Recent pelvic transvaginal ultrasound (TVS) or sonohysterography imaging report');
  }
  if (!symptoms.current_medications) {
    missingInfo.push('Current medication list (specifically anticoagulants, hormonal contraceptives, or NSAIDs)');
  }

  // 5. TAILORED QUESTIONS FOR HEALTHCARE PROVIDER
  questions.push('Would a transvaginal pelvic ultrasound (TVS) timed during the early follicular phase be helpful for clarifying my uterine anatomy?');
  if (bleedingHeaviness.includes('heavy') || bleedingHeaviness.includes('very_heavy')) {
    questions.push('Should we test my Full Blood Count (FBC) and serum ferritin to evaluate for iron-deficiency anemia from heavy blood loss?');
    questions.push('What medical options (such as tranexamic acid, hormonal IUD, or oral progestins) are appropriate for controlling bleeding volume?');
  }
  if (painPresence === 'yes') {
    questions.push('What targeted pain relief or hormonal suppression strategy is recommended to reduce inflammation and pelvic cramping?');
  }
  if (isPostmenopausal) {
    questions.push('Given postmenopausal symptoms, what is my endometrial stripe thickness and is an endometrial Pipelle biopsy indicated?');
  }
  if (intermenstrual === 'yes' || postcoital === 'yes') {
    questions.push('Could we inspect the cervix and consider a saline infusion sonohysterogram (SIS) or hysteroscopy to rule out polyps?');
  }

  // 6. LIFESTYLE & SUPPORTIVE GUIDANCE
  lifestyle.push('Keep a detailed cycle & symptom log (dates, pad/tampon count per day, pain score 1-10) to share with your gynecologist.');
  if (bleedingHeaviness.includes('heavy')) {
    lifestyle.push('Support red blood cell synthesis with dietary iron (lean meats, leafy greens, legumes) paired with Vitamin C to enhance absorption.');
  }
  if (painPresence === 'yes') {
    lifestyle.push('Apply gentle local warmth (heat pack) to the lower pelvis to decrease myometrial muscle spasm.');
  }

  // 7. SUMMARY
  let summary = `Clinical assessment based on reported symptoms (${symptoms.main_concern || 'uterine health inquiry'}) `;
  summary += `for an individual in the ${ageRange || 'reproductive'} age range. `;
  if (urgencyLevel === 'immediate_emergency' || urgencyLevel === 'urgent') {
    summary += `Priority triage indicates ${urgencyLevel.replace('_', ' ').toUpperCase()} attention is warranted due to identified clinical risks. `;
  } else {
    summary += `Symptoms align with patterns that benefit from planned outpatient gynecological review. `;
  }
  summary += `${patterns.length} diagnostic pattern(s) identified for discussion with a qualified clinician.`;

  return {
    summary,
    urgencyLevel,
    urgencyReasons,
    identifiedPatterns: patterns,
    ultrasoundStatus: 'unavailable_no_trained_model',
    evidenceSources: evidence,
    missingInformation: missingInfo,
    questionsForDoctor: questions,
    lifestyleGuidance: lifestyle,
    disclaimer: 'This assessment is an educational clinical guidance tool and does NOT provide a definitive medical diagnosis, prescription, or clinical treatment. Medical ultrasound and pathology require review by licensed healthcare professionals. In an emergency, contact emergency medical services immediately.'
  };
}
