import React, { useEffect, useState } from 'react';
import { 
  BookOpen, 
  Search, 
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api';
import { ConditionInfo } from '../types';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';

export const HealthLibrary: React.FC = () => {
  const [conditions, setConditions] = useState<ConditionInfo[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'uterine' | 'related' | 'acute'>('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadConditions() {
      try {
        const res = await api.getConditions();
        setConditions(res.conditions);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadConditions();
  }, []);

  const filtered = conditions.filter(c => {
    const matchesCat = selectedCategory === 'all' || c.category === selectedCategory;
    const matchesSearch = 
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.description.toLowerCase().includes(search.toLowerCase()) ||
      (c.palmCoeinCategory && c.palmCoeinCategory.toLowerCase().includes(search.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <Badge variant="plum">Clinical Knowledge Base</Badge>
        <h1 className="text-3xl sm:text-4xl font-bold text-[#2C141F] font-editorial">
          Gynecological & Uterine Health Library
        </h1>
        <p className="text-xs sm:text-sm text-gray-600 leading-relaxed">
          Grounded in the International Federation of Gynecology and Obstetrics (FIGO) PALM-COEIN classification system, ACOG clinical bulletins, and RCOG guidelines.
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full sm:w-96">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search conditions, symptoms, or FIGO categories..."
            className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#E9E3DC] bg-white text-xs text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#451E33]/20"
          />
        </div>

        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-white border border-[#E9E3DC] self-stretch sm:self-auto justify-center">
          {[
            { id: 'all', label: 'All Conditions' },
            { id: 'uterine', label: 'Primary Uterine' },
            { id: 'related', label: 'Related Endocrine' },
            { id: 'acute', label: 'Acute / Infectious' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                selectedCategory === cat.id
                  ? 'bg-[#451E33] text-white shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-48 rounded-2xl bg-white border border-[#E9E3DC] animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card variant="white" className="text-center py-12">
          <p className="text-xs text-gray-500">No conditions match your search query.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((item) => {
            const isExpanded = expandedId === item.id;
            return (
              <Card
                key={item.id}
                variant="white"
                className={`p-6 transition-all duration-200 border-[#E9E3DC] ${isExpanded ? 'ring-2 ring-[#451E33]/20 border-[#451E33]' : 'hover:border-[#C77A9E]'}`}
              >
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    {item.palmCoeinCategory && (
                      <span className="text-[10px] font-bold uppercase tracking-widest text-[#9B4274] bg-[#FAF2F5] px-2.5 py-0.5 rounded-full border border-[#EAC9D9]/60 inline-block mb-1">
                        {item.palmCoeinCategory}
                      </span>
                    )}
                    <h3 className="text-lg font-bold text-[#2C141F] font-editorial">
                      {item.name}
                    </h3>
                  </div>

                  <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-[#FAF8F5] text-gray-600 border border-[#E9E3DC]">
                    {item.category}
                  </span>
                </div>

                <p className="text-xs text-gray-700 leading-relaxed mb-4">
                  {item.description}
                </p>

                <div className="space-y-1.5 mb-4">
                  <strong className="text-[11px] uppercase tracking-wide text-gray-400 block font-semibold">
                    Hallmark Clinical Symptoms:
                  </strong>
                  <ul className="text-xs text-gray-700 space-y-1">
                    {item.typicalSymptoms.slice(0, isExpanded ? undefined : 3).map((sym, sIdx) => (
                      <li key={sIdx} className="flex items-start gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#7B325B] shrink-0 mt-1.5" />
                        <span className="leading-snug">{sym}</span>
                      </li>
                    ))}
                    {!isExpanded && item.typicalSymptoms.length > 3 && (
                      <li className="text-[11px] text-gray-400 italic pl-3.5">
                        +{item.typicalSymptoms.length - 3} more symptoms...
                      </li>
                    )}
                  </ul>
                </div>

                {isExpanded && (
                  <div className="space-y-4 pt-4 border-t border-gray-100 text-xs text-gray-700 animate-in fade-in duration-150">
                    <div>
                      <strong className="text-[11px] uppercase tracking-wide text-[#451E33] block font-semibold mb-1">
                        Diagnostic Gold Standards:
                      </strong>
                      <ul className="list-disc list-inside space-y-0.5 text-gray-600">
                        {item.diagnosticGoldStandards.map((d, dIdx) => (
                          <li key={dIdx}>{d}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <strong className="text-[11px] uppercase tracking-wide text-[#5A7B57] block font-semibold mb-1">
                        Recommended Clinical Investigations:
                      </strong>
                      <ul className="list-disc list-inside space-y-0.5 text-gray-600">
                        {item.recommendedInvestigations.map((inv, iIdx) => (
                          <li key={iIdx}>{inv}</li>
                        ))}
                      </ul>
                    </div>

                    <div>
                      <strong className="text-[11px] uppercase tracking-wide text-[#7B325B] block font-semibold mb-1">
                        Standard Management & Treatment:
                      </strong>
                      <ul className="list-disc list-inside space-y-0.5 text-gray-600">
                        {item.treatmentOverview.map((t, tIdx) => (
                          <li key={tIdx}>{t}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}

                <div className="pt-4 border-t border-gray-100 mt-4 flex justify-end">
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : item.id)}
                    className="text-xs font-semibold text-[#451E33] hover:text-[#7B325B] inline-flex items-center gap-1"
                  >
                    <span>{isExpanded ? 'Show Less' : 'Full Clinical Workup'}</span>
                    <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

    </div>
  );
};
