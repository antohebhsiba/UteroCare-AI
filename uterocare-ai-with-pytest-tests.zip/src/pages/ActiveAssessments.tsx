import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  PlusCircle, 
  Trash2, 
  ArrowRight, 
  FileText, 
  Clock, 
  Calendar, 
  AlertTriangle, 
  Sparkles,
  ClipboardList,
  CheckCircle2,
  FileSearch,
  Upload
} from 'lucide-react';
import { Assessment } from '../types';
import { api } from '../services/api';
import { useAssessment } from '../context/AssessmentContext';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';

export const ActiveAssessments: React.FC = () => {
  const { startNewAssessment } = useAssessment();
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);
  const navigate = useNavigate();

  const fetchAssessments = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.getAssessments();
      setAssessments(res.assessments);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve assessment records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAssessments();
  }, []);

  const handleStartNew = async () => {
    if (starting) return;
    setStarting(true);
    setError(null);
    try {
      const id = await startNewAssessment();
      navigate(`/assessment/${id}`);
    } catch (err: any) {
      setError(err.message || 'Failed to initialize assessment.');
    } finally {
      setStarting(false);
    }
  };

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await api.deleteAssessment(id);
      setAssessments(prev => prev.filter(a => a.id !== id));
      setConfirmDeleteId(null);
    } catch (err: any) {
      setError(err.message || 'Failed to delete assessment.');
    } finally {
      setDeletingId(null);
    }
  };

  const getStatusBadge = (status: string, emergencyFlag?: number) => {
    if (emergencyFlag === 1) {
      return <Badge variant="emergency">Urgent Clinical Flag</Badge>;
    }
    switch (status) {
      case 'completed':
        return <Badge variant="completed">Analysis Complete</Badge>;
      case 'processing':
        return <Badge variant="soon">Processing</Badge>;
      case 'collecting_information':
        return <Badge variant="draft">In Progress</Badge>;
      case 'ready_for_review':
        return <Badge variant="routine">Ready for Analysis</Badge>;
      default:
        return <Badge variant="draft">Draft</Badge>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E9E3DC]">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#9B4274]">
              Assessment Registry
            </span>
            <span className="text-xs text-gray-400">• Private Records</span>
          </div>
          <h1 className="text-3xl font-bold text-[#2C141F] font-editorial mt-1">
            My Uterine Health Assessments
          </h1>
          <p className="text-xs sm:text-sm text-gray-600 mt-1">
            Track, resume in-progress questionnaires, upload medical documents, and view clinical reports.
          </p>
        </div>

        <Button
          variant="primary"
          size="md"
          onClick={handleStartNew}
          isLoading={starting}
          icon={<PlusCircle className="w-4 h-4" />}
        >
          Start New Assessment
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-3">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Content */}
      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 rounded-2xl bg-white border border-[#E9E3DC] animate-pulse p-6" />
          ))}
        </div>
      ) : assessments.length === 0 ? (
        <Card variant="white" className="text-center py-16 px-6 border-dashed border-[#DFC0CC]">
          <div className="w-16 h-16 rounded-3xl bg-[#FAF2F5] text-[#9B4274] flex items-center justify-center mx-auto mb-4 border border-[#EAC9D9]/50">
            <ClipboardList className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-[#2C141F] font-editorial">
            No Assessments Created Yet
          </h3>
          <p className="text-xs text-gray-600 max-w-md mx-auto mt-2 leading-relaxed">
            Begin your first confidential evaluation. You will be guided through bleeding patterns, pelvic pain, and cycle symptoms step-by-step.
          </p>
          <div className="mt-6">
            <Button
              variant="primary"
              size="md"
              onClick={handleStartNew}
              isLoading={starting}
              icon={<PlusCircle className="w-4 h-4" />}
            >
              Start First Assessment
            </Button>
          </div>
        </Card>
      ) : (
        <div className="space-y-4">
          {assessments.map((item) => (
            <Card
              key={item.id}
              variant="white"
              className="hover:border-[#C77A9E] transition-all duration-200 p-6 flex flex-col md:flex-row md:items-center justify-between gap-6"
            >
              {/* Left detail info */}
              <div className="space-y-2 flex-1">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-[#FAF2F5] text-[#451E33] border border-[#EAC9D9]">
                    {item.id}
                  </span>
                  {getStatusBadge(item.status, item.emergency_flag)}
                </div>

                <h3 className="text-lg font-bold text-[#2C141F] font-editorial">
                  {item.title}
                </h3>

                {item.main_concern && (
                  <p className="text-xs text-gray-700 font-sans italic line-clamp-1">
                    "{item.main_concern}"
                  </p>
                )}

                <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500 pt-1">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Created: {new Date(item.created_at).toLocaleDateString()}</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Updated: {new Date(item.updated_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </span>
                  {item.document_count !== undefined && item.document_count > 0 && (
                    <span className="flex items-center gap-1 text-[#5A7B57] font-medium">
                      <FileText className="w-3.5 h-3.5" />
                      <span>{item.document_count} file(s) attached</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Right action buttons */}
              <div className="flex flex-wrap items-center gap-2.5 pt-3 md:pt-0 border-t md:border-t-0 border-gray-100">
                {/* Uploads link */}
                <Link to={`/assessment/${item.id}/uploads`}>
                  <Button variant="outline" size="sm" icon={<Upload className="w-3.5 h-3.5" />}>
                    Scans & Records
                  </Button>
                </Link>

                {/* If completed, view report; otherwise resume */}
                {item.status === 'completed' ? (
                  <Link to={`/assessment/${item.id}/results`}>
                    <Button variant="primary" size="sm" icon={<FileSearch className="w-3.5 h-3.5" />}>
                      View Results & Report
                    </Button>
                  </Link>
                ) : (
                  <Link to={`/assessment/${item.id}`}>
                    <Button variant="primary" size="sm" icon={<ArrowRight className="w-3.5 h-3.5" />}>
                      Resume Questionnaire
                    </Button>
                  </Link>
                )}

                {/* Delete button or confirmation */}
                {confirmDeleteId === item.id ? (
                  <div className="flex items-center gap-1.5 p-1 rounded-xl bg-rose-50 border border-rose-200">
                    <button
                      onClick={() => handleDelete(item.id)}
                      disabled={deletingId === item.id}
                      className="text-xs px-2.5 py-1 rounded-lg bg-rose-700 text-white font-medium hover:bg-rose-800"
                    >
                      {deletingId === item.id ? 'Deleting...' : 'Confirm'}
                    </button>
                    <button
                      onClick={() => setConfirmDeleteId(null)}
                      className="text-xs px-2 py-1 text-gray-600 hover:text-gray-900"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setConfirmDeleteId(item.id)}
                    className="p-2 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                    title="Delete assessment"
                    aria-label={`Delete assessment ${item.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

            </Card>
          ))}
        </div>
      )}

    </div>
  );
};
