import React, { useState } from 'react';

export const UterusIllustration: React.FC<{ className?: string }> = ({ className = '' }) => {
  const [activeZone, setActiveZone] = useState<string | null>(null);

  const zones: Record<string, { title: string; desc: string }> = {
    fundus: {
      title: 'Uterine Fundus',
      desc: 'The broad, curved upper zone of the uterus above the fallopian tube insertion points.',
    },
    endometrium: {
      title: 'Endometrial Lining',
      desc: 'The hormone-responsive mucous membrane that thickens during the menstrual cycle and sheds during menses; origin of polyps and hyperplasia.',
    },
    myometrium: {
      title: 'Myometrium',
      desc: 'The thick muscular middle layer of smooth muscle tissue; origin of leiomyomas (fibroids) and adenomyosis infiltration.',
    },
    fallopian: {
      title: 'Fallopian Tube & Fimbriae',
      desc: 'Ciliated conduit connecting ovaries to the uterine cavity, facilitating ovum transport and fertilization.',
    },
    ovary: {
      title: 'Ovary',
      desc: 'Paired female gonad responsible for oocyte maturation and production of estrogen and progesterone hormones.',
    },
    cervix: {
      title: 'Cervical Canal & Os',
      desc: 'The cylindrical lower anatomical neck of the uterus communicating between the uterine cavity and the vagina.',
    },
  };

  return (
    <div className={`relative flex flex-col items-center select-none ${className}`}>
      {/* 3D-Inspired SVG Anatomy Illustration */}
      <svg
        viewBox="0 0 600 500"
        className="w-full max-w-[500px] h-auto drop-shadow-xl"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Gradients for depth and 3D volume */}
          <linearGradient id="myometriumGrad" x1="300" y1="120" x2="300" y2="420" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#7B325B" />
            <stop offset="45%" stopColor="#5E2645" />
            <stop offset="85%" stopColor="#451E33" />
            <stop offset="100%" stopColor="#2E1522" />
          </linearGradient>

          <radialGradient id="fundusHighlight" cx="300" cy="160" r="140" fx="280" fy="140" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#C77A9E" stopOpacity="0.85" />
            <stop offset="60%" stopColor="#7B325B" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#451E33" stopOpacity="0" />
          </radialGradient>

          <linearGradient id="endometriumGrad" x1="300" y1="170" x2="300" y2="350" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#F5E5EC" />
            <stop offset="30%" stopColor="#EAC9D9" />
            <stop offset="70%" stopColor="#DDA6BF" />
            <stop offset="100%" stopColor="#C77A9E" />
          </linearGradient>

          <linearGradient id="tubeLeft" x1="160" y1="170" x2="260" y2="160" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#C77A9E" />
            <stop offset="50%" stopColor="#7B325B" />
            <stop offset="100%" stopColor="#451E33" />
          </linearGradient>

          <linearGradient id="tubeRight" x1="440" y1="170" x2="340" y2="160" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#C77A9E" />
            <stop offset="50%" stopColor="#7B325B" />
            <stop offset="100%" stopColor="#451E33" />
          </linearGradient>

          <radialGradient id="ovaryLeftGrad" cx="125" cy="185" r="35" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FAF2F5" />
            <stop offset="60%" stopColor="#EAC9D9" />
            <stop offset="100%" stopColor="#B8CCA5" />
          </radialGradient>

          <radialGradient id="ovaryRightGrad" cx="475" cy="185" r="35" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FAF2F5" />
            <stop offset="60%" stopColor="#EAC9D9" />
            <stop offset="100%" stopColor="#B8CCA5" />
          </radialGradient>

          <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Ambient background glow ring */}
        <circle cx="300" cy="240" r="180" fill="#FAF2F5" fillOpacity="0.6" filter="url(#softGlow)" />
        <ellipse cx="300" cy="410" rx="140" ry="22" fill="#E9E3DC" fillOpacity="0.5" />

        {/* Left Fallopian Tube with graceful sweep */}
        <path
          d="M 260 180 C 220 145, 160 130, 115 165 C 100 178, 105 195, 120 190 C 130 185, 155 170, 200 175 C 235 180, 255 195, 260 200"
          stroke="url(#tubeLeft)"
          strokeWidth="14"
          strokeLinecap="round"
          className="transition-all duration-300 cursor-pointer hover:stroke-[#C77A9E]"
          onMouseEnter={() => setActiveZone('fallopian')}
          onMouseLeave={() => setActiveZone(null)}
        />
        {/* Left Fimbriae */}
        <path d="M 108 172 Q 95 165 98 180 Q 104 188 116 182" fill="#9B4274" />
        <path d="M 112 165 Q 105 152 118 160" stroke="#9B4274" strokeWidth="3" />

        {/* Right Fallopian Tube */}
        <path
          d="M 340 180 C 380 145, 440 130, 485 165 C 500 178, 495 195, 480 190 C 470 185, 445 170, 400 175 C 365 180, 345 195, 340 200"
          stroke="url(#tubeRight)"
          strokeWidth="14"
          strokeLinecap="round"
          className="transition-all duration-300 cursor-pointer hover:stroke-[#C77A9E]"
          onMouseEnter={() => setActiveZone('fallopian')}
          onMouseLeave={() => setActiveZone(null)}
        />
        {/* Right Fimbriae */}
        <path d="M 492 172 Q 505 165 502 180 Q 496 188 484 182" fill="#9B4274" />
        <path d="M 488 165 Q 495 152 482 160" stroke="#9B4274" strokeWidth="3" />

        {/* Left Ovary & Ligament */}
        <path d="M 235 220 C 190 220, 150 205, 130 195" stroke="#B8CCA5" strokeWidth="4" strokeDasharray="3 3" />
        <g
          className="cursor-pointer transition-transform duration-300 hover:scale-105"
          onMouseEnter={() => setActiveZone('ovary')}
          onMouseLeave={() => setActiveZone(null)}
        >
          <ellipse cx="125" cy="190" rx="26" ry="18" transform="rotate(-15 125 190)" fill="url(#ovaryLeftGrad)" stroke="#B8CCA5" strokeWidth="2.5" />
          <circle cx="120" cy="186" r="4" fill="#FAF8F5" fillOpacity="0.8" />
          <circle cx="132" cy="192" r="3.5" fill="#FAF8F5" fillOpacity="0.6" />
        </g>

        {/* Right Ovary & Ligament */}
        <path d="M 365 220 C 410 220, 450 205, 470 195" stroke="#B8CCA5" strokeWidth="4" strokeDasharray="3 3" />
        <g
          className="cursor-pointer transition-transform duration-300 hover:scale-105"
          onMouseEnter={() => setActiveZone('ovary')}
          onMouseLeave={() => setActiveZone(null)}
        >
          <ellipse cx="475" cy="190" rx="26" ry="18" transform="rotate(15 475 190)" fill="url(#ovaryRightGrad)" stroke="#B8CCA5" strokeWidth="2.5" />
          <circle cx="480" cy="186" r="4" fill="#FAF8F5" fillOpacity="0.8" />
          <circle cx="468" cy="192" r="3.5" fill="#FAF8F5" fillOpacity="0.6" />
        </g>

        {/* Main Uterus Body (Myometrium with 3D contours) */}
        <g
          className="cursor-pointer"
          onMouseEnter={() => setActiveZone('myometrium')}
          onMouseLeave={() => setActiveZone(null)}
        >
          <path
            d="M 255 185
               C 270 150, 330 150, 345 185
               C 385 220, 370 290, 335 340
               C 325 355, 325 385, 320 415
               C 318 425, 282 425, 280 415
               C 275 385, 275 355, 265 340
               C 230 290, 215 220, 255 185 Z"
            fill="url(#myometriumGrad)"
            stroke="#2E1522"
            strokeWidth="3"
            filter="drop-shadow(0 10px 15px rgba(46, 21, 34, 0.2))"
          />
          {/* Volumetric fundus highlight for 3D depth */}
          <path
            d="M 260 188 C 275 160, 325 160, 340 188 C 365 225, 350 280, 300 280 C 250 280, 235 225, 260 188 Z"
            fill="url(#fundusHighlight)"
          />
        </g>

        {/* Endometrial Cavity & Inverted Triangle Chamber */}
        <g
          className="cursor-pointer transition-all duration-300"
          onMouseEnter={() => setActiveZone('endometrium')}
          onMouseLeave={() => setActiveZone(null)}
        >
          <path
            d="M 278 200
               C 290 195, 310 195, 322 200
               C 335 230, 325 265, 310 310
               L 310 360
               L 290 360
               L 290 310
               C 275 265, 265 230, 278 200 Z"
            fill="url(#endometriumGrad)"
            stroke="#B26E86"
            strokeWidth="2"
          />
          {/* Subtle glandular striae */}
          <path d="M 295 215 Q 300 235 296 255" stroke="#FFFFFF" strokeWidth="1.2" strokeOpacity="0.7" />
          <path d="M 305 215 Q 300 235 304 255" stroke="#FFFFFF" strokeWidth="1.2" strokeOpacity="0.7" />
          <path d="M 300 270 L 300 350" stroke="#FAF2F5" strokeWidth="1.5" strokeOpacity="0.8" />
        </g>

        {/* Cervix & External Os */}
        <g
          className="cursor-pointer"
          onMouseEnter={() => setActiveZone('cervix')}
          onMouseLeave={() => setActiveZone(null)}
        >
          <path d="M 285 390 C 295 396, 305 396, 315 390" stroke="#EAC9D9" strokeWidth="4" strokeLinecap="round" />
          <circle cx="300" cy="410" r="4" fill="#2E1522" />
        </g>

        {/* Visual interactive hot spots */}
        <g className="cursor-pointer" onClick={() => setActiveZone('fundus')}>
          <circle cx="300" cy="160" r="5" fill="#FAF2F5" stroke="#451E33" strokeWidth="2" />
          <circle cx="300" cy="160" r="10" fill="#451E33" fillOpacity="0.15" className="animate-ping" />
        </g>
        <g className="cursor-pointer" onClick={() => setActiveZone('endometrium')}>
          <circle cx="300" cy="240" r="5" fill="#FAF2F5" stroke="#451E33" strokeWidth="2" />
          <circle cx="300" cy="240" r="10" fill="#451E33" fillOpacity="0.15" className="animate-ping" />
        </g>
        <g className="cursor-pointer" onClick={() => setActiveZone('ovary')}>
          <circle cx="125" cy="190" r="4" fill="#5A7B57" stroke="#FAF8F5" strokeWidth="1.5" />
        </g>
      </svg>

      {/* Anatomy Interactive Detail Pill */}
      <div className="mt-4 w-full max-w-md min-h-[64px] bg-white/90 backdrop-blur-xs rounded-2xl border border-[#E9E3DC] p-3 text-center transition-all duration-200 shadow-xs">
        {activeZone && zones[activeZone] ? (
          <div>
            <span className="text-xs font-bold text-[#451E33] tracking-wide uppercase">
              {zones[activeZone].title}
            </span>
            <p className="text-xs text-gray-600 mt-0.5 leading-relaxed">
              {zones[activeZone].desc}
            </p>
          </div>
        ) : (
          <p className="text-xs text-gray-500 italic flex items-center justify-center h-full">
            Hover or tap anatomical zones (fundus, lining, myometrium, ovaries) to inspect clinical relevance
          </p>
        )}
      </div>
    </div>
  );
};
