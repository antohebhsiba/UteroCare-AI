import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Sparkles, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Upload, 
  Info, 
  ArrowRight,
  ShieldCheck,
  Stethoscope
} from 'lucide-react';
import { useAssessment } from '../context/AssessmentContext';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';

export const AIWorkspace: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const {
    activeAssessment,
    symptoms,
    documents,
    loadAssessment,
    triggerAnalysis,
    isLoading,
  } = useAssessment();

  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      loadAssessment(id);
    }
  }, [id, loadAssessment]);

  const handleRunAnalysis = async () => {
    setAnalyzing(true);
    setError(null);
    try {
      await triggerAnalysis();
      navigate(`/assessment/${id}/results`);
    } catch (err: any) {
      setError(err.message || 'Failed to complete clinical analysis.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E9E3DC]">
        <div className="flex items-center gap-3">
          <Link
            to={id ? `/assessment/${id}` : '/assessments'}
            className="p-1.5 rounded-xl text-gray-500 hover:text-[#451E33] hover:bg-[#F5E5EC] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-[#FAF2F5] text-[#451E33] border border-[#EAC9D9]">
                {id}
              </span>
              <span className="text-xs text-gray-400">• Clinical Workspace</span>
            </div>
            <h1 className="text-2xl font-bold text-[#2C141F] font-editorial mt-0.5">
              Review & Clinical Synthesis
            </h1>
          </div>
        </div>

        <Button
          variant="primary"
          size="md"
          onClick={handleRunAnalysis}
          isLoading={analyzing}
          icon={<Sparkles className="w-4 h-4" />}
        >
          {analyzing ? 'Synthesizing Guidance...' : 'Generate Clinical Analysis'}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-3">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Grid: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Recorded Symptoms Summary */}
        <div className="lg:col-span-7 space-y-6">
          <Card variant="white">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-4">
              <h3 className="text-sm font-bold text-[#2C141F] font-editorial">
                Patient-Reported Symptom Profile
              </h3>
              <Link to={`/assessment/${id}`} className="text-xs font-semibold text-[#7B325B] hover:underline">
                Edit Answers
              </Link>
            </div>

            <div className="space-y-3 text-xs">
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Age Bracket:</span>
                <span className="font-medium text-gray-900">{symptoms.age_range || 'Not specified'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Main Concern:</span>
                <span className="font-medium text-gray-900 max-w-xs text-right truncate">{symptoms.main_concern || 'None entered'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Bleeding Heaviness:</span>
                <span className="font-medium text-gray-900 capitalize">{symptoms.bleeding_heaviness || 'Not specified'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Bleeding Duration:</span>
                <span className="font-medium text-gray-900">{symptoms.bleeding_duration || 'Not specified'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Pelvic Cramping / Pain:</span>
                <span className="font-medium text-gray-900 capitalize">{symptoms.pelvic_pain_presence || 'None'} (Severity: {symptoms.pain_severity ?? 0}/10)</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Intermenstrual Spotting:</span>
                <span className="font-medium text-gray-900 capitalize">{symptoms.intermenstrual_bleeding || 'No'}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-gray-500">Pelvic Pressure / Bulk:</span>
                <span className="font-medium text-gray-900 capitalize">{symptoms.pelvic_pressure || 'No'}</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-gray-500">Symptom Duration:</span>
                <span className="font-medium text-gray-900">{symptoms.symptom_duration || 'Ongoing'}</span>
              </div>
            </div>
          </Card>

          {/* Clinical Framework Badge */}
          <div className="p-4 rounded-2xl bg-[#EEF3ED] border border-[#D0E0CE] text-xs text-[#3E573B] flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-[#5A7B57] shrink-0" />
            <div>
              <strong>Structured FIGO Classification:</strong> Synthesis compares your profile against International Federation of Gynecology and Obstetrics criteria for abnormal uterine bleeding.
            </div>
          </div>
        </div>

        {/* Right Column: Uploaded Records & Ultrasound Notice */}
        <div className="lg:col-span-5 space-y-6">
          <Card variant="white">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-4">
              <h3 className="text-sm font-bold text-[#2C141F] font-editorial">
                Attached Documents ({documents.length})
              </h3>
              <Link to={`/assessment/${id}/uploads`} className="text-xs font-semibold text-[#7B325B] hover:underline flex items-center gap-1">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload</span>
              </Link>
            </div>

            {documents.length === 0 ? (
              <p className="text-xs text-gray-500 italic py-2">
                No documents uploaded. The clinical synthesis will run in symptom-guided mode.
              </p>
            ) : (
              <ul className="space-y-2 text-xs">
                {documents.map(d => (
                  <li key={d.id} className="p-2.5 rounded-xl bg-[#FAF8F5] border border-[#E9E3DC] flex items-center justify-between">
                    <span className="truncate max-w-[180px] font-medium">{d.original_name}</span>
                    <span className="text-[11px] text-gray-500 capitalize">{d.document_type.replace('_', ' ')}</span>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {/* Model Status Notice Box */}
          <div className="p-4 rounded-2xl bg-[#FAF8F5] border border-[#E9E3DC] space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-[#451E33]">
              <Info className="w-4 h-4 text-[#7B325B]" />
              <span>Ultrasound Analysis Engine Status</span>
            </div>
            <p className="text-[11px] text-gray-600 leading-relaxed">
              Automated ultrasound interpretation is unavailable because a compatible trained model has not been configured. Your clinical analysis will state this transparently and focus on symptom pattern identification.
            </p>
          </div>

          <Button
            variant="primary"
            size="lg"
            onClick={handleRunAnalysis}
            isLoading={analyzing}
            icon={<Sparkles className="w-5 h-5" />}
            className="w-full shadow-md"
          >
            {analyzing ? 'Synthesizing...' : 'Run Analysis & Open Report'}
          </Button>

        </div>

      </div>

    </div>
  );
};
