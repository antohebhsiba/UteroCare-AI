import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AssessmentProvider } from './context/AssessmentContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

// Pages
import { Home } from './pages/Home';
import { Register } from './pages/Register';
import { Login } from './pages/Login';
import { GuidedAssessment } from './pages/GuidedAssessment';
import { ActiveAssessments } from './pages/ActiveAssessments';
import { CycleTracker } from './pages/CycleTracker';
import { UploadScans } from './pages/UploadScans';
import { AIWorkspace } from './pages/AIWorkspace';
import { AssessmentResults } from './pages/AssessmentResults';
import { AssessmentHistory } from './pages/AssessmentHistory';
import { HealthLibrary } from './pages/HealthLibrary';
import { DoctorPrep } from './pages/DoctorPrep';
import { AccountSettings } from './pages/AccountSettings';
import { PrivacySecurity } from './pages/PrivacySecurity';
import { NotFound } from './pages/NotFound';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AssessmentProvider>
          <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-[#2C2426]">
            <Navbar />
            <main className="flex-1">
              <Routes>
                {/* 1. Home */}
                <Route path="/" element={<Home />} />

                {/* 2. Registration */}
                <Route path="/register" element={<Register />} />

                {/* 3. Login */}
                <Route path="/login" element={<Login />} />

                {/* 4. Guided Assessment (Protected) */}
                <Route
                  path="/assessment/:id"
                  element={
                    <ProtectedRoute>
                      <GuidedAssessment />
                    </ProtectedRoute>
                  }
                />

                {/* 5. Active Assessments (Protected) */}
                <Route
                  path="/assessments"
                  element={
                    <ProtectedRoute>
                      <ActiveAssessments />
                    </ProtectedRoute>
                  }
                />

                {/* 6. Cycle Tracker (Protected) */}
                <Route
                  path="/cycle"
                  element={
                    <ProtectedRoute>
                      <CycleTracker />
                    </ProtectedRoute>
                  }
                />

                {/* 7. Upload Scans & Records (Protected) */}
                <Route
                  path="/assessment/:id/uploads"
                  element={
                    <ProtectedRoute>
                      <UploadScans />
                    </ProtectedRoute>
                  }
                />

                {/* 8. AI Workspace (Protected) */}
                <Route
                  path="/assessment/:id/workspace"
                  element={
                    <ProtectedRoute>
                      <AIWorkspace />
                    </ProtectedRoute>
                  }
                />

                {/* 9. Assessment Results (Protected) */}
                <Route
                  path="/assessment/:id/results"
                  element={
                    <ProtectedRoute>
                      <AssessmentResults />
                    </ProtectedRoute>
                  }
                />

                {/* 10. Assessment History (Protected) */}
                <Route
                  path="/history"
                  element={
                    <ProtectedRoute>
                      <AssessmentHistory />
                    </ProtectedRoute>
                  }
                />

                {/* 11. Health Library (Public educational) */}
                <Route path="/library" element={<HealthLibrary />} />
                <Route path="/library/:id" element={<HealthLibrary />} />

                {/* 12. Doctor Preparation (Both standalone and assessment-linked) */}
                <Route
                  path="/doctor-prep"
                  element={
                    <ProtectedRoute>
                      <DoctorPrep />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/assessment/:id/doctor-prep"
                  element={
                    <ProtectedRoute>
                      <DoctorPrep />
                    </ProtectedRoute>
                  }
                />

                {/* 13. Account Settings (Protected) */}
                <Route
                  path="/settings"
                  element={
                    <ProtectedRoute>
                      <AccountSettings />
                    </ProtectedRoute>
                  }
                />

                {/* 14. Privacy and Security (Public) */}
                <Route path="/privacy" element={<PrivacySecurity />} />

                {/* 15. Not Found / 404 */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </AssessmentProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
