import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { db } from '../database/db.ts';

const SESSION_DURATION_DAYS = 7;

export interface SafeUser {
  id: string;
  email: string;
  name: string;
  createdAt: string;
}

export function hashPassword(password: string): string {
  const salt = bcrypt.genSaltSync(12);
  return bcrypt.hashSync(password, salt);
}

export function verifyPassword(password: string, hash: string): boolean {
  return bcrypt.compareSync(password, hash);
}

export function createSession(userId: string): { sessionId: string; expiresAt: Date } {
  const sessionId = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + SESSION_DURATION_DAYS);

  const stmt = db.prepare(`
    INSERT INTO sessions (id, user_id, created_at, expires_at)
    VALUES (?, ?, ?, ?)
  `);
  stmt.run(sessionId, userId, new Date().toISOString(), expiresAt.toISOString());

  return { sessionId, expiresAt };
}

export function getUserFromSession(sessionId: string): SafeUser | null {
  if (!sessionId) return null;

  const row = db.prepare(`
    SELECT u.id, u.email, u.name, u.created_at, s.expires_at
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
  `).get(sessionId) as { id: string; email: string; name: string; created_at: string; expires_at: string } | undefined;

  if (!row) return null;

  // Check expiration
  if (new Date(row.expires_at) < new Date()) {
    deleteSession(sessionId);
    return null;
  }

  return {
    id: row.id,
    email: row.email,
    name: row.name,
    createdAt: row.created_at,
  };
}

export function deleteSession(sessionId: string): void {
  db.prepare(`DELETE FROM sessions WHERE id = ?`).run(sessionId);
}

export function deleteUserSessions(userId: string): void {
  db.prepare(`DELETE FROM sessions WHERE user_id = ?`).run(userId);
}

// Generate real unique assessment ID
export function generateAssessmentId(): string {
  const dateStr = new Date().toISOString().slice(2, 10).replace(/-/g, '');
  const randomSuffix = crypto.randomBytes(4).toString('hex').toUpperCase();
  return `UTC-${dateStr}-${randomSuffix}`;
}
