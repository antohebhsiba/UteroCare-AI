import { Router, Request, Response } from 'express';
import { CLINICAL_CONDITIONS } from '../services/assessmentEngine.ts';

export const conditionsRouter = Router();

// GET /api/conditions
conditionsRouter.get('/', (_req: Request, res: Response) => {
  res.json({ conditions: CLINICAL_CONDITIONS });
});

// GET /api/conditions/:id
conditionsRouter.get('/:id', (req: Request, res: Response) => {
  const condition = CLINICAL_CONDITIONS.find(c => c.id === req.params.id);
  if (!condition) {
    res.status(404).json({ error: 'Condition not found in clinical health library.' });
    return;
  }
  res.json({ condition });
});
