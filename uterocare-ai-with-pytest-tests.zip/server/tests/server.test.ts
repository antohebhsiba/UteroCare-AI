import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { app } from '../app.ts';
import http from 'http';

let server: http.Server;
let baseUrl: string;

beforeAll(async () => {
  await new Promise<void>((resolve) => {
    server = app.listen(0, '127.0.0.1', () => {
      const addr = server.address() as { port: number };
      baseUrl = `http://127.0.0.1:${addr.port}`;
      resolve();
    });
  });
});

afterAll(async () => {
  await new Promise<void>((resolve) => {
    server.close(() => resolve());
  });
});

describe('UteroCare AI Automated Backend Verification', () => {
  const testUserA = {
    email: `test_a_${Date.now()}@example.com`,
    password: 'SecurePassword123!',
    name: 'Sarah Jenkins',
  };

  const testUserB = {
    email: `test_b_${Date.now()}@example.com`,
    password: 'SecurePassword456!',
    name: 'Elena Rostova',
  };

  let tokenA = '';
  let tokenB = '';
  let assessmentIdA = '';

  it('GET /api/health - verifies health and database connectivity', async () => {
    const res = await fetch(`${baseUrl}/api/health`);
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.status).toBe('ok');
    expect(json.database).toBe('connected');
  });

  it('1. POST /api/auth/register - registers new user with email and hashed password', async () => {
    const res = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testUserA),
    });
    expect(res.status).toBe(201);
    const json = await res.json();
    expect(json.user.email).toBe(testUserA.email);
    expect(json.token).toBeDefined();
    tokenA = json.token;
  });

  it('2. POST /api/auth/register - rejects duplicate email registration with 409', async () => {
    const res = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testUserA),
    });
    expect(res.status).toBe(409);
    const json = await res.json();
    expect(json.error).toMatch(/already exists/i);
  });

  it('3. POST /api/auth/login - authenticates valid credentials', async () => {
    const res = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: testUserA.email, password: testUserA.password }),
    });
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.user.email).toBe(testUserA.email);
    expect(json.token).toBeDefined();
    tokenA = json.token;
  });

  it('4. POST /api/auth/login - rejects invalid credentials with 401', async () => {
    const res = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: testUserA.email, password: 'WrongPassword!' }),
    });
    expect(res.status).toBe(401);
    const json = await res.json();
    expect(json.error).toMatch(/invalid email or password/i);
  });

  it('5. GET /api/auth/me - restores session for authenticated user', async () => {
    const res = await fetch(`${baseUrl}/api/auth/me`, {
      headers: { Authorization: `Bearer ${tokenA}` },
    });
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.user.email).toBe(testUserA.email);
  });

  it('6. Unauthenticated requests to protected routes are rejected with 401', async () => {
    const res = await fetch(`${baseUrl}/api/assessments`);
    expect(res.status).toBe(401);
  });

  it('7. POST /api/assessments - creates real draft assessment with valid unique ID (no placeholders)', async () => {
    const res = await fetch(`${baseUrl}/api/assessments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenA}`,
      },
      body: JSON.stringify({ title: 'Menorrhagia & Pelvic Cramping Evaluation' }),
    });
    expect(res.status).toBe(201);
    const json = await res.json();
    expect(json.assessment).toBeDefined();
    expect(json.assessment.id).toMatch(/^UTC-/);
    expect(json.assessment.id).not.toBe('utc_pending');
    assessmentIdA = json.assessment.id;
  });

  it('8. PUT /api/assessments/:id/symptoms - saves symptom questionnaire progressively', async () => {
    const res = await fetch(`${baseUrl}/api/assessments/${assessmentIdA}/symptoms`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenA}`,
      },
      body: JSON.stringify({
        age_range: '30-39',
        main_concern: 'Heavy menstrual bleeding and pelvic pressure for 8 months',
        cycle_regularity: 'regular',
        cycle_length: '28 days',
        bleeding_duration: '8-9 days',
        bleeding_heaviness: 'heavy',
        pelvic_pain_presence: 'yes',
        pain_severity: 6,
        pelvic_pressure: 'yes',
        symptom_duration: '6-12 months',
      }),
    });
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.symptoms.bleeding_heaviness).toBe('heavy');
    expect(json.symptoms.pain_severity).toBe(6);
  });

  it('9. GET /api/assessments/:id - restores saved answers and assessment details accurately', async () => {
    const res = await fetch(`${baseUrl}/api/assessments/${assessmentIdA}`, {
      headers: { Authorization: `Bearer ${tokenA}` },
    });
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.assessment.id).toBe(assessmentIdA);
    expect(json.symptoms.main_concern).toContain('Heavy menstrual bleeding');
  });

  it('10. GET /api/assessments - lists active assessments for user', async () => {
    const res = await fetch(`${baseUrl}/api/assessments`, {
      headers: { Authorization: `Bearer ${tokenA}` },
    });
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.assessments.length).toBeGreaterThanOrEqual(1);
    expect(json.assessments[0].id).toBe(assessmentIdA);
  });

  it('11. Security: prevents cross-user access to another user’s assessment', async () => {
    const regB = await fetch(`${baseUrl}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testUserB),
    });
    const jsonB = await regB.json();
    tokenB = jsonB.token;

    const crossAccess = await fetch(`${baseUrl}/api/assessments/${assessmentIdA}`, {
      headers: { Authorization: `Bearer ${tokenB}` },
    });
    expect(crossAccess.status).toBe(404);
  });

  it('12. POST /api/assessments/:id/analyze - completes clinical symptom-based analysis and enforces ultrasound disclaimer', async () => {
    const res = await fetch(`${baseUrl}/api/assessments/${assessmentIdA}/analyze`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${tokenA}` },
    });
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.result.summary).toBeDefined();
    expect(json.result.identified_patterns.length).toBeGreaterThan(0);
    expect(json.result.questions_for_doctor.length).toBeGreaterThan(0);
    expect(json.result.disclaimer).toBeDefined();
  });

  it('13. GET /api/assessments/:id/report - retrieves complete clinical report', async () => {
    const res = await fetch(`${baseUrl}/api/assessments/${assessmentIdA}/report`, {
      headers: { Authorization: `Bearer ${tokenA}` },
    });
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.report.assessmentId).toBe(assessmentIdA);
    expect(json.report.patientName).toBe(testUserA.name);
    expect(json.report.identifiedPatterns.length).toBeGreaterThan(0);
  });

  it('14. POST /api/cycle - records menstrual cycle entry and computes analytics', async () => {
    const res = await fetch(`${baseUrl}/api/cycle`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${tokenA}`,
      },
      body: JSON.stringify({
        start_date: '2026-10-01',
        end_date: '2026-10-06',
        flow_intensity: 'heavy',
        pain_level: 5,
        symptoms: ['pelvic_cramps', 'fatigue'],
        notes: 'Heavier flow on days 2 and 3.',
      }),
    });
    expect(res.status).toBe(201);
    const json = await res.json();
    expect(json.entry.start_date).toBe('2026-10-01');
  });

  it('15. GET /api/cycle - retrieves saved cycles for user', async () => {
    const res = await fetch(`${baseUrl}/api/cycle`, {
      headers: { Authorization: `Bearer ${tokenA}` },
    });
    expect(res.status).toBe(200);
    const json = await res.json();
    expect(json.entries.length).toBeGreaterThanOrEqual(1);
  });

  it('16. DELETE /api/assessments/:id - removes assessment permanently', async () => {
    const res = await fetch(`${baseUrl}/api/assessments/${assessmentIdA}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${tokenA}` },
    });
    expect(res.status).toBe(200);

    const getRes = await fetch(`${baseUrl}/api/assessments/${assessmentIdA}`, {
      headers: { Authorization: `Bearer ${tokenA}` },
    });
    expect(getRes.status).toBe(404);
  });

  // Dedicated test for: "Start New Assessment after login"
  it('17. Real workflow: Post-login Start New Assessment creates persistent record and allows immediate resume', async () => {
    // 1. Log in fresh
    const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: testUserB.email, password: testUserB.password }),
    });
    expect(loginRes.status).toBe(200);
    const loginData = await loginRes.json();
    const token = loginData.token;
    expect(token).toBeDefined();

    // 2. Click Start New Assessment (POST /api/assessments with token)
    const createRes = await fetch(`${baseUrl}/api/assessments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title: 'New Consultation Assessment' }),
    });
    expect(createRes.status).toBe(201);
    const createData = await createRes.json();
    const newAssessmentId = createData.assessment.id;
    expect(newAssessmentId).toMatch(/^UTC-/);
    expect(newAssessmentId).not.toBe('utc_pending');
    expect(newAssessmentId).not.toBe('new');

    // 3. Confirm persistent existence in SQLite database
    const dbRow = db.prepare('SELECT * FROM assessments WHERE id = ?').get(newAssessmentId) as any;
    expect(dbRow).toBeDefined();
    expect(dbRow.user_id).toBe(loginData.user.id);
    expect(dbRow.status).toBe('collecting_information');
    expect(dbRow.current_step).toBe(1);

    // 4. Retrieve and resume assessment
    const getRes = await fetch(`${baseUrl}/api/assessments/${newAssessmentId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    expect(getRes.status).toBe(200);
    const getData = await getRes.json();
    expect(getData.assessment.id).toBe(newAssessmentId);
    expect(getData.assessment.current_step).toBe(1);

    // 5. Unauthenticated access blocked
    const unauthRes = await fetch(`${baseUrl}/api/assessments/${newAssessmentId}`);
    expect(unauthRes.status).toBe(401);

    // Clean up
    await fetch(`${baseUrl}/api/assessments/${newAssessmentId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    });
  });
});
