import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Stethoscope, 
  Printer, 
  CheckSquare, 
  Square, 
  Calendar, 
  FileText, 
  ArrowLeft, 
  HelpCircle, 
  Clock, 
  AlertCircle,
  ClipboardCheck,
  ChevronRight
} from 'lucide-react';
import { api } from '../services/api';
import { Assessment, AssessmentResult, SymptomData } from '../types';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';

export const DoctorPrep: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(id || null);
  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [symptoms, setSymptoms] = useState<SymptomData>({});
  const [result, setResult] = useState<AssessmentResult | null>(null);
  const [loading, setLoading] = useState(false);

  // Interactive Checklist states
  const [checklist, setChecklist] = useState<Record<string, boolean>>({
    id_insurance: false,
    bleed_calendar: false,
    med_list: false,
    prior_scans: false,
    pad_count: false,
    written_questions: false,
  });

  useEffect(() => {
    async function fetchList() {
      try {
        const res = await api.getAssessments();
        setAssessments(res.assessments);
        if (!selectedId && res.assessments.length > 0) {
          setSelectedId(res.assessments[0].id);
        }
      } catch (err) {
        console.error(err);
      }
    }
    fetchList();
  }, [selectedId]);

  useEffect(() => {
    if (selectedId) {
      setLoading(true);
      api.getAssessment(selectedId)
        .then(res => {
          setAssessment(res.assessment);
          setSymptoms(res.symptoms || {});
          setResult(res.result);
        })
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [selectedId]);

  const toggleChecklistItem = (key: string) => {
    setChecklist(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 print:p-0 print:m-0 print:max-w-none">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E9E3DC] print:hidden">
        <div className="flex items-center gap-3">
          <Link
            to="/assessments"
            className="p-1.5 rounded-xl text-gray-500 hover:text-[#451E33] hover:bg-[#F5E5EC] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-[#9B4274]">
                Consultation Advocacy
              </span>
              <span className="text-xs text-gray-400">• Doctor Prep</span>
            </div>
            <h1 className="text-2xl font-bold text-[#2C141F] font-editorial mt-0.5">
              Gynecologist Appointment Preparation
            </h1>
          </div>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handlePrint}
          icon={<Printer className="w-4 h-4" />}
        >
          Print Doctor Packet
        </Button>
      </div>

      {/* Assessment Selector if multiple exist */}
      {assessments.length > 1 && (
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-white border border-[#E9E3DC] print:hidden text-xs">
          <span className="font-semibold text-gray-700">Select Assessment to Populate:</span>
          <select
            value={selectedId || ''}
            onChange={(e) => setSelectedId(e.target.value)}
            className="p-2 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs font-medium text-gray-900 focus:outline-none"
          >
            {assessments.map(a => (
              <option key={a.id} value={a.id}>
                {a.id} — {a.title} ({new Date(a.created_at).toLocaleDateString()})
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Main Printable Dossier */}
      <Card variant="white" className="p-8 sm:p-12 space-y-8 border-[#E9E3DC] shadow-sm">
        
        {/* Clinician Dossier Top Header */}
        <div className="border-b border-gray-200 pb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#9B4274] bg-[#FAF2F5] px-2.5 py-0.5 rounded-full border border-[#EAC9D9]/60">
              Physician Consultation Brief
            </span>
            <h2 className="text-2xl font-bold text-[#2C141F] font-editorial mt-1">
              Gynecological Symptom & Investigation Dossier
            </h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Prepared via UteroCare AI for discussion during clinical consultation.
            </p>
          </div>

          <div className="text-xs text-gray-500 sm:text-right">
            <p>Assessment Reference: <span className="font-mono font-medium text-gray-800">{selectedId || 'General'}</span></p>
            <p>Print Date: {new Date().toLocaleDateString()}</p>
          </div>
        </div>

        {/* Section 1: Clinical Symptom Summary for Doctor */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#451E33] flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-[#7B325B]" />
            <span>1. Patient-Reported Clinical Characteristics</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-[#FAF8F5] border border-[#E9E3DC] p-4 rounded-2xl">
            <div>
              <span className="text-gray-500 block">Chief Complaint:</span>
              <strong className="text-gray-900">{symptoms.main_concern || 'Not specified'}</strong>
            </div>
            <div>
              <span className="text-gray-500 block">Age Demographic:</span>
              <strong className="text-gray-900">{symptoms.age_range || 'Not specified'}</strong>
            </div>
            <div>
              <span className="text-gray-500 block">Menstrual Cycle Interval:</span>
              <strong className="text-gray-900">{symptoms.cycle_regularity || 'Not specified'} ({symptoms.cycle_length || 'Length unrecorded'})</strong>
            </div>
            <div>
              <span className="text-gray-500 block">Flow Heaviness & Duration:</span>
              <strong className="text-gray-900 capitalize">{symptoms.bleeding_heaviness || 'Not specified'} for {symptoms.bleeding_duration || 'unspecified days'}</strong>
            </div>
            <div>
              <span className="text-gray-500 block">Dysmenorrhea / Pelvic Cramping:</span>
              <strong className="text-gray-900">{symptoms.pelvic_pain_presence || 'None'} (Severity: {symptoms.pain_severity ?? 0}/10)</strong>
            </div>
            <div>
              <span className="text-gray-500 block">Intermenstrual / Postcoital Bleeding:</span>
              <strong className="text-gray-900">Between: {symptoms.intermenstrual_bleeding || 'No'} | Postcoital: {symptoms.postcoital_bleeding || 'No'}</strong>
            </div>
            <div>
              <span className="text-gray-500 block">Pelvic Bulk / Pressure Sensation:</span>
              <strong className="text-gray-900 capitalize">{symptoms.pelvic_pressure || 'None'}</strong>
            </div>
            <div>
              <span className="text-gray-500 block">Symptom Chronicity:</span>
              <strong className="text-gray-900">{symptoms.symptom_duration || 'Ongoing'}</strong>
            </div>
          </div>
        </div>

        {/* Section 2: Tailored Questions to Ask the Gynecologist */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#451E33] flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-[#7B325B]" />
            <span>2. Recommended Questions to Ask Your Clinician</span>
          </h3>

          <div className="space-y-2 bg-[#EEF3ED] border border-[#D0E0CE] p-4 rounded-2xl">
            {(result?.questions_for_doctor || [
              'Would a transvaginal ultrasound (TVS) or saline infusion sonohysterogram (SIS) clarify whether my symptoms are due to fibroids or polyps?',
              'Should we order a Full Blood Count (FBC) and serum ferritin to assess for iron deficiency anemia?',
              'What are the medical management options (e.g. tranexamic acid, hormonal IUD, oral progestins) versus procedural options for my flow volume?',
              'If pain is cyclic and deep, could adenomyosis or endometriosis be contributing?',
              'Are there lifestyle or dietary interventions you recommend alongside medical therapy?'
            ]).map((q, idx) => (
              <div key={idx} className="flex items-start gap-2 text-xs text-[#2C2426]">
                <span className="font-bold text-[#5A7B57] shrink-0">{idx + 1}.</span>
                <span className="leading-snug">{q}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Section 3: Appointment Day Checklist */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#451E33] flex items-center gap-1.5">
            <ClipboardCheck className="w-4 h-4 text-[#7B325B]" />
            <span>3. Practical Appointment Checklist (What to Bring)</span>
          </h3>

          <div className="space-y-2 text-xs">
            {[
              { key: 'id_insurance', label: 'Government ID, insurance card, and referral letter (if required)' },
              { key: 'bleed_calendar', label: 'Menstrual bleeding dates for the past 3-6 months (printed or from Cycle Tracker)' },
              { key: 'pad_count', label: 'Estimate of pads or tampons used on your heaviest bleeding days' },
              { key: 'med_list', label: 'Complete list of all medications, NSAIDs, oral contraceptives, and supplements' },
              { key: 'prior_scans', label: 'Copies or disks of any prior pelvic ultrasounds, CTs, or pathology reports' },
              { key: 'written_questions', label: 'This printed UteroCare AI summary sheet with your prioritized questions' },
            ].map(item => (
              <button
                key={item.key}
                type="button"
                onClick={() => toggleChecklistItem(item.key)}
                className="w-full flex items-center gap-2.5 p-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-left hover:bg-white transition-colors cursor-pointer"
              >
                {checklist[item.key] ? (
                  <CheckSquare className="w-4 h-4 text-[#5A7B57] shrink-0" />
                ) : (
                  <Square className="w-4 h-4 text-gray-400 shrink-0" />
                )}
                <span className={`text-xs ${checklist[item.key] ? 'line-through text-gray-400' : 'text-gray-800'}`}>
                  {item.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Section 4: Physical Examination Notes */}
        <div className="p-4 rounded-2xl border border-dashed border-gray-300 text-xs text-gray-500 space-y-1">
          <strong className="text-gray-700 block">Clinician Examination & Prescription Notes (Fill during visit):</strong>
          <div className="h-20" />
        </div>

      </Card>

    </div>
  );
};
