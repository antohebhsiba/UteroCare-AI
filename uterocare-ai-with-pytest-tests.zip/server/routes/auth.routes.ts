import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { z } from 'zod';
import { db } from '../database/db.ts';
import { hashPassword, verifyPassword, createSession, deleteSession, deleteUserSessions } from '../security/auth.ts';
import { requireAuth } from '../middleware/auth.ts';
import { deleteUploadFile } from '../services/documentService.ts';

export const authRouter = Router();

const RegisterSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters long'),
  name: z.string().min(2, 'Name must be at least 2 characters'),
});

const LoginSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(1, 'Password is required'),
});

// Set session cookie with proper flags for top-level and iframe environments
function setSessionCookie(res: Response, sessionId: string, expiresAt: Date) {
  res.cookie('utc_session', sessionId, {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    expires: expiresAt,
    path: '/',
  });
}

authRouter.post('/register', (req: Request, res: Response) => {
  try {
    const parseResult = RegisterSchema.safeParse(req.body);
    if (!parseResult.success) {
      res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Invalid input data' });
      return;
    }

    const { email, password, name } = parseResult.data;
    const normalizedEmail = email.trim().toLowerCase();

    // Check if user already exists
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
    if (existing) {
      res.status(409).json({ error: 'An account with this email address already exists. Please log in.' });
      return;
    }

    const userId = crypto.randomUUID();
    const passwordHash = hashPassword(password);
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO users (id, email, password_hash, name, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(userId, normalizedEmail, passwordHash, name.trim(), now, now);

    const { sessionId, expiresAt } = createSession(userId);
    setSessionCookie(res, sessionId, expiresAt);

    res.status(201).json({
      user: {
        id: userId,
        email: normalizedEmail,
        name: name.trim(),
        createdAt: now,
      },
      token: sessionId,
      message: 'Account registered successfully',
    });
  } catch (err: any) {
    console.error('Registration error:', err);
    res.status(500).json({ error: 'An unexpected database error occurred during registration. Please try again.' });
  }
});

authRouter.post('/login', (req: Request, res: Response) => {
  try {
    const parseResult = LoginSchema.safeParse(req.body);
    if (!parseResult.success) {
      res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Invalid email or password format' });
      return;
    }

    const { email, password } = parseResult.data;
    const normalizedEmail = email.trim().toLowerCase();

    const user = db.prepare(`
      SELECT id, email, password_hash, name, created_at FROM users WHERE email = ?
    `).get(normalizedEmail) as { id: string; email: string; password_hash: string; name: string; created_at: string } | undefined;

    if (!user || !verifyPassword(password, user.password_hash)) {
      res.status(401).json({ error: 'Invalid email or password. Please verify your credentials and try again.' });
      return;
    }

    const { sessionId, expiresAt } = createSession(user.id);
    setSessionCookie(res, sessionId, expiresAt);

    res.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        createdAt: user.created_at,
      },
      token: sessionId,
      message: 'Logged in successfully',
    });
  } catch (err: any) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'An unexpected server error occurred during login. Please try again.' });
  }
});

authRouter.post('/logout', requireAuth, (req: Request, res: Response) => {
  try {
    if (req.sessionId) {
      deleteSession(req.sessionId);
    }
    res.clearCookie('utc_session', { path: '/' });
    res.json({ success: true, message: 'Logged out successfully' });
  } catch (err) {
    console.error('Logout error:', err);
    res.status(500).json({ error: 'Failed to complete logout.' });
  }
});

authRouter.get('/me', requireAuth, (req: Request, res: Response) => {
  res.json({ user: req.user });
});

authRouter.delete('/account', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;

    // Remove any physical files owned by user
    const userDocs = db.prepare('SELECT storage_path, filename FROM medical_documents WHERE user_id = ?').all(userId) as { storage_path: string; filename: string }[];
    for (const doc of userDocs) {
      deleteUploadFile(doc.filename);
    }

    // Cascade delete user
    db.prepare('DELETE FROM users WHERE id = ?').run(userId);
    res.clearCookie('utc_session', { path: '/' });
    res.json({ success: true, message: 'Account and all associated records permanently removed.' });
  } catch (err) {
    console.error('Account deletion error:', err);
    res.status(500).json({ error: 'Failed to delete account.' });
  }
});
