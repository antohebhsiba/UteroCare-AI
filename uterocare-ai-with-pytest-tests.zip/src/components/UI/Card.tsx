import React from 'react';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'white' | 'ivory' | 'subtle' | 'rose' | 'sage';
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'white',
  className = '',
  ...props
}) => {
  const variantStyles = {
    white: 'bg-white border-[#E9E3DC]/80 shadow-[0_4px_20px_-4px_rgba(45,35,39,0.05)]',
    ivory: 'bg-[#FAF8F5] border-[#E9E3DC] shadow-xs',
    subtle: 'bg-[#FAF2F5]/50 border-[#EAC9D9]/50 shadow-none',
    rose: 'bg-[#FAF2F5] border-[#EAC9D9] shadow-xs',
    sage: 'bg-[#F4F7F4] border-[#D0E0CE] shadow-xs',
  };

  return (
    <div
      className={`rounded-2xl border p-6 transition-all duration-200 ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};
