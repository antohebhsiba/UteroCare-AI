import React from 'react';
import { AlertTriangle, PhoneCall, ShieldAlert, X } from 'lucide-react';
import { Button } from './Button';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  reasons: string[];
}

export const EmergencyModal: React.FC<EmergencyModalProps> = ({ isOpen, onClose, reasons }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border-2 border-rose-300 p-6 md:p-8 overflow-hidden">
        <div className="flex items-start gap-4 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-7 h-7" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-rose-700 uppercase tracking-widest bg-rose-50 px-2.5 py-0.5 rounded-full border border-rose-200">
                Critical Clinical Alert
              </span>
              <button 
                onClick={onClose}
                className="text-gray-400 hover:text-gray-600 rounded-lg p-1 transition-colors"
                aria-label="Dismiss alert"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <h2 className="text-xl md:text-2xl font-bold text-[#2C141F] mt-1 font-editorial">
              Immediate Medical Attention Recommended
            </h2>
          </div>
        </div>

        <p className="text-sm text-gray-700 mb-4 leading-relaxed">
          Based on the responses you provided, our medical safety triage engine identified symptoms that warrant <strong>immediate evaluation by an emergency room or on-call gynecologist</strong>:
        </p>

        <div className="bg-rose-50/80 border border-rose-200/80 rounded-2xl p-4 mb-6 space-y-2">
          {reasons.map((reason, idx) => (
            <div key={idx} className="flex items-start gap-2.5 text-xs md:text-sm text-rose-900 leading-snug">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{reason}</span>
            </div>
          ))}
        </div>

        <div className="bg-[#FAF8F5] border border-[#E9E3DC] rounded-2xl p-4 mb-6">
          <h4 className="text-xs font-bold uppercase tracking-wider text-[#451E33] mb-1">
            Recommended Immediate Actions:
          </h4>
          <ul className="text-xs text-gray-700 list-disc list-inside space-y-1">
            <li>Have someone drive you to the nearest Emergency Department immediately.</li>
            <li>If experiencing dizziness, faintness, or severe pain, dial <strong>911</strong> or your local emergency number.</li>
            <li>Do not take aspirin or anticoagulants without direct physician guidance.</li>
          </ul>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-end items-center">
          <Button
            variant="outline"
            size="md"
            onClick={onClose}
            className="w-full sm:w-auto"
          >
            I understand, continue questionnaire
          </Button>
          <a
            href="tel:911"
            className="w-full sm:w-auto inline-flex items-center justify-center font-medium transition-all text-sm px-5 py-2.5 gap-2 rounded-xl bg-rose-700 hover:bg-rose-800 text-white shadow-sm"
          >
            <PhoneCall className="w-4 h-4" />
            <span>Call Emergency (911)</span>
          </a>
        </div>
      </div>
    </div>
  );
};
