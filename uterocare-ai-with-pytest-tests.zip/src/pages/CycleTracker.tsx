import React, { useEffect, useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  Plus, 
  Trash2, 
  Edit3, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Droplet, 
  Activity,
  Sparkles,
  Info
} from 'lucide-react';
import { api } from '../services/api';
import { MenstrualEntry, CycleAnalytics } from '../types';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';

const COMMON_SYMPTOMS = [
  { id: 'severe_cramps', label: 'Severe Cramps / Dysmenorrhea' },
  { id: 'pelvic_heaviness', label: 'Pelvic Heaviness / Pressure' },
  { id: 'clots', label: 'Blood Clots' },
  { id: 'bloating', label: 'Abdominal Bloating' },
  { id: 'lower_back_pain', label: 'Lower Back Ache' },
  { id: 'headache', label: 'Hormonal Migraine / Headache' },
  { id: 'fatigue', label: 'Severe Fatigue / Weakness' },
  { id: 'nausea', label: 'Nausea or GI Upset' },
];

export const CycleTracker: React.FC = () => {
  const [entries, setEntries] = useState<MenstrualEntry[]>([]);
  const [analytics, setAnalytics] = useState<CycleAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Form State
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [flowIntensity, setFlowIntensity] = useState<'spotting' | 'light' | 'medium' | 'heavy' | 'very_heavy'>('medium');
  const [painLevel, setPainLevel] = useState<number>(3);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [notes, setNotes] = useState('');

  const loadCycleData = async () => {
    setLoading(true);
    try {
      const res = await api.getCycleLogs();
      setEntries(res.entries);
      setAnalytics(res.analytics);
    } catch (err: any) {
      setError(err.message || 'Failed to load cycle records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCycleData();
  }, []);

  const resetForm = () => {
    setEditingId(null);
    setStartDate('');
    setEndDate('');
    setFlowIntensity('medium');
    setPainLevel(3);
    setSelectedSymptoms([]);
    setNotes('');
    setShowForm(false);
  };

  const handleEdit = (entry: MenstrualEntry) => {
    setEditingId(entry.id);
    setStartDate(entry.start_date);
    setEndDate(entry.end_date || '');
    setFlowIntensity(entry.flow_intensity || 'medium');
    setPainLevel(entry.pain_level ?? 0);
    setSelectedSymptoms(entry.symptoms || []);
    setNotes(entry.notes || '');
    setShowForm(true);
    window.scrollTo({ top: 300, behavior: 'smooth' });
  };

  const handleDelete = async (id: string) => {
    try {
      await api.deleteCycleLog(id);
      await loadCycleData();
      setSuccessMsg('Cycle record deleted.');
    } catch (err: any) {
      setError(err.message || 'Failed to delete record.');
    }
  };

  const toggleSymptom = (id: string) => {
    setSelectedSymptoms(prev =>
      prev.includes(id) ? prev.filter(s => s !== id) : [...prev, id]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    if (!startDate) {
      setError('Period start date is required.');
      return;
    }

    if (endDate && new Date(endDate) < new Date(startDate)) {
      setError('End date cannot precede the start date.');
      return;
    }

    setSaving(true);
    try {
      if (editingId) {
        await api.updateCycleLog(editingId, {
          start_date: startDate,
          end_date: endDate || null,
          flow_intensity: flowIntensity,
          pain_level: painLevel,
          symptoms: selectedSymptoms,
          notes: notes.trim() || null,
        });
        setSuccessMsg('Cycle entry updated successfully.');
      } else {
        await api.addCycleLog({
          start_date: startDate,
          end_date: endDate || null,
          flow_intensity: flowIntensity,
          pain_level: painLevel,
          symptoms: selectedSymptoms,
          notes: notes.trim() || null,
        });
        setSuccessMsg('New cycle entry recorded.');
      }
      resetForm();
      await loadCycleData();
    } catch (err: any) {
      setError(err.message || 'Failed to save cycle log.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E9E3DC]">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#9B4274]">
              Menstrual Health Diary
            </span>
            <span className="text-xs text-gray-400">• Persistent Tracking</span>
          </div>
          <h1 className="text-3xl font-bold text-[#2C141F] font-editorial mt-1">
            Cycle & Bleeding Tracker
          </h1>
          <p className="text-xs sm:text-sm text-gray-600 mt-1">
            Log period intervals, flow heaviness, and pelvic pain to detect irregular ovulatory patterns.
          </p>
        </div>

        <Button
          variant="primary"
          size="md"
          onClick={() => {
            resetForm();
            setShowForm(!showForm);
          }}
          icon={<Plus className="w-4 h-4" />}
        >
          {showForm ? 'Close Log Form' : 'Log Menstrual Period'}
        </Button>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-3">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 rounded-2xl bg-[#EEF3ED] border border-[#D0E0CE] text-xs text-[#3E573B] flex items-center gap-3">
          <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Analytics Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        
        <Card variant="white" className="p-5 space-y-1">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Average Cycle Interval</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#2C141F] font-editorial">
              {analytics?.averageCycleDays ? `${analytics.averageCycleDays} days` : 'Insufficient data'}
            </span>
          </div>
          <p className="text-[11px] text-gray-400">Normal reproductive window: 24-38 days</p>
        </Card>

        <Card variant="white" className="p-5 space-y-1">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Average Flow Duration</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#2C141F] font-editorial">
              {analytics?.averagePeriodDays ? `${analytics.averagePeriodDays} days` : 'Insufficient data'}
            </span>
          </div>
          <p className="text-[11px] text-gray-400">Bleeding &gt; 8 days warrants evaluation</p>
        </Card>

        <Card variant="white" className="p-5 space-y-1">
          <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Estimated Next Period</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#451E33] font-editorial">
              {analytics?.estimatedNextPeriod ? new Date(analytics.estimatedNextPeriod).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : 'Needs ≥2 cycles'}
            </span>
          </div>
          <p className="text-[11px] text-gray-400">
            {analytics?.estimationDisclaimer ? 'Historical estimate (not contraceptive advice)' : 'Log more periods for estimates'}
          </p>
        </Card>

      </div>

      {/* Add / Edit Form */}
      {showForm && (
        <Card variant="white" className="p-6 sm:p-8 border-[#451E33]/30 shadow-md animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-4 border-b border-gray-100 mb-6">
            <h3 className="text-lg font-bold text-[#2C141F] font-editorial">
              {editingId ? 'Edit Menstrual Cycle Record' : 'Record New Period'}
            </h3>
            <button onClick={resetForm} className="text-xs text-gray-400 hover:text-gray-700">
              Cancel
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="start_date">
                  Period Start Date (Day 1) *
                </label>
                <input
                  id="start_date"
                  type="date"
                  required
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="end_date">
                  Period End Date (Optional / if completed)
                </label>
                <input
                  id="end_date"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20"
                />
              </div>
            </div>

            {/* Flow Intensity Selector */}
            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                Peak Flow Heaviness
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  { id: 'spotting', label: 'Spotting' },
                  { id: 'light', label: 'Light' },
                  { id: 'medium', label: 'Medium' },
                  { id: 'heavy', label: 'Heavy' },
                  { id: 'very_heavy', label: 'Very Heavy (Flooding)' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setFlowIntensity(item.id as any)}
                    className={`p-3 rounded-xl border text-xs font-medium text-center transition-all ${
                      flowIntensity === item.id
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Pain Scale */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-xs font-semibold text-[#451E33]">
                  Dysmenorrhea / Cramping Intensity (0-10)
                </label>
                <span className="text-xs font-bold text-[#451E33] px-2 py-0.5 rounded-md bg-[#FAF2F5] border border-[#EAC9D9]">
                  {painLevel} / 10
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="10"
                value={painLevel}
                onChange={(e) => setPainLevel(Number(e.target.value))}
                className="w-full accent-[#451E33] h-2 bg-gray-200 rounded-lg cursor-pointer"
              />
            </div>

            {/* Associated Symptoms Multi-select */}
            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                Associated Symptoms
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {COMMON_SYMPTOMS.map((sym) => (
                  <button
                    key={sym.id}
                    type="button"
                    onClick={() => toggleSymptom(sym.id)}
                    className={`p-2.5 rounded-xl border text-[11px] font-medium text-left transition-all ${
                      selectedSymptoms.includes(sym.id)
                        ? 'border-[#5A7B57] bg-[#EEF3ED] text-[#3E573B] font-bold'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {sym.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="notes">
                Personal Notes & Observations
              </label>
              <textarea
                id="notes"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="e.g. Day 2 required double pads; severe cramping relieved partially with heat pack."
                className="w-full p-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20"
              />
            </div>

            <div className="flex justify-end gap-3 pt-2 border-t border-gray-100">
              <Button type="button" variant="ghost" size="md" onClick={resetForm}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="md" isLoading={saving}>
                {editingId ? 'Update Record' : 'Save Cycle Record'}
              </Button>
            </div>
          </form>
        </Card>
      )}

      {/* Log History Table / List */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-[#2C141F] font-editorial">
          Logged Menstrual Records ({entries.length})
        </h2>

        {entries.length === 0 ? (
          <Card variant="white" className="text-center py-12 px-6">
            <CalendarIcon className="w-10 h-10 text-gray-300 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-[#2C141F]">No cycle logs recorded yet</h4>
            <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto">
              Start by logging your most recent period start date to begin building your personal cycle pattern.
            </p>
          </Card>
        ) : (
          <div className="space-y-3">
            {entries.map((entry) => (
              <Card
                key={entry.id}
                variant="white"
                className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-[#C77A9E] transition-colors"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-[#2C141F] font-editorial">
                      {new Date(entry.start_date).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                      {entry.end_date && ` — ${new Date(entry.end_date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}`}
                    </span>
                    {entry.flow_intensity && (
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-[#FAF2F5] text-[#9B4274] border border-[#EAC9D9]">
                        {entry.flow_intensity.replace('_', ' ')}
                      </span>
                    )}
                    {entry.pain_level !== undefined && entry.pain_level !== null && (
                      <span className="text-[10px] font-semibold text-gray-500 bg-gray-100 px-2 py-0.5 rounded-full">
                        Pain: {entry.pain_level}/10
                      </span>
                    )}
                  </div>

                  {entry.symptoms && entry.symptoms.length > 0 && (
                    <div className="flex flex-wrap gap-1 text-[11px] text-gray-600">
                      {entry.symptoms.map((s, idx) => (
                        <span key={idx} className="bg-[#FAF8F5] border border-[#E9E3DC] px-2 py-0.5 rounded-md">
                          {s.replace(/_/g, ' ')}
                        </span>
                      ))}
                    </div>
                  )}

                  {entry.notes && (
                    <p className="text-xs text-gray-600 italic">"{entry.notes}"</p>
                  )}
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={() => handleEdit(entry)}
                    className="p-2 text-gray-400 hover:text-[#451E33] rounded-lg hover:bg-[#F5E5EC]"
                    title="Edit record"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(entry.id)}
                    className="p-2 text-gray-400 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                    title="Delete record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
