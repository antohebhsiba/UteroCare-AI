import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Heart, Lock, Mail, AlertCircle, Sparkles, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAssessment } from '../context/AssessmentContext';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';

export const Login: React.FC = () => {
  const { login } = useAuth();
  const { startNewAssessment } = useAssessment();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const queryParams = new URLSearchParams(location.search);
  const redirectTarget = queryParams.get('redirect') || '/assessments';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim() || !password) {
      setError('Please provide both your email and password.');
      return;
    }

    setIsSubmitting(true);
    try {
      await login({ email: email.trim(), password });
      if (redirectTarget.includes('start-assessment') || redirectTarget.includes('assessment/new')) {
        const newId = await startNewAssessment();
        navigate(`/assessment/${newId}`);
      } else {
        navigate(redirectTarget.startsWith('/') ? redirectTarget : `/${redirectTarget}`);
      }
    } catch (err: any) {
      setError(err.message || 'Invalid email or password. Please verify your credentials.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const fillDemoAccount = () => {
    setEmail('demo.patient@uterocare.org');
    setPassword('UteroCareDemo2026!');
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-6">
        
        <div className="text-center space-y-2">
          <div className="inline-flex w-12 h-12 rounded-2xl bg-[#451E33] items-center justify-center text-white shadow-sm mb-2">
            <Heart className="w-6 h-6 fill-rose-200" />
          </div>
          <h1 className="text-3xl font-bold text-[#2C141F] font-editorial">
            Welcome to UteroCare AI
          </h1>
          <p className="text-xs text-gray-600 max-w-sm mx-auto">
            Log in to access your saved assessments, cycle diary, and clinical reports.
          </p>
        </div>

        <Card variant="white" className="border-[#E9E3DC] shadow-sm p-6 sm:p-8">
          
          {error && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="email">
                Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20 focus:border-[#451E33]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="password">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20 focus:border-[#451E33]"
                />
              </div>
            </div>

            <div className="pt-2">
              <Button
                type="submit"
                variant="primary"
                size="md"
                isLoading={isSubmitting}
                className="w-full"
              >
                Log In to UteroCare AI
              </Button>
            </div>

          </form>

          <div className="mt-5 p-3 rounded-xl bg-[#F5E5EC]/50 border border-[#DFC0CC]/50 text-center">
            <button
              type="button"
              onClick={fillDemoAccount}
              className="inline-flex items-center gap-1.5 text-xs text-[#7B325B] hover:text-[#451E33] font-semibold"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Fill Demo Credentials for Quick Testing</span>
            </button>
          </div>

          <div className="mt-6 pt-5 border-t border-gray-100 text-center">
            <p className="text-xs text-gray-600">
              Don't have an account yet?{' '}
              <Link to={`/register?redirect=${encodeURIComponent(redirectTarget)}`} className="font-semibold text-[#451E33] hover:underline">
                Register here
              </Link>
            </p>
          </div>

        </Card>

        <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
          <ShieldCheck className="w-4 h-4 text-[#5A7B57]" />
          <span>HTTP-only Secure Cookie Sessions • Strict Auth Verification</span>
        </div>

      </div>
    </div>
  );
};
