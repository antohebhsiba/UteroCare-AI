import { Router, Request, Response } from 'express';
import { db } from '../database/db.ts';
import { requireAuth } from '../middleware/auth.ts';

export const symptomsRouter = Router({ mergeParams: true });

symptomsRouter.get('/', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    // Verify ownership
    const assessment = db.prepare('SELECT id FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId);
    if (!assessment) {
      res.status(404).json({ error: 'Assessment not found or unauthorized.' });
      return;
    }

    const symptoms = db.prepare('SELECT * FROM symptom_responses WHERE assessment_id = ?').get(assessmentId);
    res.json({ symptoms: symptoms || {} });
  } catch (err) {
    console.error('Error fetching symptoms:', err);
    res.status(500).json({ error: 'Failed to retrieve symptoms data.' });
  }
});

symptomsRouter.put('/', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    // Verify ownership
    const assessment = db.prepare('SELECT id, status FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId);
    if (!assessment) {
      res.status(404).json({ error: 'Assessment not found or unauthorized.' });
      return;
    }

    const body = req.body;
    const now = new Date().toISOString();

    // Check emergency markers
    const bleedingHeaviness = (body.bleeding_heaviness || '').toLowerCase();
    const painSeverity = Number(body.pain_severity || 0);
    const pregnancyPossibility = (body.pregnancy_possibility || '').toLowerCase();
    const notes = (body.additional_notes || '').toLowerCase();

    let emergencyFlag = 0;
    if (
      bleedingHeaviness.includes('very_heavy') ||
      bleedingHeaviness.includes('soaking') ||
      notes.includes('faint') ||
      (painSeverity >= 9) ||
      ((pregnancyPossibility === 'yes' || pregnancyPossibility === 'possible') && (painSeverity >= 6 || bleedingHeaviness.length > 0))
    ) {
      emergencyFlag = 1;
    }

    // Upsert into symptom_responses
    const updateStmt = db.prepare(`
      UPDATE symptom_responses SET
        age_range = ?,
        main_concern = ?,
        cycle_regularity = ?,
        cycle_length = ?,
        bleeding_duration = ?,
        bleeding_heaviness = ?,
        pelvic_pain_presence = ?,
        pain_severity = ?,
        pain_location = ?,
        pain_timing = ?,
        intermenstrual_bleeding = ?,
        postcoital_bleeding = ?,
        pelvic_pressure = ?,
        urinary_bowel_symptoms = ?,
        symptom_duration = ?,
        pregnancy_possibility = ?,
        prior_diagnoses = ?,
        current_medications = ?,
        additional_notes = ?,
        updated_at = ?
      WHERE assessment_id = ?
    `);

    updateStmt.run(
      body.age_range ?? null,
      body.main_concern ?? null,
      body.cycle_regularity ?? null,
      body.cycle_length ?? null,
      body.bleeding_duration ?? null,
      body.bleeding_heaviness ?? null,
      body.pelvic_pain_presence ?? null,
      body.pain_severity !== undefined ? Number(body.pain_severity) : null,
      body.pain_location ?? null,
      body.pain_timing ?? null,
      body.intermenstrual_bleeding ?? null,
      body.postcoital_bleeding ?? null,
      body.pelvic_pressure ?? null,
      body.urinary_bowel_symptoms ?? null,
      body.symptom_duration ?? null,
      body.pregnancy_possibility ?? null,
      body.prior_diagnoses ?? null,
      body.current_medications ?? null,
      body.additional_notes ?? null,
      now,
      assessmentId
    );

    // Update assessment updated_at and emergency_flag
    db.prepare(`
      UPDATE assessments
      SET emergency_flag = ?, updated_at = ?
      WHERE id = ?
    `).run(emergencyFlag, now, assessmentId);

    const updatedSymptoms = db.prepare('SELECT * FROM symptom_responses WHERE assessment_id = ?').get(assessmentId);

    res.json({
      symptoms: updatedSymptoms,
      emergencyFlag: emergencyFlag === 1,
      message: 'Symptom responses saved securely.'
    });
  } catch (err) {
    console.error('Error saving symptoms:', err);
    res.status(500).json({ error: 'Failed to save symptom responses.' });
  }
});
