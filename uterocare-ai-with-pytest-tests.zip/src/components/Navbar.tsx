import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Heart, 
  Calendar, 
  FileText, 
  BookOpen, 
  Stethoscope, 
  Menu, 
  X, 
  LogOut, 
  User as UserIcon, 
  ShieldCheck, 
  PlusCircle, 
  ClipboardList,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAssessment } from '../context/AssessmentContext';
import { Button } from './UI/Button';

export const Navbar: React.FC = () => {
  const { user, loading: authLoading, logout } = useAuth();
  const { startNewAssessment, activeAssessmentId } = useAssessment();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [starting, setStarting] = useState(false);
  const [navError, setNavError] = useState<string | null>(null);
  const location = useLocation();
  const navigate = useNavigate();

  const handleStartAssessment = async () => {
    if (starting) return;
    if (authLoading) return;
    if (!user) {
      navigate('/login?redirect=start-assessment');
      return;
    }
    setStarting(true);
    setNavError(null);
    try {
      const id = await startNewAssessment();
      setMobileMenuOpen(false);
      navigate(`/assessment/${id}`);
    } catch (err: any) {
      console.error('Failed to start assessment:', err);
      setNavError(err.message || 'Unable to initialize assessment. Please try again.');
    } finally {
      setStarting(false);
    }
  };

  const handleLogout = async () => {
    setUserDropdownOpen(false);
    setMobileMenuOpen(false);
    await logout();
    navigate('/');
  };

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'Cycle Tracker', path: '/cycle', icon: <Calendar className="w-4 h-4" /> },
    { label: 'Health Library', path: '/library', icon: <BookOpen className="w-4 h-4" /> },
    { label: 'Doctor Prep', path: '/doctor-prep', icon: <Stethoscope className="w-4 h-4" /> },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/90 backdrop-blur-md border-b border-[#E9E3DC]/80">
      {navError && (
        <div className="bg-rose-50 border-b border-rose-200 px-4 py-2 text-xs text-rose-800 flex items-center justify-between">
          <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
            <span className="font-bold shrink-0">Assessment Notice:</span>
            <span className="flex-1">{navError}</span>
            <button onClick={() => setNavError(null)} className="text-rose-600 hover:text-rose-900 font-bold p-1 cursor-pointer">
              ✕
            </button>
          </div>
        </div>
      )}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#451E33] to-[#7B325B] flex items-center justify-center text-white shadow-sm shadow-[#451E33]/20 group-hover:scale-105 transition-transform duration-200">
              <Heart className="w-5 h-5 fill-rose-200/50 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl font-bold tracking-tight text-[#2C141F] font-editorial">
                  UteroCare
                </span>
                <span className="text-[10px] font-semibold tracking-wider uppercase px-1.5 py-0.5 rounded-md bg-[#FAF2F5] text-[#9B4274] border border-[#EAC9D9]/60">
                  AI
                </span>
              </div>
              <p className="text-[11px] text-gray-500 font-sans tracking-tight -mt-0.5 hidden sm:block">
                Clinical Uterine Health Platform
              </p>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all duration-150 flex items-center gap-2 ${
                  isActive(link.path)
                    ? 'bg-[#F5E5EC] text-[#451E33] font-semibold'
                    : 'text-[#5C4D53] hover:text-[#2C141F] hover:bg-white/80'
                }`}
              >
                {link.icon}
                <span>{link.label}</span>
              </Link>
            ))}

            {user && (
              <Link
                to="/assessments"
                className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-all duration-150 flex items-center gap-2 ${
                  isActive('/assessments')
                    ? 'bg-[#F5E5EC] text-[#451E33] font-semibold'
                    : 'text-[#5C4D53] hover:text-[#2C141F] hover:bg-white/80'
                }`}
              >
                <ClipboardList className="w-4 h-4" />
                <span>My Assessments</span>
              </Link>
            )}
          </nav>

          {/* Action Buttons & Profile */}
          <div className="hidden sm:flex items-center gap-3">
            <Button
              variant="primary"
              size="sm"
              onClick={handleStartAssessment}
              isLoading={starting}
              icon={<PlusCircle className="w-4 h-4" />}
            >
              Start Assessment
            </Button>

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 pl-3 pr-2.5 rounded-2xl border border-[#E9E3DC] bg-white hover:border-[#DFC0CC] transition-colors focus:outline-none"
                  aria-expanded={userDropdownOpen}
                >
                  <div className="w-7 h-7 rounded-xl bg-[#FAF2F5] text-[#451E33] flex items-center justify-center font-bold text-xs border border-[#EAC9D9]">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="text-xs font-semibold text-[#2C141F] max-w-[100px] truncate">
                    {user.name}
                  </span>
                </button>

                {userDropdownOpen && (
                  <div 
                    className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-[#E9E3DC] py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150"
                    onMouseLeave={() => setUserDropdownOpen(false)}
                  >
                    <div className="px-4 py-2 border-b border-gray-100">
                      <p className="text-xs font-semibold text-[#2C141F]">{user.name}</p>
                      <p className="text-[11px] text-gray-500 truncate">{user.email}</p>
                    </div>

                    <Link
                      to="/assessments"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-[#FAF8F5] transition-colors"
                    >
                      <ClipboardList className="w-4 h-4 text-[#451E33]" />
                      <span>Active Assessments</span>
                    </Link>

                    <Link
                      to="/history"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-[#FAF8F5] transition-colors"
                    >
                      <FileText className="w-4 h-4 text-[#451E33]" />
                      <span>Assessment History</span>
                    </Link>

                    <Link
                      to="/settings"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-[#FAF8F5] transition-colors"
                    >
                      <UserIcon className="w-4 h-4 text-[#451E33]" />
                      <span>Account Settings</span>
                    </Link>

                    <Link
                      to="/privacy"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2.5 text-xs text-gray-700 hover:bg-[#FAF8F5] transition-colors"
                    >
                      <ShieldCheck className="w-4 h-4 text-[#5A7B57]" />
                      <span>Privacy & Security</span>
                    </Link>

                    <div className="border-t border-gray-100 my-1" />

                    <button
                      onClick={handleLogout}
                      className="w-full text-left flex items-center gap-2.5 px-4 py-2 text-xs text-rose-700 hover:bg-rose-50 transition-colors"
                    >
                      <LogOut className="w-4 h-4 text-rose-600" />
                      <span>Log Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link to="/login">
                  <Button variant="ghost" size="sm">
                    Log In
                  </Button>
                </Link>
                <Link to="/register">
                  <Button variant="secondary" size="sm">
                    Create Account
                  </Button>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-gray-700 hover:bg-gray-100 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#FAF8F5] border-b border-[#E9E3DC] px-4 pt-3 pb-6 space-y-3">
          <Button
            variant="primary"
            size="md"
            onClick={handleStartAssessment}
            isLoading={starting}
            icon={<PlusCircle className="w-4 h-4" />}
            className="w-full mb-3"
          >
            Start New Assessment
          </Button>

          <div className="space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                  isActive(link.path)
                    ? 'bg-[#F5E5EC] text-[#451E33] font-semibold'
                    : 'text-gray-700 hover:bg-white'
                }`}
              >
                {link.icon}
                <span>{link.label}</span>
              </Link>
            ))}

            {user && (
              <>
                <Link
                  to="/assessments"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-700 hover:bg-white"
                >
                  <ClipboardList className="w-4 h-4 text-[#451E33]" />
                  <span>My Active Assessments</span>
                </Link>
                <Link
                  to="/history"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-700 hover:bg-white"
                >
                  <FileText className="w-4 h-4 text-[#451E33]" />
                  <span>Assessment History</span>
                </Link>
                <Link
                  to="/settings"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-700 hover:bg-white"
                >
                  <UserIcon className="w-4 h-4 text-[#451E33]" />
                  <span>Account Settings</span>
                </Link>
                <Link
                  to="/privacy"
                  onClick={() => setMobileMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-gray-700 hover:bg-white"
                >
                  <ShieldCheck className="w-4 h-4 text-[#5A7B57]" />
                  <span>Privacy & Security</span>
                </Link>

                <div className="pt-2 border-t border-gray-200">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-rose-700 hover:bg-rose-50"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Log Out ({user.name})</span>
                  </button>
                </div>
              </>
            )}

            {!user && (
              <div className="pt-3 border-t border-gray-200 flex flex-col gap-2">
                <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="outline" size="md" className="w-full">
                    Log In
                  </Button>
                </Link>
                <Link to="/register" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="secondary" size="md" className="w-full">
                    Create Free Account
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
