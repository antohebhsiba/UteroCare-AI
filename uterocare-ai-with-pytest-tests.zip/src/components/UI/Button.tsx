import React from 'react';
import { Loader2 } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'sage' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  icon,
  className = '',
  disabled,
  ...props
}) => {
  const baseClasses = 'inline-flex items-center justify-center font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 active:scale-[0.98] select-none rounded-xl cursor-pointer disabled:cursor-not-allowed disabled:opacity-50 disabled:active:scale-100';

  const sizeClasses = {
    sm: 'text-xs px-3.5 py-1.5 gap-1.5',
    md: 'text-sm px-5 py-2.5 gap-2 shadow-xs',
    lg: 'text-base px-6 py-3.5 gap-2.5 shadow-sm',
  };

  const variantClasses = {
    primary: 'bg-[#451E33] text-white hover:bg-[#2E1522] focus:ring-[#451E33]/30 shadow-[#451E33]/10',
    secondary: 'bg-[#F5E5EC] text-[#451E33] hover:bg-[#EAC9D9] focus:ring-[#451E33]/20 border border-[#DFC0CC]/40',
    outline: 'border border-[#451E33]/30 text-[#451E33] hover:bg-[#F5E5EC]/60 focus:ring-[#451E33]/20 bg-transparent',
    sage: 'bg-[#5A7B57] text-white hover:bg-[#435E40] focus:ring-[#5A7B57]/30 shadow-[#5A7B57]/10',
    danger: 'bg-rose-700 text-white hover:bg-rose-800 focus:ring-rose-500/30',
    ghost: 'text-[#451E33] hover:bg-[#FAF2F5] focus:ring-[#451E33]/20',
  };

  return (
    <button
      className={`${baseClasses} ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? (
        <Loader2 className="w-4 h-4 animate-spin text-current" />
      ) : (
        icon && <span className="shrink-0">{icon}</span>
      )}
      <span>{children}</span>
    </button>
  );
};
