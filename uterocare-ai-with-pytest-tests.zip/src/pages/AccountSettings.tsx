import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User as UserIcon, 
  Mail, 
  ShieldAlert, 
  Trash2, 
  Download, 
  CheckCircle2, 
  AlertTriangle,
  Lock,
  LogOut
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../services/api';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';

export const AccountSettings: React.FC = () => {
  const { user, logout, deleteAccount } = useAuth();
  const navigate = useNavigate();

  const [confirmDelete, setConfirmDelete] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleExportData = async () => {
    try {
      const assessmentsRes = await api.getAssessments();
      const cycleRes = await api.getCycleLogs();
      const exportPayload = {
        exportDate: new Date().toISOString(),
        user: {
          name: user?.name,
          email: user?.email,
          createdAt: user?.createdAt,
        },
        assessments: assessmentsRes.assessments,
        cycleLogs: cycleRes.entries,
      };

      const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `uterocare_health_export_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setSuccessMsg('Your health records have been exported to JSON successfully.');
    } catch (err: any) {
      setError('Failed to export data: ' + err.message);
    }
  };

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    setError(null);
    try {
      await deleteAccount();
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Failed to delete account.');
      setIsDeleting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Header */}
      <div className="pb-6 border-b border-[#E9E3DC]">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-[#9B4274]">
            User Account
          </span>
          <span className="text-xs text-gray-400">• Security & Data Privacy</span>
        </div>
        <h1 className="text-3xl font-bold text-[#2C141F] font-editorial mt-1">
          Account Settings
        </h1>
        <p className="text-xs sm:text-sm text-gray-600 mt-1">
          Manage your profile, export your confidential health dossier, or permanently remove your data.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-3">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 rounded-2xl bg-[#EEF3ED] border border-[#D0E0CE] text-xs text-[#3E573B] flex items-center gap-3">
          <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Profile Overview */}
      <Card variant="white" className="p-6 space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#451E33] border-b border-gray-100 pb-3">
          Profile Information
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <span className="text-gray-500 block mb-1">Full Name:</span>
            <div className="flex items-center gap-2 font-medium text-gray-900 bg-[#FAF8F5] border border-[#E9E3DC] p-2.5 rounded-xl">
              <UserIcon className="w-4 h-4 text-[#451E33]" />
              <span>{user?.name || '—'}</span>
            </div>
          </div>

          <div>
            <span className="text-gray-500 block mb-1">Email Address:</span>
            <div className="flex items-center gap-2 font-medium text-gray-900 bg-[#FAF8F5] border border-[#E9E3DC] p-2.5 rounded-xl">
              <Mail className="w-4 h-4 text-[#451E33]" />
              <span>{user?.email || '—'}</span>
            </div>
          </div>
        </div>

        <div className="text-[11px] text-gray-500 pt-2">
          Account created on {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}.
        </div>
      </Card>

      {/* Data Sovereignty & Export */}
      <Card variant="white" className="p-6 space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#451E33] border-b border-gray-100 pb-3">
          Data Export & Portability
        </h3>

        <p className="text-xs text-gray-600 leading-relaxed">
          You own your health data. Download a complete JSON archive of all your saved assessments, symptom responses, doctor questions, and menstrual cycle logs.
        </p>

        <div>
          <Button
            variant="outline"
            size="md"
            onClick={handleExportData}
            icon={<Download className="w-4 h-4" />}
          >
            Export All Health Data (JSON)
          </Button>
        </div>
      </Card>

      {/* Danger Zone: Account Deletion */}
      <Card variant="white" className="p-6 border-rose-200 bg-rose-50/20 space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-rose-800 border-b border-rose-100 pb-3">
          Danger Zone
        </h3>

        <p className="text-xs text-rose-950 leading-relaxed">
          Permanent account deletion immediately erases your user profile, all active and completed assessments, cycle logs, and uploaded ultrasound/PDF records from our server storage. This action cannot be reversed.
        </p>

        {confirmDelete ? (
          <div className="p-4 rounded-2xl bg-rose-100 border border-rose-300 space-y-3">
            <p className="text-xs font-bold text-rose-900">
              Are you completely certain? All health data will be permanently wiped from the database.
            </p>
            <div className="flex items-center gap-3">
              <Button
                variant="danger"
                size="sm"
                onClick={handleDeleteAccount}
                isLoading={isDeleting}
              >
                Yes, Delete My Account Permanently
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setConfirmDelete(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <Button
            variant="danger"
            size="sm"
            onClick={() => setConfirmDelete(true)}
            icon={<Trash2 className="w-4 h-4" />}
          >
            Permanently Delete Account & Data
          </Button>
        )}
      </Card>

    </div>
  );
};
