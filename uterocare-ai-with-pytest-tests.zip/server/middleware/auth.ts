import { Request, Response, NextFunction } from 'express';
import { getUserFromSession, SafeUser } from '../security/auth.ts';

declare global {
  namespace Express {
    interface Request {
      user?: SafeUser;
      sessionId?: string;
    }
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction): void {
  const token = req.cookies?.utc_session || (req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : null);

  if (!token) {
    res.status(401).json({ error: 'Authentication required. Please log in.' });
    return;
  }

  const user = getUserFromSession(token);
  if (!user) {
    res.clearCookie('utc_session');
    res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
    return;
  }

  req.user = user;
  req.sessionId = token;
  next();
}

export function optionalAuth(req: Request, _res: Response, next: NextFunction): void {
  const token = req.cookies?.utc_session || (req.headers.authorization?.startsWith('Bearer ') ? req.headers.authorization.slice(7) : null);

  if (token) {
    const user = getUserFromSession(token);
    if (user) {
      req.user = user;
      req.sessionId = token;
    }
  }
  next();
}
