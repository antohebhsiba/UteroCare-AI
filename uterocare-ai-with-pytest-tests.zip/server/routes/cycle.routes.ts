import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import { z } from 'zod';
import { db } from '../database/db.ts';
import { requireAuth } from '../middleware/auth.ts';

export const cycleRouter = Router();

const CycleEntrySchema = z.object({
  start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Start date must be in YYYY-MM-DD format'),
  end_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'End date must be in YYYY-MM-DD format').optional().nullable(),
  flow_intensity: z.enum(['spotting', 'light', 'medium', 'heavy', 'very_heavy']).optional().nullable(),
  pain_level: z.number().min(0).max(10).optional().nullable(),
  symptoms: z.array(z.string()).optional(),
  notes: z.string().max(1000).optional().nullable(),
});

// GET /api/cycle - list entries and compute clinical menstrual analytics
cycleRouter.get('/', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const entries = db.prepare(`
      SELECT * FROM menstrual_entries
      WHERE user_id = ?
      ORDER BY start_date DESC
    `).all(userId) as any[];

    const parsedEntries = entries.map(e => ({
      ...e,
      symptoms: JSON.parse(e.symptoms || '[]')
    }));

    // Calculate metrics if sufficient data exists
    let averageCycleDays: number | null = null;
    let averagePeriodDays: number | null = null;
    let estimatedNextPeriod: string | null = null;

    if (parsedEntries.length >= 2) {
      // Sort ascending to calculate intervals between consecutive starts
      const sortedAsc = [...parsedEntries].sort((a, b) => new Date(a.start_date).getTime() - new Date(b.start_date).getTime());
      const cycleIntervals: number[] = [];

      for (let i = 1; i < sortedAsc.length; i++) {
        const prev = new Date(sortedAsc[i - 1].start_date).getTime();
        const curr = new Date(sortedAsc[i].start_date).getTime();
        const days = Math.round((curr - prev) / (1000 * 60 * 60 * 24));
        // Biological filter: cycle interval between 18 and 60 days
        if (days >= 18 && days <= 60) {
          cycleIntervals.push(days);
        }
      }

      if (cycleIntervals.length > 0) {
        averageCycleDays = Math.round(cycleIntervals.reduce((a, b) => a + b, 0) / cycleIntervals.length);
        const lastStart = new Date(parsedEntries[0].start_date);
        const nextDate = new Date(lastStart);
        nextDate.setDate(nextDate.getDate() + averageCycleDays);
        estimatedNextPeriod = nextDate.toISOString().split('T')[0];
      }
    }

    // Average bleeding duration
    const validDurations = parsedEntries
      .filter(e => e.end_date)
      .map(e => {
        const start = new Date(e.start_date).getTime();
        const end = new Date(e.end_date).getTime();
        return Math.max(1, Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1);
      })
      .filter(d => d > 0 && d <= 14);

    if (validDurations.length > 0) {
      averagePeriodDays = Math.round(validDurations.reduce((a, b) => a + b, 0) / validDurations.length);
    }

    res.json({
      entries: parsedEntries,
      analytics: {
        totalRecordedCycles: parsedEntries.length,
        averageCycleDays,
        averagePeriodDays,
        estimatedNextPeriod,
        estimationDisclaimer: estimatedNextPeriod ? 'Estimated date calculated purely from historical cycle spacing. Biological variations, illness, and stress naturally alter ovulation.' : null
      }
    });
  } catch (err) {
    console.error('Error fetching cycle entries:', err);
    res.status(500).json({ error: 'Failed to retrieve cycle logs.' });
  }
});

// POST /api/cycle - log new cycle
cycleRouter.post('/', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const parseResult = CycleEntrySchema.safeParse(req.body);
    if (!parseResult.success) {
      res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Invalid cycle data' });
      return;
    }

    const data = parseResult.data;

    // Validate date sequence if end_date provided
    if (data.end_date && new Date(data.end_date) < new Date(data.start_date)) {
      res.status(400).json({ error: 'Period end date cannot precede the start date.' });
      return;
    }

    const entryId = crypto.randomUUID();
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO menstrual_entries (id, user_id, start_date, end_date, flow_intensity, pain_level, symptoms, notes, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      entryId,
      userId,
      data.start_date,
      data.end_date ?? null,
      data.flow_intensity ?? null,
      data.pain_level ?? null,
      JSON.stringify(data.symptoms || []),
      data.notes ?? null,
      now,
      now
    );

    const saved = db.prepare('SELECT * FROM menstrual_entries WHERE id = ?').get(entryId) as any;
    res.status(201).json({
      entry: {
        ...saved,
        symptoms: JSON.parse(saved.symptoms || '[]')
      },
      message: 'Cycle log recorded successfully.'
    });
  } catch (err) {
    console.error('Error adding cycle log:', err);
    res.status(500).json({ error: 'Failed to save menstrual cycle log.' });
  }
});

// PUT /api/cycle/:id - update existing entry
cycleRouter.put('/:id', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const entryId = req.params.id;

    const existing = db.prepare('SELECT * FROM menstrual_entries WHERE id = ? AND user_id = ?').get(entryId, userId);
    if (!existing) {
      res.status(404).json({ error: 'Cycle entry not found or unauthorized.' });
      return;
    }

    const parseResult = CycleEntrySchema.safeParse(req.body);
    if (!parseResult.success) {
      res.status(400).json({ error: parseResult.error.issues[0]?.message || 'Invalid cycle data' });
      return;
    }

    const data = parseResult.data;
    if (data.end_date && new Date(data.end_date) < new Date(data.start_date)) {
      res.status(400).json({ error: 'Period end date cannot precede the start date.' });
      return;
    }

    const now = new Date().toISOString();

    db.prepare(`
      UPDATE menstrual_entries SET
        start_date = ?,
        end_date = ?,
        flow_intensity = ?,
        pain_level = ?,
        symptoms = ?,
        notes = ?,
        updated_at = ?
      WHERE id = ? AND user_id = ?
    `).run(
      data.start_date,
      data.end_date ?? null,
      data.flow_intensity ?? null,
      data.pain_level ?? null,
      JSON.stringify(data.symptoms || []),
      data.notes ?? null,
      now,
      entryId,
      userId
    );

    const updated = db.prepare('SELECT * FROM menstrual_entries WHERE id = ?').get(entryId) as any;
    res.json({
      entry: {
        ...updated,
        symptoms: JSON.parse(updated.symptoms || '[]')
      },
      message: 'Cycle log updated successfully.'
    });
  } catch (err) {
    console.error('Error updating cycle entry:', err);
    res.status(500).json({ error: 'Failed to update cycle log.' });
  }
});

// DELETE /api/cycle/:id - delete entry with confirmation
cycleRouter.delete('/:id', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const entryId = req.params.id;

    const existing = db.prepare('SELECT id FROM menstrual_entries WHERE id = ? AND user_id = ?').get(entryId, userId);
    if (!existing) {
      res.status(404).json({ error: 'Cycle entry not found or unauthorized.' });
      return;
    }

    db.prepare('DELETE FROM menstrual_entries WHERE id = ? AND user_id = ?').run(entryId, userId);
    res.json({ success: true, message: 'Cycle log deleted.' });
  } catch (err) {
    console.error('Error deleting cycle entry:', err);
    res.status(500).json({ error: 'Failed to delete cycle log.' });
  }
});
