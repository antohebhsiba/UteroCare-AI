import { 
  User, 
  Assessment, 
  SymptomData, 
  MedicalDocument, 
  AssessmentResult, 
  MenstrualEntry, 
  CycleAnalytics, 
  ConditionInfo 
} from '../types';

class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

const TOKEN_KEY = 'utc_session_token';

export function getAuthToken(): string | null {
  try {
    return sessionStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setAuthToken(token: string | null): void {
  try {
    if (token) {
      sessionStorage.setItem(TOKEN_KEY, token);
    } else {
      sessionStorage.removeItem(TOKEN_KEY);
    }
  } catch {
    // Ignore restricted environment storage errors
  }
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const defaultHeaders: Record<string, string> = {
    Accept: 'application/json',
  };

  const token = getAuthToken();
  if (token) {
    defaultHeaders['Authorization'] = `Bearer ${token}`;
  }

  if (!(options.body instanceof FormData)) {
    defaultHeaders['Content-Type'] = 'application/json';
  }

  const config: RequestInit = {
    ...options,
    credentials: 'include',
    headers: {
      ...defaultHeaders,
      ...options.headers,
    },
  };

  const response = await fetch(endpoint, config);

  if (!response.ok) {
    let errorMsg = 'An unexpected network error occurred';
    try {
      const errJson = await response.json();
      errorMsg = errJson.error || errJson.message || errorMsg;
    } catch {
      errorMsg = `Server returned error (${response.status} ${response.statusText})`;
    }
    throw new ApiError(errorMsg, response.status);
  }

  // Handle empty bodies like 204
  if (response.status === 204) {
    return {} as T;
  }

  return response.json();
}

export const api = {
  // Auth
  async register(data: { email: string; password: string; name: string }): Promise<{ user: User; token: string; message: string }> {
    const res = await request<{ user: User; token: string; message: string }>('/api/auth/register', { method: 'POST', body: JSON.stringify(data) });
    if (res.token) {
      setAuthToken(res.token);
    }
    return res;
  },

  async login(data: { email: string; password: string }): Promise<{ user: User; token: string; message: string }> {
    const res = await request<{ user: User; token: string; message: string }>('/api/auth/login', { method: 'POST', body: JSON.stringify(data) });
    if (res.token) {
      setAuthToken(res.token);
    }
    return res;
  },

  async logout(): Promise<{ success: boolean }> {
    try {
      return await request('/api/auth/logout', { method: 'POST' });
    } finally {
      setAuthToken(null);
    }
  },

  async getMe(): Promise<{ user: User }> {
    return request('/api/auth/me');
  },

  async deleteAccount(): Promise<{ success: boolean; message: string }> {
    try {
      return await request('/api/auth/account', { method: 'DELETE' });
    } finally {
      setAuthToken(null);
    }
  },

  // Assessments
  async getAssessments(): Promise<{ assessments: Assessment[] }> {
    return request('/api/assessments');
  },

  async createAssessment(data?: { title?: string }): Promise<{ assessment: Assessment; message: string }> {
    return request('/api/assessments', { method: 'POST', body: JSON.stringify(data || {}) });
  },

  async getAssessment(id: string): Promise<{
    assessment: Assessment;
    symptoms: SymptomData;
    documents: MedicalDocument[];
    result: AssessmentResult | null;
  }> {
    return request(`/api/assessments/${id}`);
  },

  async updateAssessment(id: string, updates: Partial<Assessment>): Promise<{ assessment: Assessment }> {
    return request(`/api/assessments/${id}`, { method: 'PATCH', body: JSON.stringify(updates) });
  },

  async deleteAssessment(id: string): Promise<{ success: boolean; message: string }> {
    return request(`/api/assessments/${id}`, { method: 'DELETE' });
  },

  // Symptoms
  async getSymptoms(assessmentId: string): Promise<{ symptoms: SymptomData }> {
    return request(`/api/assessments/${assessmentId}/symptoms`);
  },

  async saveSymptoms(assessmentId: string, symptoms: Partial<SymptomData>): Promise<{
    symptoms: SymptomData;
    emergencyFlag: boolean;
    message: string;
  }> {
    return request(`/api/assessments/${assessmentId}/symptoms`, {
      method: 'PUT',
      body: JSON.stringify(symptoms),
    });
  },

  // Documents
  async getDocuments(assessmentId: string): Promise<{ documents: MedicalDocument[] }> {
    return request(`/api/assessments/${assessmentId}/documents`);
  },

  async uploadDocument(assessmentId: string, file: File): Promise<{ document: MedicalDocument; message: string }> {
    const formData = new FormData();
    formData.append('file', file);
    return request(`/api/assessments/${assessmentId}/documents`, {
      method: 'POST',
      body: formData,
    });
  },

  async deleteDocument(assessmentId: string, documentId: string): Promise<{ success: boolean }> {
    return request(`/api/assessments/${assessmentId}/documents/${documentId}`, {
      method: 'DELETE',
    });
  },

  getDocumentDownloadUrl(assessmentId: string, documentId: string): string {
    return `/api/assessments/${assessmentId}/documents/${documentId}/file`;
  },

  // Analysis & Results
  async runAnalysis(assessmentId: string): Promise<{ result: AssessmentResult; message: string }> {
    return request(`/api/assessments/${assessmentId}/analyze`, { method: 'POST' });
  },

  async getResults(assessmentId: string): Promise<{ result: AssessmentResult }> {
    return request(`/api/assessments/${assessmentId}/results`);
  },

  async getReport(assessmentId: string): Promise<{ report: any }> {
    return request(`/api/assessments/${assessmentId}/report`);
  },

  // Cycle Tracker
  async getCycleLogs(): Promise<{ entries: MenstrualEntry[]; analytics: CycleAnalytics }> {
    return request('/api/cycle');
  },

  async addCycleLog(data: {
    start_date: string;
    end_date?: string | null;
    flow_intensity?: string | null;
    pain_level?: number | null;
    symptoms?: string[];
    notes?: string | null;
  }): Promise<{ entry: MenstrualEntry; message: string }> {
    return request('/api/cycle', { method: 'POST', body: JSON.stringify(data) });
  },

  async updateCycleLog(id: string, data: Partial<MenstrualEntry>): Promise<{ entry: MenstrualEntry }> {
    return request(`/api/cycle/${id}`, { method: 'PUT', body: JSON.stringify(data) });
  },

  async deleteCycleLog(id: string): Promise<{ success: boolean }> {
    return request(`/api/cycle/${id}`, { method: 'DELETE' });
  },

  // Conditions Library
  async getConditions(): Promise<{ conditions: ConditionInfo[] }> {
    return request('/api/conditions');
  },

  async getCondition(id: string): Promise<{ condition: ConditionInfo }> {
    return request(`/api/conditions/${id}`);
  },
};
