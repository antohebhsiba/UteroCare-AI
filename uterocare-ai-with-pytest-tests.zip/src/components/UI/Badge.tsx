import React from 'react';

interface BadgeProps {
  variant?: 'emergency' | 'urgent' | 'routine' | 'soon' | 'draft' | 'completed' | 'plum' | 'sage';
  children: React.ReactNode;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ variant = 'routine', children, className = '' }) => {
  const styles = {
    emergency: 'bg-rose-100 text-rose-800 border-rose-300 ring-rose-500/20',
    urgent: 'bg-amber-50 text-amber-800 border-amber-200 ring-amber-500/20',
    soon: 'bg-orange-50 text-orange-800 border-orange-200 ring-orange-500/20',
    routine: 'bg-[#E7EFE7] text-[#3E573B] border-[#D0E0CE] ring-[#5A7B57]/20',
    draft: 'bg-[#F2EFE9] text-[#6B5E63] border-[#E5E1D8]',
    completed: 'bg-[#F5E5EC] text-[#5E2645] border-[#EAC9D9]',
    plum: 'bg-[#451E33] text-white border-transparent',
    sage: 'bg-[#5A7B57] text-white border-transparent',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full border tracking-wide uppercase ${styles[variant]} ${className}`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current shrink-0" />
      {children}
    </span>
  );
};
