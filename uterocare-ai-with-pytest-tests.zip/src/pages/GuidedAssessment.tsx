import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  Save, 
  AlertTriangle, 
  ShieldAlert, 
  FileSearch, 
  Upload,
  Info,
  Clock,
  Sparkles
} from 'lucide-react';
import { useAssessment } from '../context/AssessmentContext';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';
import { EmergencyModal } from '../components/UI/EmergencyModal';

const STEPS = [
  { id: 1, title: 'Demographics & Primary Concern' },
  { id: 2, title: 'Cycle Characteristics' },
  { id: 3, title: 'Bleeding Flow & Heaviness' },
  { id: 4, title: 'Pelvic Pain & Dysmenorrhea' },
  { id: 5, title: 'Unscheduled Bleeding' },
  { id: 6, title: 'Pelvic Pressure & Bulk Symptoms' },
  { id: 7, title: 'Duration & Pregnancy Screening' },
  { id: 8, title: 'Medical History & Review' },
];

export const GuidedAssessment: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const {
    activeAssessment,
    symptoms,
    loadAssessment,
    startNewAssessment,
    updateSymptomField,
    saveCurrentSymptoms,
    isLoading,
    saveStatus,
    errorMessage,
  } = useAssessment();

  const [currentStep, setCurrentStep] = useState(1);
  const [emergencyAlertOpen, setEmergencyAlertOpen] = useState(false);
  const [emergencyReasons, setEmergencyReasons] = useState<string[]>([]);
  const [stepError, setStepError] = useState<string | null>(null);

  // Restore assessment on mount or URL change
  useEffect(() => {
    if (id === 'new') {
      startNewAssessment()
        .then((newId) => {
          navigate(`/assessment/${newId}`, { replace: true });
        })
        .catch((err) => {
          setStepError(err.message || 'Failed to initialize assessment');
          navigate('/assessments');
        });
      return;
    }

    if (id) {
      loadAssessment(id).then((success) => {
        if (!success) {
          navigate('/assessments');
        }
      });
    }
  }, [id, loadAssessment, startNewAssessment, navigate]);

  // Check emergency triggers on symptom change
  useEffect(() => {
    const reasons: string[] = [];
    const heaviness = (symptoms.bleeding_heaviness || '').toLowerCase();
    const severity = Number(symptoms.pain_severity || 0);
    const pregnancy = (symptoms.pregnancy_possibility || '').toLowerCase();

    if (heaviness.includes('very_heavy') || heaviness.includes('soaking')) {
      reasons.push('Soaking two or more pads/tampons per hour continuously, placing you at acute hemorrhagic risk.');
    }
    if ((pregnancy === 'yes' || pregnancy === 'possible') && (severity >= 6 || heaviness.length > 0)) {
      reasons.push('Possible pregnancy accompanied by pelvic pain and/or vaginal bleeding requires immediate clinical exclusion of ectopic pregnancy.');
    }
    if (severity >= 9) {
      reasons.push(`Acute severe pelvic pain (Score ${severity}/10) warrants urgent examination to exclude adnexal torsion or severe pelvic infection.`);
    }

    if (reasons.length > 0 && !emergencyAlertOpen) {
      setEmergencyReasons(reasons);
      setEmergencyAlertOpen(true);
    }
  }, [symptoms.bleeding_heaviness, symptoms.pain_severity, symptoms.pregnancy_possibility]);

  const handleNextStep = async () => {
    setStepError(null);
    const saved = await saveCurrentSymptoms();
    if (!saved) {
      setStepError('Unable to save changes to the database. Please verify your connection.');
      return;
    }
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // Completed last step -> navigate to AI Workspace / Uploads
      navigate(`/assessment/${id}/workspace`);
    }
  };

  const handlePrevStep = () => {
    setStepError(null);
    saveCurrentSymptoms();
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  if (isLoading && !activeAssessment) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <div className="w-10 h-10 border-3 border-[#451E33] border-t-transparent rounded-full animate-spin mx-auto" />
        <p className="text-xs text-gray-500 font-sans">Restoring saved assessment from database...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Emergency Modal */}
      <EmergencyModal
        isOpen={emergencyAlertOpen}
        onClose={() => setEmergencyAlertOpen(false)}
        reasons={emergencyReasons}
      />

      {/* Top Breadcrumb & Live Persistence Indicator */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#E9E3DC]">
        <div className="flex items-center gap-3">
          <Link
            to="/assessments"
            className="p-1.5 rounded-xl text-gray-500 hover:text-[#451E33] hover:bg-[#F5E5EC] transition-colors"
            title="Back to assessments list"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-[#FAF2F5] text-[#451E33] border border-[#EAC9D9]">
                {id}
              </span>
              <span className="text-xs text-gray-500">• Step {currentStep} of {STEPS.length}</span>
            </div>
            <h1 className="text-xl font-bold text-[#2C141F] font-editorial mt-0.5">
              {STEPS[currentStep - 1]?.title}
            </h1>
          </div>
        </div>

        {/* Live Saving Status Feedback */}
        <div className="flex items-center gap-2 self-start sm:self-auto text-xs">
          {saveStatus === 'saving' && (
            <span className="inline-flex items-center gap-1.5 text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
              <Clock className="w-3.5 h-3.5 animate-spin" />
              <span>Saving to database...</span>
            </span>
          )}
          {saveStatus === 'saved' && (
            <span className="inline-flex items-center gap-1.5 text-[#3E573B] bg-[#E7EFE7] px-2.5 py-1 rounded-full border border-[#D0E0CE]">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#5A7B57]" />
              <span>Progress Saved</span>
            </span>
          )}
          {saveStatus === 'error' && (
            <span className="inline-flex items-center gap-1.5 text-rose-700 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Save failed. Retrying...</span>
            </span>
          )}
        </div>
      </div>

      {/* Progress Stepper Bar */}
      <div className="w-full bg-[#E9E3DC]/60 h-2 rounded-full overflow-hidden">
        <div
          className="bg-[#451E33] h-full transition-all duration-300"
          style={{ width: `${(currentStep / STEPS.length) * 100}%` }}
        />
      </div>

      {stepError && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-3">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{stepError}</span>
        </div>
      )}

      {/* Step Form Content */}
      <Card variant="white" className="p-6 sm:p-10 space-y-8">
        
        {/* STEP 1: Demographics & Primary Concern */}
        {currentStep === 1 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-[#2C141F] font-editorial mb-1">
                Tell us about yourself and your primary concern
              </h2>
              <p className="text-xs text-gray-600">
                Uterine conditions such as fibroids, adenomyosis, and endometrial hyperplasia vary widely based on hormonal age milestones.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                What is your current age range?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['Under 20', '20-29', '30-39', '40-49', '50-55 (Perimenopausal)', 'Over 55 (Postmenopausal)', 'Prefer not to answer'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('age_range', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                      symptoms.age_range === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2" htmlFor="main_concern">
                What is the primary gynecological symptom or question bringing you here?
              </label>
              <textarea
                id="main_concern"
                rows={3}
                value={symptoms.main_concern || ''}
                onChange={(e) => updateSymptomField('main_concern', e.target.value)}
                placeholder="e.g. Periods have become very heavy with large clots over the past 6 months, accompanied by intense lower pelvic cramping and bladder pressure."
                className="w-full p-3.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20 focus:border-[#451E33]"
              />
            </div>
          </div>
        )}

        {/* STEP 2: Cycle Characteristics */}
        {currentStep === 2 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-[#2C141F] font-editorial mb-1">
                Menstrual Cycle Regularity & Timing
              </h2>
              <p className="text-xs text-gray-600">
                Cycle predictability helps distinguish structural uterine lesions from systemic ovulatory or endocrine disruptions (FIGO Ovulatory dysfunction 'O').
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                How predictable or regular are your menstrual cycles?
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {[
                  { val: 'regular', label: 'Regular (arrives reliably within 2-3 days of expected date)' },
                  { val: 'irregular', label: 'Irregular (unpredictable dates, intervals fluctuate by >7 days)' },
                  { val: 'infrequent', label: 'Infrequent (fewer than 9 periods per year)' },
                  { val: 'absent', label: 'Absent (no periods for 3+ consecutive months)' },
                  { val: 'postmenopausal', label: 'Postmenopausal (no periods for 12+ months)' },
                  { val: 'dont_know', label: "I don't know / Not tracking" },
                ].map((item) => (
                  <button
                    key={item.val}
                    type="button"
                    onClick={() => updateSymptomField('cycle_regularity', item.val)}
                    className={`p-3.5 rounded-xl border text-xs font-medium text-left transition-all ${
                      symptoms.cycle_regularity === item.val
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                Usual Cycle Length (Days from Day 1 of one period to Day 1 of the next period)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['Under 24 days (Short)', '24-38 days (Normal)', 'Over 38 days (Prolonged)', "I don't know", 'Not applicable'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('cycle_length', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                      symptoms.cycle_length === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Bleeding Flow & Heaviness */}
        {currentStep === 3 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-[#2C141F] font-editorial mb-1">
                Bleeding Volume & Duration
              </h2>
              <p className="text-xs text-gray-600">
                Heavy menstrual bleeding (menorrhagia) is the defining presentation of submucosal fibroids, adenomyosis, and endometrial polyps.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                How many days does your bleeding typically last?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['1-3 days', '4-7 days (Standard)', '8-10 days (Prolonged)', 'More than 10 days', 'Continuous / Daily', 'Not applicable'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('bleeding_duration', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                      symptoms.bleeding_duration === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                How heavy is your blood flow on your heaviest days?
              </label>
              <div className="space-y-2">
                {[
                  { val: 'light', label: 'Light flow (regular pads or tampons last >4 hours without filling)' },
                  { val: 'moderate', label: 'Moderate flow (changing regular pad/tampon every 3-4 hours)' },
                  { val: 'heavy', label: 'Heavy (changing super pad/tampon every 1-2 hours, passing nickel-sized clots)' },
                  { val: 'very_heavy', label: 'Very Heavy / Flooding (soaking 2+ pads/tampons per hour, passing golf ball-sized clots, double protection required)' },
                  { val: 'spotting_only', label: 'Spotting only (scant brownish discharge)' },
                ].map((item) => (
                  <button
                    key={item.val}
                    type="button"
                    onClick={() => updateSymptomField('bleeding_heaviness', item.val)}
                    className={`w-full p-3.5 rounded-xl border text-xs font-medium text-left transition-all ${
                      symptoms.bleeding_heaviness === item.val
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 4: Pelvic Pain & Dysmenorrhea */}
        {currentStep === 4 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-[#2C141F] font-editorial mb-1">
                Pelvic Pain, Cramping & Severity
              </h2>
              <p className="text-xs text-gray-600">
                Severe dysmenorrhea and non-cyclical pelvic pain provide strong diagnostic clues for adenomyosis, endometriosis, and degenerating fibroids.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                Do you experience pelvic pain or intense menstrual cramps?
              </label>
              <div className="grid grid-cols-3 gap-2.5">
                {['yes', 'no', 'occasionally'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('pelvic_pain_presence', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-center uppercase tracking-wider transition-all ${
                      symptoms.pelvic_pain_presence === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {symptoms.pelvic_pain_presence !== 'no' && (
              <>
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-xs font-semibold text-[#451E33]">
                      Pain Severity Scale (0 = None, 10 = Debilitating / Worst Imaginable)
                    </label>
                    <span className="text-sm font-bold text-[#451E33] px-2.5 py-0.5 rounded-lg bg-[#FAF2F5] border border-[#EAC9D9]">
                      {symptoms.pain_severity ?? 0} / 10
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="10"
                    step="1"
                    value={symptoms.pain_severity ?? 0}
                    onChange={(e) => updateSymptomField('pain_severity', Number(e.target.value))}
                    className="w-full accent-[#451E33] h-2 bg-gray-200 rounded-lg cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                    <span>0: No pain</span>
                    <span>3: Mild</span>
                    <span>6: Moderate (limits activity)</span>
                    <span>8: Severe</span>
                    <span>10: Emergency</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#451E33] mb-2">
                    Where is the pain primarily localized?
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {['Lower midline pelvis', 'Left lower abdomen', 'Right lower abdomen', 'Radiating to lower back', 'Deep vaginal / pelvic floor', 'Diffuse throughout pelvis'].map((loc) => (
                      <button
                        key={loc}
                        type="button"
                        onClick={() => updateSymptomField('pain_location', loc)}
                        className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                          symptoms.pain_location === loc
                            ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                            : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                        }`}
                      >
                        {loc}
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* STEP 5: Unscheduled Bleeding */}
        {currentStep === 5 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-[#2C141F] font-editorial mb-1">
                Unscheduled or Postcoital Bleeding
              </h2>
              <p className="text-xs text-gray-600">
                Intermenstrual bleeding (between periods) is a hallmark sign of endometrial polyps, while postcoital bleeding warrants cervical speculum examination.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                Do you experience spotting or bleeding between expected menstrual periods?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['yes', 'no', 'occasionally', "I don't know"].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('intermenstrual_bleeding', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-center uppercase tracking-wider transition-all ${
                      symptoms.intermenstrual_bleeding === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                Do you experience bleeding during or immediately following sexual intercourse?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['yes', 'no', 'occasionally', 'Not applicable'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('postcoital_bleeding', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-center uppercase tracking-wider transition-all ${
                      symptoms.postcoital_bleeding === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 6: Pelvic Pressure & Bulk Symptoms */}
        {currentStep === 6 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-[#2C141F] font-editorial mb-1">
                Pelvic Pressure, Fullness & Adjacent Organs
              </h2>
              <p className="text-xs text-gray-600">
                Large intramural or subserosal fibroids and uterine prolapse place mechanical pressure against the urinary bladder and rectosigmoid bowel.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                Do you feel a chronic sensation of pelvic fullness, downward heaviness, or lower abdominal bulge?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['yes', 'no', 'worse_standing', "I don't know"].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('pelvic_pressure', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-center uppercase tracking-wider transition-all ${
                      symptoms.pelvic_pressure === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt === 'worse_standing' ? 'Worse when standing' : opt}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                Do you experience frequent urination, incomplete bladder emptying, or bowel constipation?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['yes', 'no', 'bladder_only', 'bowel_only'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('urinary_bowel_symptoms', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-center uppercase tracking-wider transition-all ${
                      symptoms.urinary_bowel_symptoms === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 7: Duration & Pregnancy Screening */}
        {currentStep === 7 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-[#2C141F] font-editorial mb-1">
                Symptom Duration & Sensitive Pregnancy Safety Check
              </h2>
              <p className="text-xs text-gray-600">
                Pregnancy-related bleeding and unilateral pain require distinct, emergent medical pathways to exclude ectopic gestation.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-2">
                How long have you been experiencing these symptoms?
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['Under 1 month', '1-3 months', '3-6 months', '6-12 months', 'More than 1 year', 'Years / Ongoing'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('symptom_duration', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-left transition-all ${
                      symptoms.symptom_duration === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-[#E9E3DC] bg-[#FAF8F5] text-gray-700 hover:bg-white'
                    }`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-[#FAF2F5]/60 border border-[#DFC0CC] p-4 rounded-2xl">
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5">
                Is there any possibility you could be currently pregnant?
              </label>
              <p className="text-[11px] text-gray-500 mb-3">
                This question is asked purely for your clinical safety, as unexplained vaginal bleeding or pain during early pregnancy requires urgent physician attention.
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {['no', 'possible', 'yes', 'not_applicable'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => updateSymptomField('pregnancy_possibility', opt)}
                    className={`p-3 rounded-xl border text-xs font-medium text-center uppercase tracking-wider transition-all ${
                      symptoms.pregnancy_possibility === opt
                        ? 'border-[#451E33] bg-[#F5E5EC] text-[#451E33] font-bold shadow-xs'
                        : 'border-white bg-white text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    {opt.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STEP 8: Medical History & Final Review */}
        {currentStep === 8 && (
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-[#2C141F] font-editorial mb-1">
                Medical History & Medications Review
              </h2>
              <p className="text-xs text-gray-600">
                Known diagnoses (fibroids, polyps, thyroid disorders) and medications (blood thinners, hormonal coils) clarify the clinical picture.
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="prior_diagnoses">
                Any prior gynecological diagnoses or pelvic surgical procedures?
              </label>
              <textarea
                id="prior_diagnoses"
                rows={2}
                value={symptoms.prior_diagnoses || ''}
                onChange={(e) => updateSymptomField('prior_diagnoses', e.target.value)}
                placeholder="e.g. Diagnosed with small 2cm fibroid 2 years ago; laparoscopic removal of ovarian cyst in 2021."
                className="w-full p-3 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="current_medications">
                Current medications, hormonal therapies, or contraception
              </label>
              <textarea
                id="current_medications"
                rows={2}
                value={symptoms.current_medications || ''}
                onChange={(e) => updateSymptomField('current_medications', e.target.value)}
                placeholder="e.g. Combined oral contraceptive pill, ibuprofen for pain, iron supplements."
                className="w-full p-3 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="additional_notes">
                Additional observations or notes for your doctor
              </label>
              <textarea
                id="additional_notes"
                rows={2}
                value={symptoms.additional_notes || ''}
                onChange={(e) => updateSymptomField('additional_notes', e.target.value)}
                placeholder="Anything else relevant to your symptoms, family history of fibroids or endometriosis..."
                className="w-full p-3 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20"
              />
            </div>

            {/* Ready to proceed banner */}
            <div className="p-4 rounded-2xl bg-[#EEF3ED] border border-[#D0E0CE] text-xs text-[#3E573B] flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-[#5A7B57] shrink-0 mt-0.5" />
              <div>
                <strong>Questionnaire complete!</strong> You can now attach ultrasound images or medical PDF records if you have them, or proceed directly to generate your clinical report.
              </div>
            </div>
          </div>
        )}

        {/* Stepper Navigation Buttons */}
        <div className="flex items-center justify-between pt-6 border-t border-gray-100">
          <Button
            type="button"
            variant="ghost"
            size="md"
            onClick={handlePrevStep}
            disabled={currentStep === 1}
            icon={<ArrowLeft className="w-4 h-4" />}
          >
            Previous
          </Button>

          <div className="flex items-center gap-3">
            <Button
              type="button"
              variant="outline"
              size="md"
              onClick={() => saveCurrentSymptoms()}
              icon={<Save className="w-4 h-4" />}
            >
              Save Progress
            </Button>

            <Button
              type="button"
              variant="primary"
              size="md"
              onClick={handleNextStep}
              icon={currentStep === STEPS.length ? <Sparkles className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            >
              {currentStep === STEPS.length ? 'Review & Analyze' : 'Next Step'}
            </Button>
          </div>
        </div>

      </Card>

    </div>
  );
};
