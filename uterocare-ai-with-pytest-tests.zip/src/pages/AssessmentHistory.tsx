import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  FileText, 
  Calendar, 
  Clock, 
  ArrowRight, 
  Trash2, 
  CheckCircle2, 
  Sparkles,
  ClipboardList
} from 'lucide-react';
import { api } from '../services/api';
import { Assessment } from '../types';
import { Card } from '../components/UI/Card';
import { Button } from '../components/UI/Button';
import { Badge } from '../components/UI/Badge';

export const AssessmentHistory: React.FC = () => {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'completed' | 'draft'>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    async function loadHistory() {
      try {
        const res = await api.getAssessments();
        setAssessments(res.assessments);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadHistory();
  }, []);

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await api.deleteAssessment(id);
      setAssessments(prev => prev.filter(a => a.id !== id));
    } catch (err) {
      console.error(err);
    } finally {
      setDeletingId(null);
    }
  };

  const filtered = assessments.filter(a => {
    if (filter === 'completed') return a.status === 'completed';
    if (filter === 'draft') return a.status !== 'completed';
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E9E3DC]">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-[#9B4274]">
              Longitudinal Registry
            </span>
            <span className="text-xs text-gray-400">• Assessment History</span>
          </div>
          <h1 className="text-3xl font-bold text-[#2C141F] font-editorial mt-1">
            Historical Records & Reports
          </h1>
          <p className="text-xs sm:text-sm text-gray-600 mt-1">
            Review past assessments to observe symptom changes over months and years.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-white border border-[#E9E3DC]">
          {(['all', 'completed', 'draft'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setFilter(tab)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-all ${
                filter === tab
                  ? 'bg-[#451E33] text-white shadow-xs'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-28 rounded-2xl bg-white border border-[#E9E3DC] animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card variant="white" className="text-center py-16 px-6">
          <div className="w-14 h-14 rounded-2xl bg-[#FAF2F5] text-[#9B4274] flex items-center justify-center mx-auto mb-3">
            <ClipboardList className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-[#2C141F] font-editorial">
            No Assessments Found
          </h3>
          <p className="text-xs text-gray-500 mt-1">
            {filter !== 'all' ? `No ${filter} assessments available.` : 'You have not created any assessments yet.'}
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map(item => (
            <Card
              key={item.id}
              variant="white"
              className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-[#C77A9E] transition-colors"
            >
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-[#FAF2F5] text-[#451E33] border border-[#EAC9D9]">
                    {item.id}
                  </span>
                  <Badge variant={item.status === 'completed' ? 'completed' : 'draft'}>
                    {item.status.replace('_', ' ')}
                  </Badge>
                </div>
                <h4 className="text-base font-bold text-[#2C141F] font-editorial">
                  {item.title}
                </h4>
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{new Date(item.created_at).toLocaleDateString()}</span>
                  </span>
                  {item.main_concern && (
                    <span className="italic truncate max-w-sm">"{item.main_concern}"</span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-auto">
                {item.status === 'completed' ? (
                  <Link to={`/assessment/${item.id}/results`}>
                    <Button variant="outline" size="sm" icon={<FileText className="w-3.5 h-3.5" />}>
                      View Report
                    </Button>
                  </Link>
                ) : (
                  <Link to={`/assessment/${item.id}`}>
                    <Button variant="primary" size="sm" icon={<ArrowRight className="w-3.5 h-3.5" />}>
                      Resume
                    </Button>
                  </Link>
                )}

                <button
                  onClick={() => handleDelete(item.id)}
                  disabled={deletingId === item.id}
                  className="p-2 text-gray-400 hover:text-rose-600 rounded-xl hover:bg-rose-50"
                  title="Delete assessment"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </Card>
          ))}
        </div>
      )}

    </div>
  );
};
