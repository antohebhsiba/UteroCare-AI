import express, { Request, Response, NextFunction } from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import { db } from './database/db.ts';
import { authRouter } from './routes/auth.routes.ts';
import { assessmentsRouter } from './routes/assessments.routes.ts';
import { symptomsRouter } from './routes/symptoms.routes.ts';
import { documentsRouter } from './routes/documents.routes.ts';
import { analysisRouter } from './routes/analysis.routes.ts';
import { cycleRouter } from './routes/cycle.routes.ts';
import { conditionsRouter } from './routes/conditions.routes.ts';

export const app = express();

// Basic security headers
app.use((_req: Request, res: Response, next: NextFunction) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// Middleware
app.use(cors({
  origin: true,
  credentials: true,
}));
app.use(cookieParser());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Simple in-memory rate limiting for auth endpoints (prevents brute force)
const rateLimitMap = new Map<string, { count: number; resetAt: number }>();
function authRateLimiter(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const windowMs = 15 * 60 * 1000; // 15 minutes
  const maxAttempts = 30;

  const record = rateLimitMap.get(ip);
  if (!record || record.resetAt < now) {
    rateLimitMap.set(ip, { count: 1, resetAt: now + windowMs });
    return next();
  }

  if (record.count >= maxAttempts) {
    res.status(429).json({ error: 'Too many authentication attempts. Please wait 15 minutes before trying again.' });
    return;
  }

  record.count += 1;
  next();
}

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  try {
    const dbCheck = db.prepare('SELECT 1 as healthy').get() as { healthy: number };
    res.json({
      status: 'ok',
      service: 'UteroCare AI API',
      database: dbCheck?.healthy === 1 ? 'connected' : 'error',
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    res.status(503).json({
      status: 'error',
      database: 'disconnected',
      error: err.message,
    });
  }
});

// Route registration
app.use('/api/auth/login', authRateLimiter);
app.use('/api/auth/register', authRateLimiter);
app.use('/api/auth', authRouter);

// Nested assessment endpoints
app.use('/api/assessments/:id/symptoms', symptomsRouter);
app.use('/api/assessments/:id/documents', documentsRouter);
app.use('/api/assessments/:id', analysisRouter);
app.use('/api/assessments', assessmentsRouter);

app.use('/api/cycle', cycleRouter);
app.use('/api/conditions', conditionsRouter);

// 404 for unmatched API routes
app.all('/api/*', (req: Request, res: Response) => {
  res.status(404).json({ error: `API route ${req.method} ${req.url} not found` });
});

// Central error handler
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error('Unhandled server exception:', err);
  const status = err.status || err.statusCode || 500;
  res.status(status).json({
    error: err.message || 'An unexpected internal server error occurred.'
  });
});
