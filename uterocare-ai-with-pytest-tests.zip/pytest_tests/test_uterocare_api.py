"""Pytest API tests for UteroCare AI.

Run with the UteroCare server running:
    python -m pytest -v pytest_tests

Optional base URL:
    set UTEROCARE_BASE_URL=http://127.0.0.1:3000

These tests use synthetic data and do not require third-party HTTP libraries.
"""
import json
import os
import time
import urllib.error
import urllib.request
import uuid

import pytest

BASE_URL = os.getenv("UTEROCARE_BASE_URL", "http://127.0.0.1:3000").rstrip("/")


def request_json(path, method="GET", payload=None, token=None):
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    headers = {"Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(BASE_URL + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=8) as response:
            body = response.read().decode("utf-8")
            return response.status, json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8")
        try:
            parsed = json.loads(body) if body else {}
        except json.JSONDecodeError:
            parsed = {"raw": body}
        return exc.code, parsed


def new_user():
    suffix = f"{int(time.time())}_{uuid.uuid4().hex[:8]}"
    return {
        "name": "Pytest User",
        "email": f"pytest_{suffix}@example.com",
        "password": "TestPassword123!",
    }


@pytest.fixture(scope="session", autouse=True)
def server_is_running():
    try:
        status, body = request_json("/api/health")
    except (OSError, TimeoutError, urllib.error.URLError) as exc:
        pytest.skip(
            f"UteroCare server is not reachable at {BASE_URL}. Start it with `npm run dev`. ({exc})"
        )
    if status != 200 or body.get("status") != "ok":
        pytest.skip(f"UteroCare health check did not pass: HTTP {status}, response={body}")


def test_health_endpoint_reports_database_connected():
    status, body = request_json("/api/health")
    assert status == 200
    assert body.get("status") == "ok"
    assert body.get("database") == "connected"


def test_register_with_valid_details_succeeds():
    status, body = request_json("/api/auth/register", "POST", new_user())
    assert status == 201
    assert body.get("user", {}).get("email", "").endswith("@example.com")
    assert body.get("token")


@pytest.mark.parametrize(
    "payload",
    [
        {"name": "Valid Name", "email": "not-an-email", "password": "TestPassword123!"},
        {"name": "A", "email": "shortname@example.com", "password": "TestPassword123!"},
        {"name": "Valid Name", "email": "valid@example.com", "password": "123"},
        {"name": "", "email": "", "password": ""},
    ],
)
def test_registration_rejects_invalid_or_missing_fields(payload):
    status, body = request_json("/api/auth/register", "POST", payload)
    assert status == 400
    assert body.get("error")


def test_duplicate_registration_is_rejected():
    user = new_user()
    first_status, _ = request_json("/api/auth/register", "POST", user)
    assert first_status == 201
    second_status, body = request_json("/api/auth/register", "POST", user)
    assert second_status == 409
    assert body.get("error")


def test_login_with_wrong_password_is_rejected():
    user = new_user()
    status, _ = request_json("/api/auth/register", "POST", user)
    assert status == 201
    bad_login = {"email": user["email"], "password": "WrongPassword123!"}
    status, body = request_json("/api/auth/login", "POST", bad_login)
    assert status == 401
    assert body.get("error")


def test_protected_assessments_endpoint_rejects_unauthenticated_request():
    status, body = request_json("/api/assessments")
    assert status == 401
    assert body.get("error")


def test_authenticated_user_can_create_and_list_assessment():
    user = new_user()
    status, body = request_json("/api/auth/register", "POST", user)
    assert status == 201
    token = body["token"]

    create_status, created = request_json(
        "/api/assessments", "POST", {"title": "Pytest Sample Assessment"}, token=token
    )
    assert create_status == 201
    assessment = created.get("assessment", {})
    assert assessment.get("id")
    assert assessment.get("title") == "Pytest Sample Assessment"

    list_status, listed = request_json("/api/assessments", token=token)
    assert list_status == 200
    ids = [item.get("id") for item in listed.get("assessments", [])]
    assert assessment["id"] in ids


def test_unknown_api_route_returns_404():
    status, body = request_json(f"/api/pytest-route-does-not-exist-{uuid.uuid4().hex}")
    assert status == 404
    assert body.get("error")
