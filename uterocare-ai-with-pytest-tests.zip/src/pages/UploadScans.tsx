import React, { useEffect, useState, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Upload, 
  FileText, 
  Image as ImageIcon, 
  Trash2, 
  AlertCircle, 
  CheckCircle2, 
  ExternalLink, 
  AlertTriangle, 
  Sparkles,
  Info,
  ShieldCheck
} from 'lucide-react';
import { useAssessment } from '../context/AssessmentContext';
import { api } from '../services/api';
import { MedicalDocument } from '../types';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';
import { Badge } from '../components/UI/Badge';

export const UploadScans: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const {
    activeAssessment,
    documents,
    loadAssessment,
    uploadScanOrRecord,
    removeDocument,
    isLoading,
  } = useAssessment();

  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [selectedPreviewDoc, setSelectedPreviewDoc] = useState<MedicalDocument | null>(null);

  useEffect(() => {
    if (id) {
      loadAssessment(id);
    }
  }, [id, loadAssessment]);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadError(null);
    setSuccessMsg(null);

    // Validate size (max 15MB)
    if (file.size > 15 * 1024 * 1024) {
      setUploadError('File exceeds maximum allowable size (15MB). Please upload a smaller file.');
      return;
    }

    // Validate type
    const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (!validTypes.includes(file.type)) {
      setUploadError('Unsupported format. Please upload JPG/PNG ultrasound images or PDF clinical reports.');
      return;
    }

    setUploading(true);
    try {
      const doc = await uploadScanOrRecord(file);
      setSuccessMsg(`"${file.name}" uploaded securely and linked to assessment.`);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err: any) {
      setUploadError(err.message || 'File upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (docId: string) => {
    if (selectedPreviewDoc?.id === docId) {
      setSelectedPreviewDoc(null);
    }
    await removeDocument(docId);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#E9E3DC]">
        <div className="flex items-center gap-3">
          <Link
            to={id ? `/assessment/${id}` : '/assessments'}
            className="p-1.5 rounded-xl text-gray-500 hover:text-[#451E33] hover:bg-[#F5E5EC] transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-semibold px-2 py-0.5 rounded-md bg-[#FAF2F5] text-[#451E33] border border-[#EAC9D9]">
                {id}
              </span>
              <span className="text-xs text-gray-400">• Records Storage</span>
            </div>
            <h1 className="text-2xl font-bold text-[#2C141F] font-editorial mt-0.5">
              Upload Scans & Medical Records
            </h1>
          </div>
        </div>

        {id && (
          <Link to={`/assessment/${id}/workspace`}>
            <Button variant="primary" size="md" icon={<Sparkles className="w-4 h-4" />}>
              Proceed to AI Workspace
            </Button>
          </Link>
        )}
      </div>

      {/* Mandatory Medical Ultrasound Model Notice (Part 10 directive) */}
      <div className="bg-[#FAF8F5] border border-[#E9E3DC] rounded-2xl p-4 flex items-start gap-3">
        <Info className="w-5 h-5 text-[#7B325B] shrink-0 mt-0.5" />
        <div className="text-xs text-gray-700 leading-relaxed">
          <strong className="text-[#451E33]">Ultrasound Interpretation Transparency:</strong> Automated ultrasound interpretation is unavailable because a compatible trained model has not been configured in this environment. Uploaded images are stored securely for doctor review. PDF reports will have readable text extracted automatically.
        </div>
      </div>

      {uploadError && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-center gap-3">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{uploadError}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-4 rounded-2xl bg-[#EEF3ED] border border-[#D0E0CE] text-xs text-[#3E573B] flex items-center gap-3">
          <CheckCircle2 className="w-4 h-4 text-[#5A7B57] shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Upload Dropzone */}
      <Card variant="white" className="p-8 text-center border-dashed border-2 border-[#DFC0CC] hover:border-[#451E33] transition-colors">
        <input
          ref={fileInputRef}
          type="file"
          accept=".jpg,.jpeg,.png,.pdf"
          onChange={handleFileSelect}
          className="hidden"
          id="file-upload-input"
        />

        <div className="w-14 h-14 rounded-3xl bg-[#FAF2F5] text-[#9B4274] flex items-center justify-center mx-auto mb-3 border border-[#EAC9D9]/60">
          <Upload className="w-6 h-6" />
        </div>

        <h3 className="text-lg font-bold text-[#2C141F] font-editorial">
          Select Pelvic Ultrasound Scans or Medical Reports
        </h3>
        <p className="text-xs text-gray-600 max-w-md mx-auto mt-1 mb-4 leading-relaxed">
          Supports JPG/PNG pelvic ultrasound images and PDF pathology or clinical consultation summaries (up to 15MB each). Files are stored privately outside public web paths.
        </p>

        <label htmlFor="file-upload-input">
          <Button
            type="button"
            variant="secondary"
            size="md"
            isLoading={uploading}
            onClick={() => fileInputRef.current?.click()}
            icon={<Upload className="w-4 h-4" />}
          >
            {uploading ? 'Uploading & Encrypting...' : 'Browse Local Files'}
          </Button>
        </label>
      </Card>

      {/* Documents List */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-[#2C141F] font-editorial">
            Attached Records ({documents.length})
          </h2>
          <span className="text-xs text-gray-500">
            Linked to assessment {id}
          </span>
        </div>

        {documents.length === 0 ? (
          <Card variant="ivory" className="text-center py-8 text-xs text-gray-500">
            No documents attached yet. You may complete the clinical assessment without uploading scans.
          </Card>
        ) : (
          <div className="space-y-3">
            {documents.map((doc) => (
              <Card
                key={doc.id}
                variant="white"
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#FAF2F5] text-[#451E33] flex items-center justify-center shrink-0 border border-[#EAC9D9]">
                    {doc.document_type === 'pdf_report' ? (
                      <FileText className="w-5 h-5 text-rose-700" />
                    ) : (
                      <ImageIcon className="w-5 h-5 text-[#5A7B57]" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#2C141F] truncate max-w-sm">
                      {doc.original_name}
                    </h4>
                    <div className="flex items-center gap-2 text-[11px] text-gray-500 mt-0.5">
                      <span>{(doc.size_bytes / 1024).toFixed(1)} KB</span>
                      <span>•</span>
                      <span className="capitalize">{doc.document_type.replace('_', ' ')}</span>
                      <span>•</span>
                      <span>{new Date(doc.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  {doc.extracted_text && (
                    <button
                      onClick={() => setSelectedPreviewDoc(selectedPreviewDoc?.id === doc.id ? null : doc)}
                      className="text-xs px-2.5 py-1.5 rounded-lg border border-[#DFC0CC] text-[#7B325B] hover:bg-[#FAF2F5]"
                    >
                      {selectedPreviewDoc?.id === doc.id ? 'Hide Text' : 'View Extracted Text'}
                    </button>
                  )}

                  <a
                    href={api.getDocumentDownloadUrl(id || '', doc.id)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs px-2.5 py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 inline-flex items-center gap-1"
                  >
                    <span>View File</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  <button
                    onClick={() => handleDelete(doc.id)}
                    className="p-1.5 text-gray-400 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                    title="Remove document"
                    aria-label={`Remove document ${doc.original_name}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Extracted Text Inspector Modal/Drawer */}
      {selectedPreviewDoc?.extracted_text && (
        <Card variant="white" className="p-6 border-[#451E33]/30 shadow-md animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-gray-100 mb-3">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#451E33]" />
              <h3 className="text-xs font-bold text-[#2C141F] uppercase tracking-wider">
                Extracted Clinical Report Text: {selectedPreviewDoc.original_name}
              </h3>
            </div>
            <button
              onClick={() => setSelectedPreviewDoc(null)}
              className="text-xs text-gray-400 hover:text-gray-700 font-semibold"
            >
              Close
            </button>
          </div>
          <div className="p-3.5 rounded-xl bg-[#FAF8F5] border border-[#E9E3DC] text-xs text-gray-800 font-mono max-h-60 overflow-y-auto whitespace-pre-wrap leading-relaxed">
            {selectedPreviewDoc.extracted_text}
          </div>
        </Card>
      )}

      {/* Privacy Guarantee */}
      <div className="flex items-center justify-center gap-2 text-xs text-gray-500 pt-4">
        <ShieldCheck className="w-4 h-4 text-[#5A7B57]" />
        <span>Private Disk Storage • Isolated Assessment Ownership • No Public Access</span>
      </div>

    </div>
  );
};
