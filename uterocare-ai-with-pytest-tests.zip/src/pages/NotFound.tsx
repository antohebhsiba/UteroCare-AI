import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Home, ArrowLeft } from 'lucide-react';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';

export const NotFound: React.FC = () => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center py-16 px-4">
      <Card variant="white" className="max-w-md w-full text-center p-8 border-[#E9E3DC] shadow-sm space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-[#FAF2F5] text-[#451E33] flex items-center justify-center mx-auto mb-2 border border-[#EAC9D9]">
          <Heart className="w-7 h-7 fill-rose-200" />
        </div>

        <h1 className="text-4xl font-bold text-[#2C141F] font-editorial">
          404
        </h1>
        <h2 className="text-lg font-bold text-gray-800 font-editorial">
          Page Not Found
        </h2>

        <p className="text-xs text-gray-600 leading-relaxed">
          The health page or assessment record you requested does not exist or may have been moved.
        </p>

        <div className="pt-4 flex flex-col sm:flex-row gap-2.5 justify-center">
          <Link to="/">
            <Button variant="primary" size="sm" icon={<Home className="w-4 h-4" />}>
              Return to Home
            </Button>
          </Link>
          <Link to="/assessments">
            <Button variant="outline" size="sm" icon={<ArrowLeft className="w-4 h-4" />}>
              My Assessments
            </Button>
          </Link>
        </div>
      </Card>
    </div>
  );
};
