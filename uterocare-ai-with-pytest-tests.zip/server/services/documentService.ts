import fs from 'fs';
import path from 'path';

const UPLOADS_DIR = path.resolve(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

export function saveUploadFile(buffer: Buffer, originalFilename: string, mimeType: string): { filename: string; filePath: string } {
  const ext = path.extname(originalFilename).toLowerCase() || (mimeType === 'application/pdf' ? '.pdf' : '.jpg');
  const safeBase = path.basename(originalFilename, ext).replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 50);
  const uniqueName = `${Date.now()}_${Math.random().toString(36).substring(2, 9)}_${safeBase}${ext}`;
  const filePath = path.join(UPLOADS_DIR, uniqueName);

  fs.writeFileSync(filePath, buffer);
  return { filename: uniqueName, filePath };
}

export function deleteUploadFile(filename: string): void {
  try {
    const filePath = path.join(UPLOADS_DIR, path.basename(filename));
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch (err) {
    console.error('Error removing upload file from disk:', err);
  }
}

export function extractPdfText(buffer: Buffer): { text: string; isScanned: boolean } {
  try {
    // Extract raw text markers from PDF streams
    const content = buffer.toString('utf-8', 0, Math.min(buffer.length, 500000));
    const textMatches: string[] = [];
    
    // Look for text in PDF objects / BT ... ET blocks or string literals ( ... )
    const regex = /\(([^)]+)\)\s*T[jJ]/g;
    let match;
    while ((match = regex.exec(content)) !== null) {
      if (match[1] && match[1].trim().length > 0) {
        textMatches.push(match[1]);
      }
    }

    if (textMatches.length > 0) {
      const extracted = textMatches.join(' ').replace(/\\r/g, ' ').replace(/\\n/g, ' ');
      return { text: extracted, isScanned: false };
    }

    // Secondary check for ASCII text lines
    const lines = content.split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 5 && !l.startsWith('%') && !l.startsWith('/') && !l.includes('obj') && !l.includes('endobj'));

    if (lines.length > 10) {
      return { text: lines.slice(0, 30).join(' '), isScanned: false };
    }

    return {
      text: '',
      isScanned: true
    };
  } catch (err) {
    console.error('Error parsing PDF content:', err);
    return { text: '', isScanned: true };
  }
}
