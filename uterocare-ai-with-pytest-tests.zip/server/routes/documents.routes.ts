import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { db } from '../database/db.ts';
import { requireAuth } from '../middleware/auth.ts';
import { saveUploadFile, deleteUploadFile, extractPdfText } from '../services/documentService.ts';

export const documentsRouter = Router({ mergeParams: true });

// Memory storage for inspection and validation before writing to disk
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 15 * 1024 * 1024, // 15 MB limit
  },
  fileFilter: (_req, file, cb) => {
    const allowedMimes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG images and PDF documents are supported.'));
    }
  },
});

// POST /api/assessments/:id/documents
documentsRouter.post('/', requireAuth, (req: Request, res: Response, next) => {
  upload.single('file')(req, res, (err) => {
    if (err) {
      if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') {
        res.status(400).json({ error: 'File size exceeds maximum permitted limit (15MB).' });
        return;
      }
      res.status(400).json({ error: err.message || 'File upload failed.' });
      return;
    }
    next();
  });
}, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    // Verify assessment ownership
    const assessment = db.prepare('SELECT id FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId);
    if (!assessment) {
      res.status(404).json({ error: 'Assessment not found or unauthorized.' });
      return;
    }

    if (!req.file) {
      res.status(400).json({ error: 'No file was provided in the request.' });
      return;
    }

    const { originalname, mimetype, buffer } = req.file;

    // Determine document type
    const isPdf = mimetype === 'application/pdf';
    const documentType = isPdf ? 'pdf_report' : 'ultrasound_image';

    // Save to private storage
    const { filename, filePath } = saveUploadFile(buffer, originalname, mimetype);

    let extractedText: string | null = null;
    let status = 'uploaded';

    if (isPdf) {
      const pdfResult = extractPdfText(buffer);
      extractedText = pdfResult.text || null;
      status = pdfResult.text ? 'extracted' : 'uploaded';
    }

    const docId = crypto.randomUUID();
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO medical_documents (
        id, assessment_id, user_id, filename, original_name, mime_type, size_bytes, storage_path, document_type, extracted_text, status, created_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      docId,
      assessmentId,
      userId,
      filename,
      originalname,
      mimetype,
      buffer.length,
      filePath,
      documentType,
      extractedText,
      status,
      now
    );

    const savedDoc = db.prepare('SELECT * FROM medical_documents WHERE id = ?').get(docId);

    res.status(201).json({
      document: savedDoc,
      message: 'Document uploaded and securely associated with assessment.'
    });
  } catch (err: any) {
    console.error('Document upload error:', err);
    res.status(500).json({ error: 'An unexpected error occurred while saving the medical document.' });
  }
});

// GET /api/assessments/:id/documents
documentsRouter.get('/', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const assessmentId = req.params.id;

    // Verify ownership
    const assessment = db.prepare('SELECT id FROM assessments WHERE id = ? AND user_id = ?').get(assessmentId, userId);
    if (!assessment) {
      res.status(404).json({ error: 'Assessment not found or unauthorized.' });
      return;
    }

    const docs = db.prepare(`
      SELECT id, assessment_id, filename, original_name, mime_type, size_bytes, document_type, extracted_text, status, created_at
      FROM medical_documents
      WHERE assessment_id = ?
      ORDER BY created_at ASC
    `).all(assessmentId);

    res.json({ documents: docs });
  } catch (err) {
    console.error('Error fetching documents:', err);
    res.status(500).json({ error: 'Failed to retrieve assessment documents.' });
  }
});

// GET /api/assessments/:id/documents/:documentId/file - private file retrieval
documentsRouter.get('/:documentId/file', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const { id: assessmentId, documentId } = req.params;

    const doc = db.prepare(`
      SELECT * FROM medical_documents
      WHERE id = ? AND assessment_id = ? AND user_id = ?
    `).get(documentId, assessmentId, userId) as any;

    if (!doc) {
      res.status(404).json({ error: 'Document not found or access denied.' });
      return;
    }

    const filePath = path.resolve(process.cwd(), 'uploads', doc.filename);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'Physical file not found on disk.' });
      return;
    }

    res.setHeader('Content-Type', doc.mime_type);
    res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(doc.original_name)}"`);
    fs.createReadStream(filePath).pipe(res);
  } catch (err) {
    console.error('Error downloading file:', err);
    res.status(500).json({ error: 'Failed to retrieve file.' });
  }
});

// DELETE /api/assessments/:id/documents/:documentId
documentsRouter.delete('/:documentId', requireAuth, (req: Request, res: Response) => {
  try {
    const userId = req.user!.id;
    const { id: assessmentId, documentId } = req.params;

    const doc = db.prepare(`
      SELECT * FROM medical_documents
      WHERE id = ? AND assessment_id = ? AND user_id = ?
    `).get(documentId, assessmentId, userId) as any;

    if (!doc) {
      res.status(404).json({ error: 'Document not found or access denied.' });
      return;
    }

    deleteUploadFile(doc.filename);
    db.prepare('DELETE FROM medical_documents WHERE id = ?').run(documentId);

    res.json({ success: true, message: 'Document removed successfully.' });
  } catch (err) {
    console.error('Error deleting document:', err);
    res.status(500).json({ error: 'Failed to delete document.' });
  }
});
