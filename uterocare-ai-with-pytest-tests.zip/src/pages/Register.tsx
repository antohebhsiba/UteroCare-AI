import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Heart, Lock, Mail, User as UserIcon, AlertCircle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAssessment } from '../context/AssessmentContext';
import { Button } from '../components/UI/Button';
import { Card } from '../components/UI/Card';

export const Register: React.FC = () => {
  const { register } = useAuth();
  const { startNewAssessment } = useAssessment();
  const navigate = useNavigate();
  const location = useLocation();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const queryParams = new URLSearchParams(location.search);
  const redirectTarget = queryParams.get('redirect') || '/assessments';

  // Password strength checks
  const hasMinLength = password.length >= 8;
  const hasNumberOrSymbol = /[\d!@#$%^&*(),.?":{}|<>]/.test(password);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim() || name.trim().length < 2) {
      setError('Please provide your name (at least 2 characters).');
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      setError('Please provide a valid email address.');
      return;
    }

    if (!hasMinLength) {
      setError('Password must be at least 8 characters long.');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match. Please verify both fields.');
      return;
    }

    setIsSubmitting(true);
    try {
      await register({
        name: name.trim(),
        email: email.trim(),
        password,
      });
      if (redirectTarget.includes('start-assessment') || redirectTarget.includes('assessment/new')) {
        const newId = await startNewAssessment();
        navigate(`/assessment/${newId}`);
      } else {
        navigate(redirectTarget.startsWith('/') ? redirectTarget : `/${redirectTarget}`);
      }
    } catch (err: any) {
      setError(err.message || 'Registration failed. Please check your details and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex w-12 h-12 rounded-2xl bg-[#451E33] items-center justify-center text-white shadow-sm mb-2">
            <Heart className="w-6 h-6 fill-rose-200" />
          </div>
          <h1 className="text-3xl font-bold text-[#2C141F] font-editorial">
            Create Your Confidential Account
          </h1>
          <p className="text-xs text-gray-600 max-w-sm mx-auto">
            Your assessments and health records are privately stored and never shared with third parties.
          </p>
        </div>

        <Card variant="white" className="border-[#E9E3DC] shadow-sm p-6 sm:p-8">
          
          {error && (
            <div className="mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="name">
                Full Name or Preferred Name
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  id="name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Sarah Jenkins"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20 focus:border-[#451E33]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="email">
                Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="sarah@example.com"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20 focus:border-[#451E33]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="password">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 8 characters"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20 focus:border-[#451E33]"
                />
              </div>

              {/* Password strength micro-hints */}
              <div className="mt-2 space-y-1 text-[11px]">
                <div className={`flex items-center gap-1.5 ${hasMinLength ? 'text-[#5A7B57]' : 'text-gray-400'}`}>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>At least 8 characters</span>
                </div>
                <div className={`flex items-center gap-1.5 ${hasNumberOrSymbol ? 'text-[#5A7B57]' : 'text-gray-400'}`}>
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Contains a number or symbol</span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#451E33] mb-1.5" htmlFor="confirmPassword">
                Confirm Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  id="confirmPassword"
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat your password"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-[#E9E3DC] bg-[#FAF8F5] text-xs text-gray-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#451E33]/20 focus:border-[#451E33]"
                />
              </div>
            </div>

            <div className="pt-2">
              <Button
                type="submit"
                variant="primary"
                size="md"
                isLoading={isSubmitting}
                className="w-full"
              >
                Create Account & Continue
              </Button>
            </div>

          </form>

          <div className="mt-6 pt-5 border-t border-gray-100 text-center">
            <p className="text-xs text-gray-600">
              Already have an account?{' '}
              <Link to={`/login?redirect=${encodeURIComponent(redirectTarget)}`} className="font-semibold text-[#451E33] hover:underline">
                Log in here
              </Link>
            </p>
          </div>

        </Card>

        <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
          <ShieldCheck className="w-4 h-4 text-[#5A7B57]" />
          <span>Encrypted with Argon2id/Bcrypt • Private SQLite Storage</span>
        </div>

      </div>
    </div>
  );
};
